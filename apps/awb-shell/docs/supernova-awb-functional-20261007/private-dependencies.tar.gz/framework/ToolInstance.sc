ToolInstance {
    // THE SINGLE REGISTRY OF TOOLS.
    //
    // Every instance registers here on creation and detaches on close, so one
    // place answers "what tools exist" regardless of how they were made -
    // through ToolLauncher or constructed directly. ToolLauncher keeps its own
    // map because it needs instanceID lookup and single-instance policy; this
    // is the directory, not a second launcher.
    //
    // ATTACHING IS EASY; DETACHING CANNOT BE GUARANTEED. A crash, an abandoned
    // instance, or a window closed without close() all leave an entry behind.
    // So the design does not pretend otherwise: entries are never silently
    // dropped, `status` and `openedAt` stay truthful, and a leaked instance
    // shows as what it is - `created`, hours old, no GUI - rather than
    // vanishing or passing for active. `sweep` prunes the ones that really
    // did close; everything else is visible and can be judged.
    classvar <all;

    var <definition, <instanceID, <config, <status, <interfaceObject, <guiObject;
    var <emissions, <ownedObjects, <openedAt, <closedAt;
    var <configRevision, <trackingEnabled, <trackingAvailable;
    var <recordingState, <recordingPath;
    var trackingAdapter, ownedRecords, projectedEmissions;
    var eventSequence, openedElapsed;
    var activeRecorder, trackingBeforeRecord;
    var <sourcePresetRef, <sourcePresetFingerprint;

    *initClass { all = [] }

    *new { |definition, initialConfig, instanceID|
        ^super.newCopyArgs(definition, instanceID).init(initialConfig);
    }

    // Set when a tool builds its own GUI outside ToolLauncher, so guiObject
    // is truthful on BOTH paths - the hub reads it either way.
    guiObject_ { |anObject| guiObject = anObject; ^this }

    // --- the registry ---------------------------------------------------------

    // Registered at CREATION, not at open, so an instance built directly is in
    // the directory too. Whether it was opened is what `status` is for.
    *prAttach { |instance|
        if(all.includes(instance).not) {
            all = all.add(instance);
            this.changed(\attached, instance);
        };
        ^instance;
    }

    *prDetach { |instance|
        all = all.reject { |each| each === instance };
        this.changed(\detached, instance);
        ^instance;
    }

    // Instances that have not closed. Includes any that leaked, showing their
    // real status - that is the point.
    *live { ^all.reject { |each| each.status == \closed } }

    *withStatus { |aStatus| ^all.select { |each| each.status == aStatus.asSymbol } }

    *forDefinition { |toolID|
        toolID = toolID.asSymbol;
        ^all.select { |each| each.definition.id == toolID };
    }

    // Drop the ones that genuinely closed. Returns how many went, so a caller
    // can tell the difference between "nothing to do" and "nothing happened".
    *sweep {
        var before;
        before = all.size;
        all = all.reject { |each| each.status == \closed };
        ^before - all.size;
    }

    *report {
        var out;
        out = "TOOL INSTANCES  ·  % registered  ·  % live\n".format(
            all.size, this.live.size);
        all.do { |each|
            out = out ++ "   %  %  %  %\n".format(
                each.status.asString.padRight(10),
                each.definition.id.asString.padRight(22),
                each.instanceID.asString.padRight(26),
                if(each.guiObject.notNil) { "gui" } { "" }
            );
        };
        ^out;
    }

    init { |initialConfig|
        if(definition.isKindOf(ToolDefinition).not) {
            Error("ToolInstance requires a ToolDefinition").throw;
        };

        instanceID = instanceID ? this.makeInstanceID;
        config = definition.defaultConfig.copy;
        config.putAll(initialConfig ? ());
        status = \created;
        ToolInstance.prAttach(this);
        configRevision = 0;
        emissions = List.new;
        ownedObjects = IdentitySet.new;
        ownedRecords = IdentityDictionary.new;
        projectedEmissions = IdentitySet.new;
        trackingEnabled = false;
        trackingAvailable = false;
        recordingState = \idle;
        guiObject = nil;
        sourcePresetRef = nil;
        sourcePresetFingerprint = nil;
        eventSequence = 0;
        openedElapsed = Main.elapsedTime;
    }

    makeInstanceID {
        ^("%:%".format(definition.id, UniqueID.next));
    }

    open { |options|
        options = options ? ();
        if(status != \created) {
            Error("ToolInstance % cannot open from state %"
                .format(instanceID, status)).throw;
        };

        sourcePresetRef = options[\sourcePresetRef];
        sourcePresetFingerprint = options[\sourcePresetFingerprint];
        this.configureTracking(options);
        status = \opening;
        openedAt = Date.getDate;
        this.publishEvent(\instanceOpening, this.snapshot);
        this.syncNodeManager;

        try {
            interfaceObject = if(options[\launchInterface] == false) {
                nil
            } {
                definition.open(this, options)
            };
            if((options[\gui] ? true) and: { definition.guiFactory.notNil }) {
                guiObject = definition.openGUI(this, interfaceObject, options);
            };
            status = \active;
            this.syncNodeManager;
            this.publishEvent(\instanceOpened, this.snapshot);
            this.changed(\opened, this.snapshot);
        } { |error|
            status = \failed;
            this.syncNodeManager;
            this.publishEvent(\instanceFailed, (error: error.errorString));
            this.changed(\failed, error);
            error.throw;
        };

        ^this;
    }

    configureTracking { |options|
        var requested;

        trackingAdapter = if(options[\nodeManager] == false) { nil } { \NodeManager.asClass };
        trackingAvailable = trackingAdapter.notNil;
        requested = options[\track] ? options[\trackingEnabled] ? false;
        trackingEnabled = requested == true and: { trackingAvailable };
        ^this;
    }

    updateState { |patch, removedKeys|
        if(status == \closed) {
            Error("ToolInstance % is closed".format(instanceID)).throw;
        };

        removedKeys = removedKeys ? [];
        removedKeys.do { |key| config.removeAt(key) };
        config.putAll(patch ? ());
        configRevision = configRevision + 1;
        this.publishEvent(\stateChanged, (
            patch: (patch ? ()).deepCopy,
            removedKeys: removedKeys.copy,
            state: config.deepCopy
        ));
        this.syncNodeManager;
        this.changed(\stateChanged, patch ? ());
        ^config;
    }

    emit { |emissionType, payload, emissionMetadata|
        var emission, configSnapshot;

        emissionType = emissionType.asSymbol;
        if(definition.acceptsEmission(emissionType).not) {
            Error("Tool % does not declare emission type %"
                .format(definition.id, emissionType)).throw;
        };

        configSnapshot = config.deepCopy;
        emission = (
            emissionID: "%:%".format(instanceID, UniqueID.next),
            type: emissionType,
            payload: payload,
            metadata: (emissionMetadata ? ()).copy,
            toolSource: definition.id,
            toolVersion: definition.version,
            toolInstance: instanceID,
            config: configSnapshot,
            configRevision: configRevision,
            configFingerprint: this.configFingerprintFor(configSnapshot),
            emittedAt: Date.getDate
        );
        if(sourcePresetRef.notNil) {
            emission[\sourcePresetRef] = sourcePresetRef.deepCopy;
            emission[\sourcePresetFingerprint] = sourcePresetFingerprint;
        };
        emissions.add(emission);
        this.publishEvent(\emission, emission.deepCopy);
        if(trackingEnabled) { this.projectEmission(emission) };
        this.syncNodeManager;
        this.changed(\emitted, emission);
        ^emission;
    }

    own { |object, type = \toolObject, objectMetadata|
        var provenance, record;

        if(object.isNil) {
            Error("ToolInstance cannot own nil").throw;
        };

        provenance = (objectMetadata ? ()).copy;
        provenance[\toolSource] = definition.id;
        provenance[\toolInstance] = instanceID;
        if(sourcePresetRef.notNil) {
            provenance[\sourcePresetRef] = sourcePresetRef.deepCopy;
            provenance[\sourcePresetFingerprint] = sourcePresetFingerprint;
        };
        record = (type: type, metadata: provenance);
        ownedRecords[object] = record;
        ownedObjects.add(object);
        if(trackingAvailable) {
            trackingAdapter.perform(\watch, object, type, provenance, this);
            if(trackingEnabled) {
                trackingAdapter.perform(\project, object, type, provenance);
            } {
                trackingAdapter.perform(\unproject, object);
            };
        };
        this.publishEvent(\objectOwned, (
            objectID: this.objectIDFor(object),
            objectType: type,
            metadata: provenance.deepCopy
        ));
        this.changed(\objectOwned, object);
        ^object;
    }

    disown { |object, unregister = true|
        var record;

        record = ownedRecords.removeAt(object);
        ownedObjects.remove(object);
        if(unregister and: { trackingAvailable }) {
            trackingAdapter.perform(\forget, object);
        };
        if(record.notNil) {
            this.publishEvent(\objectDisowned, (
                objectID: this.objectIDFor(object),
                objectType: record[\type]
            ));
        };
        this.changed(\objectDisowned, object);
        ^object;
    }

    requestOwnedAction { |object, action, args, origin = \tool|
        var record, requestID, controlled;

        record = ownedRecords[object];
        if(record.isNil) { ^false };
        args = args ? [];
        requestID = "%:%".format(instanceID, UniqueID.next);
        controlled = this.performDirectAction(object, action, args);
        if(controlled) {
            this.publishEvent(\objectCommand, (
                objectID: this.objectIDFor(object),
                objectType: record[\type],
                action: action,
                arguments: args.copy
            ), requestID, origin);
            this.notifyInterface(\ownedObjectActionRequested,
                object, action, args, origin, requestID);
        };
        ^controlled;
    }

    performDirectAction { |object, action, args|
        var releaseTime, server, nodeIDs, controlled;

        controlled = true;
        try {
            switch(action,
                \pause, {
                    if(object.isKindOf(Node).not) { ^false };
                    object.run(false);
                },
                \resume, {
                    if(object.isKindOf(Node).not) { ^false };
                    object.run(true);
                },
                \release, {
                    if(object.respondsTo(\release).not) { ^false };
                    releaseTime = args.at(0);
                    if(releaseTime.isNil) { object.release } { object.release(releaseTime) };
                },
                \stop, {
                    if(object.respondsTo(\stop).not) { ^false };
                    object.stop;
                },
                \free, {
                    if(object.respondsTo(\free).not) { ^false };
                    object.free;
                },
                \terminate, {
                    if(object.isKindOf(Event)) {
                        nodeIDs = object[\id];
                        if(nodeIDs.isNil) { ^false };
                        server = object[\server] ? Server.default;
                        nodeIDs.asArray.do { |nodeID| server.sendMsg(\n_free, nodeID) };
                        object[\id] = nil;
                    } {
                        if(object.isKindOf(Node) and: { object.respondsTo(\free) }) {
                            object.free;
                        } {
                            if(object.respondsTo(\stop)) {
                                object.stop;
                            } {
                                if(object.respondsTo(\free)) { object.free } { ^false };
                            };
                        };
                    };
                },
                { ^false }
            );
        } { |error|
            controlled = false;
            ("ToolInstance action % failed for %: %"
                .format(action, object.class.name, error.errorString)).warn;
        };
        ^controlled;
    }

    ownedObjectEnded { |object, reason = \ended, origin = \nodeManager|
        var record;

        record = ownedRecords.removeAt(object);
        if(record.isNil) { ^false };
        ownedObjects.remove(object);
        this.publishEvent(\objectEnded, (
            objectID: this.objectIDFor(object),
            objectType: record[\type],
            reason: reason,
            metadata: record[\metadata].deepCopy
        ), nil, origin);
        this.notifyInterface(\ownedObjectEnded, object, reason, origin);
        this.changed(\objectEnded, object);
        ^true;
    }

    notifyInterface { |selector ...args|
        var callback;

        if(interfaceObject.isNil) { ^this };
        if(interfaceObject.respondsTo(selector)) {
            interfaceObject.perform(selector, *args);
        } {
            if(interfaceObject.isKindOf(Event)) {
                callback = interfaceObject[selector];
                if(callback.notNil) { callback.valueArray(args) };
            };
        };
        ^this;
    }

    interfaceData { |selector ...args|
        if(interfaceObject.isNil) {
            Error("ToolInstance % has no interface object".format(instanceID)).throw;
        };
        if(interfaceObject.respondsTo(selector).not) {
            Error("Tool % does not expose %"
                .format(definition.id, selector)).throw;
        };
        ^interfaceObject.perform(selector, *args);
    }

    content {
        ^this.interfaceData(\content);
    }

    contentAt { |key|
        ^this.interfaceData(\contentAt, key);
    }

    results {
        ^this.interfaceData(\results);
    }

    resultAt { |index|
        ^this.interfaceData(\resultAt, index);
    }

    selection {
        ^this.interfaceData(\selection);
    }

    setTracking { |enabled|
        var hostControl, activated;
        enabled = enabled == true;
        if(enabled == trackingEnabled) { ^trackingEnabled };
        if(trackingAvailable.not) {
            this.changed(\trackingUnavailable, this.snapshot);
            ^false;
        };

        if(enabled) {
            hostControl = \AWBHostControl.asClass;
            activated = if(hostControl.notNil and: { hostControl.default.notNil }) {
                hostControl.perform(\ensureNodeManager)
            } {
                if(trackingAdapter.respondsTo(\ensureEnabled)) {
                    trackingAdapter.perform(\ensureEnabled)
                } {
                    true
                }
            };
            if(activated.not) {
                    this.changed(\trackingUnavailable, this.snapshot);
                    ^false;
            };
        };

        trackingEnabled = enabled;
        if(enabled) {
            this.syncNodeManager;
            ownedRecords.keysValuesDo { |object, record|
                trackingAdapter.perform(\project,
                    object, record[\type], record[\metadata]);
            };
        } {
            projectedEmissions.copy.do { |emission|
                trackingAdapter.perform(\forget, emission);
            };
            projectedEmissions.clear;
            ownedObjects.do { |object| trackingAdapter.perform(\unproject, object) };
            trackingAdapter.perform(\forget, this);
        };
        this.publishEvent(\trackingChanged, (enabled: enabled));
        this.changed(\trackingChanged, enabled);
        ^trackingEnabled;
    }

    startRecording { |directory|
        if(recordingState == \recording) { ^recordingPath };
        if(trackingAvailable.not) {
            Error("Semantic recording requires NodeManager integration").throw;
        };
        trackingBeforeRecord = trackingEnabled;
        if(trackingEnabled.not) { this.setTracking(true) };
        try {
            activeRecorder = SessionRecorder(
                this,
                (kind: \toolInstance, id: instanceID),
                directory
            );
            recordingState = \recording;
            recordingPath = activeRecorder.partialPath;
            activeRecorder.start;
            this.changed(\recordingChanged, recordingState);
        } { |error|
            recordingState = \failed;
            if(trackingEnabled != trackingBeforeRecord) {
                this.setTracking(trackingBeforeRecord);
            };
            this.changed(\recordingFailed, error);
            error.throw;
        };
        ^recordingPath;
    }

    stopRecording {
        var result;

        if(recordingState != \recording) { ^recordingPath };
        result = activeRecorder.stop;
        recordingPath = result;
        recordingState = if(activeRecorder.state == \completed) { \idle } { \failed };
        if(trackingEnabled != trackingBeforeRecord) {
            this.setTracking(trackingBeforeRecord);
        };
        this.changed(\recordingChanged, recordingState);
        ^recordingPath;
    }

    recorderFailed { |recorder, caught|
        if(recorder !== activeRecorder) { ^this };
        recordingPath = recorder.partialPath;
        recordingState = \failed;
        if(trackingEnabled != trackingBeforeRecord) {
            this.setTracking(trackingBeforeRecord);
        };
        this.changed(\recordingFailed, caught);
        ^this;
    }

    close {
        if(status == \closed) { ^this };

        if(recordingState == \recording) { this.stopRecording };

        status = \closing;
        this.publishEvent(\instanceClosing, this.snapshot);
        this.syncNodeManager;

        try {
            definition.closeGUI(this, guiObject);
            guiObject = nil;
        } { |error|
            ("ToolInstance GUI close failed for %: %"
                .format(instanceID, error.errorString)).warn;
        };

        try {
            definition.close(this);
        } { |error|
            ("ToolInstance close action failed for %: %"
                .format(instanceID, error.errorString)).warn;
        };

        switch(definition.cleanupPolicy,
            \releaseOwned, { this.releaseOwned },
            \leaveOwned, { nil },
            { this.terminateOwned }
        );

        status = \closed;
        closedAt = Date.getDate;
        ToolInstance.prDetach(this);
        this.publishEvent(\instanceClosed, this.snapshot);
        if(trackingAvailable) {
            projectedEmissions.copy.do { |emission|
                trackingAdapter.perform(\forget, emission);
            };
            ownedObjects.copy.do { |object| trackingAdapter.perform(\forget, object) };
            trackingAdapter.perform(\forget, this);
        };
        projectedEmissions.clear;
        ownedObjects.clear;
        ownedRecords.clear;
        ToolLauncher.instanceClosed(this);
        this.changed(\closed, this.snapshot);
        ^this;
    }

    releaseOwned { |releaseTime = 0.1|
        ownedObjects.copy.do { |object|
            this.requestOwnedAction(object, \release, [releaseTime], \toolClose);
        };
        ^this;
    }

    terminateOwned {
        ownedObjects.copy.do { |object|
            this.requestOwnedAction(object, \terminate, [], \toolClose);
        };
        ^this;
    }

    syncNodeManager {
        var projection;
        if(trackingEnabled.not or: { trackingAvailable.not }) { ^this };
        projection = (
            name: definition.displayName,
            toolSource: definition.id,
            toolVersion: definition.version,
            toolInstance: instanceID,
            toolState: config.deepCopy,
            toolStatus: status,
            configRevision: configRevision,
            emissionCount: emissions.size
        );
        if(sourcePresetRef.notNil) {
            projection[\sourcePresetRef] = sourcePresetRef.deepCopy;
            projection[\sourcePresetFingerprint] = sourcePresetFingerprint;
        };
        trackingAdapter.perform(\project, this, \tool, projection);
        ^this;
    }

    projectEmission { |emission|
        var configSnapshot, projection;

        configSnapshot = emission[\config].deepCopy;
        projection = (
            name: "% emission (revision %)".format(
                emission[\type], emission[\configRevision]),
            toolSource: definition.id,
            toolVersion: definition.version,
            toolInstance: instanceID,
            emissionID: emission[\emissionID],
            emissionType: emission[\type],
            toolConfig: configSnapshot,
            configRevision: emission[\configRevision],
            readOnly: true
        );
        if(emission[\sourcePresetRef].notNil) {
            projection[\sourcePresetRef] = emission[\sourcePresetRef].deepCopy;
            projection[\sourcePresetFingerprint] = emission[\sourcePresetFingerprint];
        };
        trackingAdapter.perform(\project, emission, \toolEmission, projection);
        projectedEmissions.add(emission);
        ^emission;
    }

    publishEvent { |kind, payload, requestID, origin = \toolInstance|
        var envelope;

        eventSequence = eventSequence + 1;
        envelope = (
            schema: \awbToolInstanceEventV1,
            sequence: eventSequence,
            kind: kind,
            toolID: definition.id,
            toolVersion: definition.version,
            toolInstance: instanceID,
            configRevision: configRevision,
            wallTime: Date.getDate.asString,
            elapsedTime: Main.elapsedTime - openedElapsed,
            requestID: requestID,
            origin: origin,
            payload: payload
        );
        this.changed(\toolEvent, envelope);
        ^envelope;
    }

    objectIDFor { |object|
        if(object.respondsTo(\nodeID) and: { object.nodeID.notNil }) {
            ^("node:%".format(object.nodeID));
        };
        ^("object:%".format(object.identityHash));
    }

    configFingerprintFor { |configuration|
        ^[
            definition.id,
            definition.version,
            configuration
        ].asCompileString.hash.asString;
    }

    snapshot {
        ^(
            toolID: definition.id,
            toolVersion: definition.version,
            instanceID: instanceID,
            status: status,
            config: config.deepCopy,
            configRevision: configRevision,
            emissionCount: emissions.size,
            ownedObjectCount: ownedObjects.size,
            trackingAvailable: trackingAvailable,
            trackingEnabled: trackingEnabled,
            recordingState: recordingState,
            recordingPath: recordingPath,
            openedAt: openedAt,
            closedAt: closedAt,
            sourcePresetRef: if(sourcePresetRef.notNil) { sourcePresetRef.deepCopy } { nil },
            sourcePresetFingerprint: sourcePresetFingerprint
        );
    }

    tool {
        ^interfaceObject;
    }

    gui {
        ^guiObject;
    }

    applyPreset { |preset|
        var issue, previousRef, previousFingerprint;

        if(preset.isKindOf(ToolPreset).not) {
            Error("ToolInstance can only apply a ToolPreset").throw;
        };
        issue = preset.compatibilityErrorFor(this);
        if(issue.notNil) { Error(issue).throw };

        previousRef = sourcePresetRef;
        previousFingerprint = sourcePresetFingerprint;
        sourcePresetRef = preset.qualifiedRef.deepCopy;
        sourcePresetFingerprint = preset.fingerprint;

        try {
            interfaceObject.applyPresetConfig(
                preset.config.deepCopy,
                if(preset.selectedState.notNil) {
                    preset.selectedState.deepCopy
                } { nil }
            );
        } { |error|
            sourcePresetRef = previousRef;
            sourcePresetFingerprint = previousFingerprint;
            error.throw;
        };

        this.syncNodeManager;
        this.publishEvent(\presetApplied, (
            sourcePresetRef: sourcePresetRef.deepCopy,
            sourcePresetFingerprint: sourcePresetFingerprint,
            configRevision: configRevision,
            configFingerprint: this.configFingerprintFor(config)
        ));
        this.changed(\presetApplied, preset);
        ^this;
    }

    isPlaying {
        ^status != \closed and: { status != \failed };
    }

    name {
        ^definition.displayName ++ " [" ++ instanceID ++ "]";
    }
}
