ToolDefinition {
    var <id, <displayName, <version, <interfaceKind, <capabilities;
    var <defaultConfig, <emissionTypes, <dependencies, <multipleInstances;
    var <cleanupPolicy, <factory, <externalLauncher, <closeAction, <metadata;
    var <guiFactory, <guiCloseAction;

    *new { |id, displayName, version = "0.1.0", interfaceKind = \native,
        capabilities, defaultConfig, emissionTypes, dependencies,
        multipleInstances = true, cleanupPolicy = \terminateOwned,
        factory, externalLauncher, closeAction, metadata, guiFactory, guiCloseAction|

        ^super.newCopyArgs(
            id.asSymbol,
            displayName ? id.asString,
            version,
            interfaceKind,
            capabilities ? [],
            defaultConfig ? (),
            emissionTypes ? [],
            dependencies ? (),
            multipleInstances,
            cleanupPolicy,
            factory,
            externalLauncher,
            closeAction,
            metadata ? (),
            guiFactory,
            guiCloseAction
        ).init;
    }

    init {
        if([\native, \external, \either].includes(interfaceKind).not) {
            Error("ToolDefinition: invalid interface kind %".format(interfaceKind)).throw;
        };

        if([\terminateOwned, \releaseOwned, \leaveOwned].includes(cleanupPolicy).not) {
            Error("ToolDefinition: invalid cleanup policy %".format(cleanupPolicy)).throw;
        };

        if(interfaceKind == \native and: { factory.isKindOf(Function).not }) {
            Error("ToolDefinition: native tool % requires a factory".format(id)).throw;
        };

        if(interfaceKind == \external and: { externalLauncher.isKindOf(Function).not }) {
            Error("ToolDefinition: external tool % requires an allowlisted launcher".format(id)).throw;
        };

        capabilities = capabilities.asArray.collect(_.asSymbol);
        emissionTypes = emissionTypes.asArray.collect(_.asSymbol);
        defaultConfig = defaultConfig.copy;
        dependencies = dependencies.copy;
        metadata = metadata.copy;
    }

    supportsInterface { |requestedKind|
        requestedKind = requestedKind.asSymbol;
        ^(interfaceKind == \either) or: { interfaceKind == requestedKind };
    }

    acceptsEmission { |emissionType|
        ^emissionTypes.isEmpty or: { emissionTypes.includes(emissionType.asSymbol) };
    }

    open { |instance, options|
        var requestedKind, launcher;

        options = options ? ();
        requestedKind = options[\interfaceKind];
        if(requestedKind.isNil) {
            requestedKind = if(interfaceKind == \external) { \external } { \native };
        };
        requestedKind = requestedKind.asSymbol;

        if(this.supportsInterface(requestedKind).not) {
            Error("ToolDefinition % does not support % interfaces"
                .format(id, requestedKind)).throw;
        };

        launcher = if(requestedKind == \external) { externalLauncher } { factory };
        if(launcher.isKindOf(Function).not) {
            Error("ToolDefinition % has no % launcher"
                .format(id, requestedKind)).throw;
        };

        ^launcher.value(instance, instance.config, options);
    }

    close { |instance|
        if(closeAction.isKindOf(Function)) {
            closeAction.value(instance);
        };
    }

    openGUI { |instance, tool, options|
        var toolGUI;
        if(guiFactory.isKindOf(Function)) {
            toolGUI = guiFactory.value(instance, tool, options ? ());
            ^ToolGUIContract.validate(toolGUI, instance);
        };
        ^nil;
    }

    closeGUI { |instance, gui|
        if(gui.isNil) { ^this };
        if(guiCloseAction.isKindOf(Function)) {
            guiCloseAction.value(instance, gui);
        } {
            if(gui.respondsTo(\dispose)) { gui.dispose };
        };
        ^this;
    }
}
