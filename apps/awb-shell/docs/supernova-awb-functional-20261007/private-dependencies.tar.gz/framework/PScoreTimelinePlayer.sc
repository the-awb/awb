/*
PScoreTimelinePlayer
====================

Connector-aware extension of PTimelinePlayer. The base player remains the
small native absolute-time player; this subclass adds authored identity,
document revision, execution identity and transport anchors for hosted tools.

Envelope state at a time
------------------------
`SynthDefAnalysis.envelopesFor(defName, args)` rebuilds real `Env` objects
from a SynthDef's UGen graph, keyed by each EnvGen's `synthIndex`, with the
segment times resolved per event - so an attack written as
`beatEnvARatio * attackT`, or a release behind a `Select`, comes out as a
number rather than an assumption.

`SynthDefAnalysis.envValueAt(spec, age, gateOffAge)` evaluates one of them.
There is no curve maths: `Env:at` already evaluates natively through the
`Array:envAt` primitive. What `envValueAt` adds is the sustain, which
`Env:at` walks straight through - it is a runtime fact about the gate, not a
property of the shape. `gateOffAge` is nil while the gate is open.

Two things that catch people out, both covered by test/unit/18:

  - Envelopes in one def do NOT share a time course. `substrate`'s amp opens
    over `attackT` while its beat opens over `beatEnvARatio * attackT`, so a
    single scalar cannot stand in for them once time matters.
  - A def can hold gated and ungated envelopes at once. `resonantBassEnv2`'s
    `Env.triangle(dur)` ignores the gate entirely while its `asr` waits for
    it, so the horizon is per envelope, not per voice.

Background and the reasoning behind the design are in
Project documents/LIVE_CONTEXT_TOOL_NOTES.md, sections 9 and 10.

For smart seek specifically: a reconstruction currently RESTARTS a note, which
is a different question from where that note's envelopes had reached. The
`(env:, levelScale:, timeScale:, doneAction:)` spec above carries what is
needed to resume one mid-flight - `env.levels`, `env.times` and the segment
index at `age` give the truncated Env, and `envValueAt` gives the level to
start from.

Note also that `reconstructions` is not computed in sclang: it arrives over
OSC and `PTimelineOSCBridge` only normalises it. Anything needing the overlap
set on this side has to derive it from `timeline` entries' `time` + `dur`.
*/
PScoreTimelinePlayer : PTimelinePlayer {
    var <scoreID, <revision, <runID, <transportState;
    var <anchorHostTime, <anchorScoreTime, <playbackRate;
    var <realizationSerial;
    var <releasedRealizations, <endedRealizations;
    var <executionClock, <clockOrigin, <scoreOrigin;
    var <scheduledStartClockTime, <scheduledStartHostTime;
    var <pendingSeekPlan, <lastSeekReport;
    var <executionGeneration, <committedFrontier;
    var smartStreamPlan, smartStartTime;
    var clockCallback, scheduledStartToken;

    *new { |timeline, templateEvent, scoreID = "untitled", revision = 0|
        ^super.new(timeline, templateEvent)
            .initScoreTimelinePlayer(scoreID, revision);
    }

    initScoreTimelinePlayer { |newScoreID, newRevision|
        scoreID = newScoreID.asString;
        revision = newRevision.asInteger;
        runID = nil;
        transportState = \stopped;
        anchorHostTime = Main.elapsedTime;
        anchorScoreTime = currentTime ? 0.0;
        playbackRate = 1.0;
        realizationSerial = 0;
        releasedRealizations = Dictionary.new;
        endedRealizations = Set.new;
        executionClock = nil;
        clockOrigin = nil;
        scoreOrigin = anchorScoreTime;
        scheduledStartClockTime = nil;
        scheduledStartHostTime = nil;
        pendingSeekPlan = nil;
        lastSeekReport = nil;
        executionGeneration = 0;
        committedFrontier = 0.0;
        smartStreamPlan = nil;
        smartStartTime = nil;
        clockCallback = nil;
        scheduledStartToken = 0;
        ^this;
    }

    parseTimeline { |timelineArray|
        ^timelineArray.collect { |item, index|
            var entry, parsedTime, entryID, path, event, eventType, eventDuration;

            entry = item.copy;
            parsedTime = this.parseTimeStamp(item[\time]);
            entryID = item[\id] ? ("entry-" ++ index);
            path = item[\path] ? [];
            event = item[\event] ? ();
            eventType = event[\type].asSymbol;
            eventDuration = event[\dur];
            if(eventType == \note and: {
                eventDuration.isNil or: {
                    (eventDuration.asString == "inf").not and: {
                        eventDuration.isNumber.not or: {
                            eventDuration < 0
                        }
                    }
                }
            }) {
                Error("Score note % must declare a non-negative finite dur or \"inf\""
                    .format(entryID)).throw;
            };

            entry[\id] = entryID.asString;
            entry[\time] = parsedTime;
            entry[\path] = path.asArray.copy;
            entry[\event] = event.copy;
            entry;
        };
    }

    initializeData { |timelineArray|
        timeline = this.parseTimeline(timelineArray ? []);
        totalDuration = this.durationForTimeline(timeline);
        currentTime = 0;
    }

    durationForTimeline { |items|
        var lastDuration;
        if(items.isEmpty) { ^0.0 };
        lastDuration = items.last.event[\dur];
        ^items.last.time + if(lastDuration.asString == "inf") { 1 } {
            lastDuration ? 1
        };
    }

    scoreEntryAt { |index|
        if(index < 0 or: { index >= timeline.size }) { ^nil };
        ^timeline[index].copy;
    }

    beginRun {
        executionGeneration = executionGeneration + 1;
        runID = "%:%:%".format(scoreID, revision, UniqueID.next);
        realizationSerial = 0;
        releasedRealizations.clear;
        endedRealizations.clear;
        ^runID;
    }

    nextRealizationID { |entryID|
        realizationSerial = realizationSerial + 1;
        ^"%:%:%".format(runID, entryID, realizationSerial);
    }

    nodeManagerMetadata {
        ^super.nodeManagerMetadata.putAll((
            scoreID: scoreID,
            scoreRevision: revision,
            scoreRunID: runID,
            executionGeneration: executionGeneration
        ));
    }

    clockUnitsNow { |clock|
        var activeClock;

        activeClock = clock ? executionClock ? TempoClock.default;
        if(activeClock === SystemClock or: { activeClock === AppClock }) {
            ^Main.elapsedTime;
        };
        ^activeClock.beats;
    }

    clockRate { |clock|
        var activeClock;

        activeClock = clock ? executionClock;
        if(activeClock.notNil and: { activeClock.respondsTo(\tempo) }) {
            ^activeClock.tempo.asFloat;
        };
        ^1.0;
    }

    clockUnitsToHostTime { |clockUnits, clock|
        var activeClock;

        activeClock = clock ? executionClock;
        if(activeClock.notNil and: { activeClock.respondsTo(\beats2secs) }) {
            ^activeClock.beats2secs(clockUnits).asFloat;
        };
        ^clockUnits.asFloat;
    }

    attachExecutionClock { |clock|
        if(executionClock.notNil and: { clockCallback.notNil }) {
            executionClock.removeDependant(clockCallback);
        };
        executionClock = clock ? TempoClock.default;
        clockCallback = { |changedClock, what|
            if(what == \tempo and: {
                [\playing, \queued].includes(transportState)
            }) {
                playbackRate = this.clockRate(changedClock);
                this.notifyDependants(\transportChanged, this.transportAnchor);
            };
        };
        executionClock.addDependant(clockCallback);
        ^executionClock;
    }

    prepareClockStart { |position, quant|
        var quantSpec, startClockTime, nowClockTime, token;

        quantSpec = quant.asQuant;
        startClockTime = quantSpec.nextTimeOnGrid(executionClock);
        nowClockTime = this.clockUnitsNow(executionClock);
        scoreOrigin = position.asFloat;
        clockOrigin = startClockTime;
        scheduledStartClockTime = startClockTime;
        scheduledStartHostTime = this.clockUnitsToHostTime(
            startClockTime, executionClock
        );
        playbackRate = this.clockRate(executionClock);
        anchorHostTime = Main.elapsedTime;
        anchorScoreTime = scoreOrigin;
        currentTime = scoreOrigin;

        scheduledStartToken = scheduledStartToken + 1;
        token = scheduledStartToken;
        if(startClockTime > (nowClockTime + 0.0001)) {
            transportState = \queued;
            executionClock.schedAbs(startClockTime, {
                if(token == scheduledStartToken
                    and: { transportState == \queued }
                    and: { isPlaying }) {
                    this.setClockAnchor(\playing, scoreOrigin, startClockTime);
                    this.notifyDependants(\transportChanged, this.transportAnchor);
                };
                nil;
            });
        } {
            this.setClockAnchor(\playing, position, startClockTime);
        };
        ^this;
    }

    setClockAnchor { |state, position, originClockTime|
        transportState = state;
        scoreOrigin = position.asFloat;
        clockOrigin = originClockTime ? this.clockUnitsNow(executionClock);
        anchorHostTime = Main.elapsedTime;
        anchorScoreTime = scoreOrigin;
        playbackRate = this.clockRate(executionClock);
        currentTime = scoreOrigin;
        if(state != \queued) {
            scheduledStartClockTime = nil;
            scheduledStartHostTime = nil;
        };
        ^this;
    }

    createStreamFrom { |targetIndex|
        var targetTime, startIndex, events, callback, commitCallback;

        if(smartStreamPlan.notNil) {
            var plan;
            plan = smartStreamPlan;
            smartStreamPlan = nil;
            ^this.createSmartStream(plan);
        };

        if(timeline.isEmpty) { ^nil };
        if(targetIndex < 0 or: { targetIndex >= timeline.size }) { ^nil };

        targetTime = timeline[targetIndex].time;
        startIndex = targetIndex;
        events = [];

        timeline[startIndex..].do { |item, i|
            var delta, currentTimelineIndex, streamEvent, lastDuration, nextTime;

            currentTimelineIndex = startIndex + i;
            delta = if(currentTimelineIndex < (timeline.size - 1)) {
                timeline[currentTimelineIndex + 1].time - item.time;
            } {
                lastDuration = item.event[\dur];
                item.event[\delta]
                    ? if(lastDuration.asString == "inf") { 1 } { lastDuration }
                    ? item.event[\sustain]
                    ? 1;
            };
            nextTime = item.time + delta;

            streamEvent = item.event.copy;
            streamEvent[\delta] = delta;
            streamEvent[\__scoreID] = scoreID;
            streamEvent[\__scoreRevision] = revision;
            streamEvent[\__scoreRunID] = runID;
            streamEvent[\__scoreEntryID] = item.id;
            streamEvent[\__scorePath] = item.path.copy;
            streamEvent[\__scoreRealizationID] = this.nextRealizationID(item.id);
            streamEvent[\__scoreIndex] = currentTimelineIndex;
            streamEvent[\__scoreTime] = item.time;
            streamEvent[\__scoreNextTime] = nextTime;
            streamEvent[\__scoreExecutionGeneration] = executionGeneration;
            if(streamEvent[\type].asSymbol == \note
                and: { streamEvent[\dur].asString == "inf" }) {
                // Open score synths are still authored note entries, but their
                // lifetime is closed only by an explicit release/free command.
                // Prevent Event's normal delta/dur-derived gate-off scheduling
                // without hiding the SynthDef's actual gate capability. An
                // authored release command may still drive that gate later.
                streamEvent[\dur] = inf;
                streamEvent[\sendGate] = false;
            };
            if([\set, \release, \free].includes(streamEvent[\type])) {
                // set/release/free are authored score lifecycle commands, not
                // SuperCollider Event types. Unknown Event types fall back to
                // \note, which previously made a release entry spawn a default
                // synth. Keep scheduler timing, but execute the lifecycle command
                // explicitly against the score's realized note Events.
                streamEvent[\__scoreLifecycleType] = streamEvent[\type];
                streamEvent[\__scoreLifecycleControls] = this.lifecycleControlPairs(streamEvent);
                streamEvent[\type] = \rest;
                streamEvent[\callback] = { |scheduledEvent|
                    this.applyLifecycleEvent(scheduledEvent);
                };
            };
            events = events.add(streamEvent);
        };

        callback = { |event, streamIndex|
            var timelineIndex;
            timelineIndex = startIndex + streamIndex;
            this.addToHistory(event, timelineIndex);
        };

        commitCallback = { |event|
            this.streamItemCommitted(event);
        };

        ^PIndexedStream(events, callback, commitCallback);
    }

    streamItemCommitted { |event|
        var nextTime;
        nextTime = event[\__scoreNextTime];
        if(nextTime.notNil) {
            committedFrontier = nextTime.asFloat;
            this.notifyDependants(\transportChanged, this.transportAnchor);
        };
        ^event;
    }

    createFutureStream { |items, frontier, sourceRevision|
        var firstIndex, events, callback, commitCallback, firstTime;

        firstIndex = items.detectIndex { |item| item.time >= (frontier - 0.000001) }
            ? items.size;
        events = List.new;
        firstTime = if(firstIndex < items.size) { items[firstIndex].time } { nil };
        if(firstTime.notNil and: { firstTime > (frontier + 0.000001) }) {
            events.add((type: \rest, delta: firstTime - frontier)
                .put(\__scoreTime, frontier)
                .put(\__scoreNextTime, firstTime)
                .put(\__scoreRevision, sourceRevision)
                .put(\__scoreExecutionGeneration, executionGeneration)
                .put(\__scoreFrontierOnly, true));
        };

        if(firstIndex < items.size) {
            items[firstIndex..].do { |item, offset|
                var scoreIndex, delta, lastDuration, nextTime, streamEvent;
                scoreIndex = firstIndex + offset;
                delta = if(scoreIndex < (items.size - 1)) {
                    items[scoreIndex + 1].time - item.time
                } {
                    lastDuration = item.event[\dur];
                    item.event[\delta]
                        ? if(lastDuration.asString == "inf") { 1 } { lastDuration }
                        ? item.event[\sustain]
                        ? 1;
                };
                nextTime = item.time + delta;
                streamEvent = item.event.copy;
                streamEvent[\delta] = delta;
                streamEvent[\__scoreID] = scoreID;
                streamEvent[\__scoreRevision] = sourceRevision;
                streamEvent[\__scoreRunID] = runID;
                streamEvent[\__scoreEntryID] = item.id;
                streamEvent[\__scorePath] = item.path.copy;
                streamEvent[\__scoreRealizationID] = this.nextRealizationID(item.id);
                streamEvent[\__scoreIndex] = scoreIndex;
                streamEvent[\__scoreTime] = item.time;
                streamEvent[\__scoreNextTime] = nextTime;
                streamEvent[\__scoreExecutionGeneration] = executionGeneration;
                if(streamEvent[\type].asSymbol == \note
                    and: { streamEvent[\dur].asString == "inf" }) {
                    streamEvent[\dur] = inf;
                    streamEvent[\sendGate] = false;
                };
                if([\set, \release, \free].includes(streamEvent[\type])) {
                    streamEvent[\__scoreLifecycleType] = streamEvent[\type];
                    streamEvent[\__scoreLifecycleControls] = this.lifecycleControlPairs(streamEvent);
                    streamEvent[\type] = \rest;
                    streamEvent[\callback] = { |scheduledEvent|
                        this.applyLifecycleEvent(scheduledEvent);
                    };
                };
                events.add(streamEvent);
            };
        };

        callback = { |event|
            var scoreIndex;
            scoreIndex = event[\__scoreIndex];
            if(scoreIndex.notNil) { this.addToHistory(event, scoreIndex) };
        };
        commitCallback = { |event| this.streamItemCommitted(event) };
        ^PIndexedStream(events.asArray, callback, commitCallback);
    }

    createSmartStream { |plan|
        var target, futureIndex, futureStream, futureEvents, reconstructions;
        var events, firstFutureTime, callback, commitCallback;

        target = plan[\target].asFloat;
        futureIndex = timeline.detectIndex { |item| item.time >= target } ? timeline.size;
        futureStream = if(futureIndex < timeline.size) { this.createStreamFrom(futureIndex) } { nil };
        futureEvents = if(futureStream.notNil) { futureStream.events.copy } { [] };
        reconstructions = plan[\reconstructions] ? [];
        events = List.new;
        firstFutureTime = if(futureIndex < timeline.size) { timeline[futureIndex].time } { nil };
        if(reconstructions.isEmpty and: {
            firstFutureTime.notNil and: { firstFutureTime > target }
        }) {
            events.add((type: \rest, delta: firstFutureTime - target)
                .put(\__scoreTime, target)
                .put(\__scoreNextTime, firstFutureTime)
                .put(\__scoreRevision, revision)
                .put(\__scoreExecutionGeneration, executionGeneration)
                .put(\__scoreFrontierOnly, true));
        };
        reconstructions.do { |item, index|
            var event, remaining, delta;
            event = item[\event].copy;
            remaining = item[\remainingGate] ? item[\remainingRelease] ? 0.01;
            delta = if(index < (reconstructions.size - 1)) { 0 } {
                if(firstFutureTime.notNil) { (firstFutureTime - target).max(0) } { remaining.max(0.01) }
            };
            event[\delta] = delta;
            event[\__scoreID] = scoreID;
            event[\__scoreRevision] = revision;
            event[\__scoreRunID] = runID;
            event[\__scoreEntryID] = item[\entryID].asString;
            event[\__scorePath] = [];
            event[\__scoreRealizationID] = this.nextRealizationID(item[\entryID]);
            event[\__scoreIndex] = futureIndex;
            event[\__scoreTime] = target;
            event[\__scoreNextTime] = target + delta;
            event[\__scoreExecutionGeneration] = executionGeneration;
            event[\__scoreReconstructionQuality] = item[\quality].asSymbol;
            event[\__scoreReconstructionPhase] = item[\phase].asSymbol;
            if(item[\phase].asSymbol == \release) {
                event[\sustain] = 0;
                event[\sendGate] = true;
            };
            if(event[\dur].asString == "inf") {
                event[\dur] = inf;
                event[\sendGate] = false;
            };
            events.add(event);
        };
        events.addAll(futureEvents);
        if(events.isEmpty) { ^nil };

        callback = { |event, streamIndex|
            var scoreIndex;
            scoreIndex = event[\__scoreIndex];
            if(scoreIndex.notNil and: { scoreIndex < timeline.size }) {
                this.addToHistory(event, scoreIndex);
            };
        };
        commitCallback = { |event| this.streamItemCommitted(event) };
        ^PIndexedStream(events.asArray, callback, commitCallback);
    }

    lifecycleTargets { |event|
        var requested, active, matched;

        requested = event[\target] ? "@prev";
        // Strings are ArrayedCollections in SuperCollider. Do not mistake a
        // single JSON target ID for a collection of one-character targets.
        requested = if(requested.isArray and: { requested.class != String }) {
            requested
        } {
            [requested]
        };
        active = this.currentStreamEvents.select { |candidate|
            candidate[\__scoreEntryID].notNil
        };
        matched = List.new;
        requested.do { |target|
            var targetString, targetKey, candidate;
            targetString = target.asString;
            targetKey = targetString.asSymbol;
            if(targetKey == "@all".asSymbol) {
                active.do { |item|
                    if(matched.includes(item).not) { matched.add(item) };
                };
            } {
                if(targetKey == "@prev".asSymbol) {
                    candidate = active.last;
                    if(candidate.notNil and: { matched.includes(candidate).not }) {
                        matched.add(candidate);
                    };
                } {
                    active.do { |item|
                        if(item[\__scoreEntryID].asString.asSymbol == targetKey and: {
                            matched.includes(item).not
                        }) {
                            matched.add(item);
                        };
                    };
                };
            };
        };
        ^matched.asArray;
    }

    lifecycleControlPairs { |event|
        var excluded, pairs;

        excluded = #[
            type, target, delta, callback,
            \__scoreLifecycleType, \__scoreLifecycleControls,
            \__scoreID, \__scoreRevision, \__scoreRunID,
            \__scoreEntryID, \__scorePath, \__scoreRealizationID,
            \__scoreIndex, \__scoreTime
        ];
        pairs = List.new;
        event.keysValuesDo { |key, value|
            if(excluded.includes(key).not) {
                pairs.add(key);
                pairs.add(value);
            };
        };
        ^pairs.asArray;
    }

    setLifecycleTarget { |target, controls|
        var server, nodeIDs;

        server = target[\server] ? Server.default;
        nodeIDs = target[\id].asArray;
        nodeIDs.do { |nodeID, voiceIndex|
            var voiceControls;
            voiceControls = List.new;
            controls.pairsDo { |key, value|
                if(value.isArray and: { value.class != String }) {
                    value = value.wrapAt(voiceIndex);
                };
                voiceControls.add(key);
                voiceControls.add(value);
            };
            server.sendBundle(server.latency,
                ["/n_set", nodeID] ++ voiceControls.asArray);
        };
        ^target;
    }

    applyLifecycleEvent { |event|
        var lifecycleType, targets, controls, releaseTime;

        lifecycleType = event[\__scoreLifecycleType];
        targets = this.lifecycleTargets(event);
        switch(lifecycleType,
            \set, {
                // The scheduled rest Event inherits its prototype environment.
                // Use the control pairs captured from the authored command
                // before that merge, never the runtime Event's server/state.
                controls = event[\__scoreLifecycleControls] ? [];
                if(controls.notEmpty) {
                    targets.do { |target| this.setLifecycleTarget(target, controls) };
                };
            },
            \release, {
                releaseTime = event[\releaseTime];
                targets.do { |target|
                    // Open-ended score notes suppress Event's automatic gate
                    // message with sendGate=false. Restore the discovered
                    // SynthDef capability for this explicit authored release.
                    target[\sendGate] = target[\hasGate];
                    target.release(releaseTime);
                };
            },
            \free, { targets.do(_.free) },
            {
                ("PScoreTimelinePlayer: unsupported lifecycle type %"
                    .format(lifecycleType)).warn;
            }
        );
        ^event;
    }

    play { |clock, quant, index|
        var wasPlaying, result, startTime, activeClock, plan;

        wasPlaying = isPlaying;
        if(wasPlaying and: { index.isNil }) {
            ^super.play(clock, quant, index);
        };

        if(timeline.isEmpty) {
            "PScoreTimelinePlayer: Cannot play an empty score".warn;
            ^this;
        };
        if(index.notNil and: { this.eventAtIndex(index).isNil }) {
            ("PScoreTimelinePlayer: play(index: %) out of range").format(index).warn;
            ^this;
        };

        activeClock = this.attachExecutionClock(clock ? TempoClock.default);
        plan = pendingSeekPlan;
        if(plan.notNil) {
            pendingSeekPlan = nil;
            smartStreamPlan = plan;
            smartStartTime = plan[\target].asFloat;
            startIndex = timeline.detectIndex { |item| item.time >= smartStartTime } ? timeline.size;
            currentIndex = startIndex - (plan[\reconstructions] ? []).size;
        };
        this.beginRun;
        committedFrontier = smartStartTime ?? {
            if(index.notNil) { timeline[index].time } { timeline[startIndex].time }
        };
        result = super.play(activeClock, quant, index);
        if(isPlaying) {
            startTime = smartStartTime ?? {
                if(index.notNil) {
                    timeline[index].time
                } {
                    timeline[startIndex].time
                }
            };
            smartStartTime = nil;
            this.prepareClockStart(startTime, quant);
            this.notifyDependants(\transportChanged, this.transportAnchor);
        } {
            runID = nil;
        };
        ^result;
    }

    smartJumpToTime { |plan|
        var target, wasPlaying, wasPaused, reconstructed, skipped;

        target = plan[\target].asFloat;
        if(target < 0 or: { target > totalDuration }) {
            Error("PScoreTimelinePlayer: smart seek out of range").throw;
        };
        wasPlaying = isPlaying;
        wasPaused = transportState == \paused;
        scheduledStartToken = scheduledStartToken + 1;
        if(currentPlayer.notNil) { currentPlayer.stopAll };
        currentPlayer = nil;
        isPlaying = false;
        pendingSeekPlan = plan;
        reconstructed = (plan[\reconstructions] ? []).size;
        skipped = (plan[\skipped] ? []).size;
        lastSeekReport = (
            mode: \smart, target: target,
            reconstructed: reconstructed, skipped: skipped
        );
        this.setTransportAnchor(\stopped, target);
        if(wasPlaying) { this.play(executionClock ? TempoClock.default, 0) } {
            if(wasPaused) { transportState = \stopped };
            this.notifyDependants(\transportChanged, this.transportAnchor);
        };
        ^lastSeekReport;
    }

    pause {
        var position;

        position = this.currentScoreTime;
        super.pause;
        if(isPlaying.not and: { currentPlayer.notNil }) {
            this.setTransportAnchor(\paused, position);
            this.notifyDependants(\transportChanged, this.transportAnchor);
        };
        ^this;
    }

    resume { |clock, quant|
        var result, activeClock;

        activeClock = executionClock ? clock ? TempoClock.default;
        if(clock.notNil and: { executionClock.notNil } and: {
            clock !== executionClock
        }) {
            "PScoreTimelinePlayer: resume retains the clock used for play".warn;
        };
        if(executionClock.isNil) { this.attachExecutionClock(activeClock) };
        result = super.resume(executionClock, quant);
        if(isPlaying) {
            this.prepareClockStart(anchorScoreTime, quant);
            this.notifyDependants(\transportChanged, this.transportAnchor);
        };
        ^result;
    }

    stop {
        var position;

        position = this.currentScoreTime;
        scheduledStartToken = scheduledStartToken + 1;
        super.stop;
        this.setTransportAnchor(\stopped, position);
        this.notifyDependants(\transportChanged, this.transportAnchor);
        ^this;
    }

    stopAll {
        var position;

        position = this.currentScoreTime;
        scheduledStartToken = scheduledStartToken + 1;
        super.stopAll;
        this.setTransportAnchor(\stopped, position);
        this.notifyDependants(\transportChanged, this.transportAnchor);
        ^this;
    }

    jumpToTime { |targetTime|
        var parsedTime, targetIndex, resolvedTime, wasPlaying, wasPaused;

        pendingSeekPlan = nil;
        smartStreamPlan = nil;
        smartStartTime = nil;
        lastSeekReport = nil;
        parsedTime = this.parseTimeStamp(targetTime);
        if(parsedTime < 0 or: { parsedTime > totalDuration }) {
            "PScoreTimelinePlayer: jumpToTime out of range (0 to %)"
                .format(totalDuration).warn;
            ^this;
        };
        if(timeline.isEmpty) { ^this };

        targetIndex = this.findIndexForTime(parsedTime);
        resolvedTime = timeline[targetIndex].time;
        wasPlaying = isPlaying;
        wasPaused = transportState == \paused;
        scheduledStartToken = scheduledStartToken + 1;
        if(currentPlayer.notNil) { currentPlayer.stopAll };

        startIndex = targetIndex;
        currentIndex = targetIndex;
        currentTime = resolvedTime;
        if(wasPlaying) {
            this.createAndStartPlayer;
            if(currentPlayer.notNil) {
                this.setupStreamEndDetection;
                currentPlayer.play(executionClock ? TempoClock.default, false, 0);
                isPlaying = true;
                this.setClockAnchor(
                    \playing,
                    resolvedTime,
                    this.clockUnitsNow(executionClock)
                );
                NodeManager.register(this, \streamPlayer, this.nodeManagerMetadata);
            };
        } {
            currentPlayer = nil;
            isPlaying = false;
            // Seeking away from a paused realization frees those nodes. The
            // next Play therefore starts a fresh run from the sought boundary;
            // it must not attempt to resume the now-discarded stream player.
            this.setTransportAnchor(if(wasPaused) { \stopped } { transportState }, resolvedTime);
        };
        this.notifyDependants(\transportChanged, this.transportAnchor);
        ^this;
    }

    addToHistory { |event, scoreIndex|
        var entry, eventTime, eventEntryID;

        entry = timeline[scoreIndex];
        eventTime = event[\__scoreTime] ? entry.time;
        eventEntryID = event[\__scoreEntryID] ? entry.id;
        currentTime = eventTime;
        this.setClockAnchor(
            if(isPlaying) { \playing } { transportState },
            currentTime,
            this.clockUnitsNow(executionClock)
        );
        super.addToHistory(event, scoreIndex);
        this.notifyDependants(\scoreEntryScheduled, (
            scoreID: scoreID,
            revision: event[\__scoreRevision] ? revision,
            runID: runID,
            entryID: eventEntryID,
            realizationID: event[\__scoreRealizationID],
            scoreIndex: scoreIndex,
            scoreTime: eventTime,
            executionGeneration: event[\__scoreExecutionGeneration] ? executionGeneration,
            event: event
        ));
    }

    activeRealizationFor { |realizationID|
        ^this.currentStreamEvents.detect { |event|
            event[\__scoreRealizationID].asString == realizationID.asString
        };
    }

    controlRealization { |expectedRunID, realizationID, action, releaseTime = 0, targetNodeID = -1|
        var event, nodeIDs, server, latency, messages, state;

        if(runID.isNil or: { expectedRunID.asString != runID.asString }) {
            ^(ok: false, code: \staleRun, realizationID: realizationID.asString);
        };
        if(endedRealizations.includes(realizationID.asString)) {
            ^(ok: false, code: \alreadyEnded, realizationID: realizationID.asString);
        };
        if(action == \release) {
            ^this.releaseRealization(expectedRunID, realizationID, releaseTime, targetNodeID);
        };
        if([\pause, \resume, \free].includes(action).not) {
            ^(ok: false, code: \unknownAction, realizationID: realizationID.asString);
        };

        event = this.activeRealizationFor(realizationID);
        if(event.isNil) {
            ^(ok: false, code: \unknownRealization,
                realizationID: realizationID.asString);
        };
        nodeIDs = (event[\id] ? []).asArray;
        if(nodeIDs.isEmpty) {
            ^(ok: false, code: \missingNodes, realizationID: realizationID.asString);
        };
        if(targetNodeID.asInteger >= 0) {
            if(nodeIDs.includes(targetNodeID.asInteger).not) {
                ^(ok: false, code: \unknownNode, realizationID: realizationID.asString);
            };
            nodeIDs = [targetNodeID.asInteger];
        };
        server = event[\server] ? Server.default;
        latency = server.latency ? 0.2;
        switch(action,
            \pause, {
                messages = nodeIDs.collect { |nodeID| ['/n_run', nodeID, 0] };
                server.sendBundle(latency, *messages);
                state = \paused;
            },
            \resume, {
                messages = nodeIDs.collect { |nodeID| ['/n_run', nodeID, 1] };
                server.sendBundle(latency, *messages);
                state = \running;
            },
            \free, {
                messages = nodeIDs.collect { |nodeID| ['/n_free', nodeID] };
                server.sendBundle(latency, *messages);
                state = \ending;
            }
        );
        ^(
            ok: true,
            code: \applied,
            state: state,
            scoreID: scoreID,
            revision: revision,
            runID: runID,
            realizationID: realizationID.asString,
            event: event
        );
    }

    setRealization { |expectedRunID, realizationID, controlName, declaredWidth, values, targetNodeID = -1|
        var event, nodeIDs, synthLib, synthDesc, control, server, latency, messages;

        if(runID.isNil or: { expectedRunID.asString != runID.asString }) {
            ^(ok: false, code: \staleRun, realizationID: realizationID.asString);
        };
        if(endedRealizations.includes(realizationID.asString)) {
            ^(ok: false, code: \alreadyEnded, realizationID: realizationID.asString);
        };
        event = this.activeRealizationFor(realizationID);
        if(event.isNil) {
            ^(ok: false, code: \unknownRealization, realizationID: realizationID.asString);
        };
        nodeIDs = (event[\id] ? []).asArray;
        if(nodeIDs.isEmpty) {
            ^(ok: false, code: \missingNodes, realizationID: realizationID.asString);
        };
        if(targetNodeID.asInteger >= 0) {
            if(nodeIDs.includes(targetNodeID.asInteger).not) {
                ^(ok: false, code: \unknownNode, realizationID: realizationID.asString);
            };
            nodeIDs = [targetNodeID.asInteger];
        };
        synthLib = event[\synthLib] ? SynthDescLib.global;
        synthDesc = synthLib.at(event[\instrument].asSymbol);
        if(synthDesc.isNil) { ^(ok: false, code: \missingSynthDesc) };
        control = synthDesc.controls.detect { |item|
            item.name.asSymbol == controlName.asSymbol
        };
        if(control.isNil) { ^(ok: false, code: \unknownControl) };
        if(control.numChannels.asInteger != declaredWidth.asInteger) {
            ^(ok: false, code: \staleControlWidth);
        };
        if(values.isEmpty or: { values.size > 256 }) {
            ^(ok: false, code: \invalidValues);
        };
        if(declaredWidth.asInteger > 1 and: { values.size != declaredWidth.asInteger }) {
            ^(ok: false, code: \invalidValues);
        };
        server = event[\server] ? Server.default;
        latency = server.latency ? 0.2;
        messages = if(declaredWidth.asInteger == 1) {
            nodeIDs.collect { |nodeID, index|
                ['/n_set', nodeID, controlName.asSymbol, values.wrapAt(index)]
            }
        } {
            nodeIDs.collect { |nodeID|
                ['/n_setn', nodeID, controlName.asSymbol, values.size] ++ values
            }
        };
        server.sendBundle(latency, *messages);
        ^(ok: true, code: \applied, realizationID: realizationID.asString, event: event);
    }

    releaseRealization { |expectedRunID, realizationID, releaseTime, targetNodeID = -1|
        var event, released, data, synthLib, synthDesc, instrument;
        var server, latency, releaseArgument, nodeIDs, gateValue;

        if(runID.isNil or: { expectedRunID.asString != runID.asString }) {
            ^(ok: false, code: \staleRun, realizationID: realizationID.asString);
        };
        if(endedRealizations.includes(realizationID.asString)) {
            ^(ok: false, code: \alreadyEnded, realizationID: realizationID.asString);
        };
        data = releasedRealizations[realizationID.asString];
        if(data.notNil) {
            ^data.copy.put(\ok, true).put(\code, \alreadyReleased);
        };

        event = this.activeRealizationFor(realizationID);
        if(event.isNil) {
            ^(ok: false, code: \unknownRealization,
                realizationID: realizationID.asString);
        };
        instrument = event[\instrument];
        synthLib = event[\synthLib] ? SynthDescLib.global;
        synthDesc = if(instrument.notNil) {
            synthLib.at(instrument.asDefName)
        };
        if(synthDesc.isNil) {
            ^(ok: false, code: \releaseCapabilityUnknown,
                realizationID: realizationID.asString);
        };
        if(synthDesc.hasGate.not or: {
            NodeManager.supportsControl(event, \release).not
        }) {
            ^(ok: false, code: \notReleasable,
                realizationID: realizationID.asString);
        };

        server = event[\server] ? Server.default;
        latency = server.latency ? 0.2;
        releaseArgument = if(releaseTime.asFloat > 0) { releaseTime } { nil };
        released = true;
        if(targetNodeID.asInteger >= 0) {
            nodeIDs = (event[\id] ? []).asArray;
            if(nodeIDs.includes(targetNodeID.asInteger).not) {
                ^(ok: false, code: \unknownNode, realizationID: realizationID.asString);
            };
            gateValue = if(releaseTime.asFloat > 0) { -1 - releaseTime.asFloat } { 0 };
            server.sendBundle(latency, ['/n_set', targetNodeID.asInteger, \gate, gateValue]);
        } {
            SystemClock.sched(latency, {
                if(NodeManager.releaseObject(event, releaseArgument).not) {
                    "PScoreTimelinePlayer: scheduled realization release failed".warn;
                };
                nil;
            });
        };

        data = (
            ok: true,
            code: \released,
            scoreID: scoreID,
            revision: revision,
            runID: runID,
            entryID: event[\__scoreEntryID],
            realizationID: event[\__scoreRealizationID],
            scoreIndex: event[\__scoreIndex],
            scoreTime: event[\__scoreTime],
            releaseTime: releaseTime,
            targetNodeID: targetNodeID,
            event: event
        );
        if(targetNodeID.asInteger < 0) {
            releasedRealizations[realizationID.asString] = data;
        };
        this.notifyDependants(\scoreRealizationReleased, data);
        ^data;
    }

    onNodeEnd { |finishedEvent|
        var realizationID;

        realizationID = finishedEvent[\__scoreRealizationID];
        if(realizationID.notNil) {
            endedRealizations.add(realizationID.asString);
        };
        NodeManager.notifyObservers(\scoreRealizationEnded, (
            streamPlayer: this,
            event: finishedEvent
        ));
        super.onNodeEnd(finishedEvent);
    }

    checkIfFullyFinished {
        var wasPlaying;

        wasPlaying = isPlaying;
        super.checkIfFullyFinished;
        if(wasPlaying and: { isPlaying.not } and: { isStreamExhausted }) {
            scheduledStartToken = scheduledStartToken + 1;
            this.setTransportAnchor(\stopped, totalDuration);
            this.notifyDependants(\transportChanged, this.transportAnchor);
        };
    }

    setTransportAnchor { |state, position, rate|
        transportState = state;
        anchorHostTime = Main.elapsedTime;
        anchorScoreTime = position.asFloat;
        playbackRate = rate ? this.clockRate(executionClock);
        scoreOrigin = anchorScoreTime;
        clockOrigin = this.clockUnitsNow(executionClock);
        scheduledStartClockTime = nil;
        scheduledStartHostTime = nil;
        currentTime = anchorScoreTime;
        ^this;
    }

    currentScoreTime {
        if(transportState == \queued) { ^scoreOrigin };
        if(transportState == \playing and: { isPlaying }) {
            ^(scoreOrigin
                + (this.clockUnitsNow(executionClock) - clockOrigin))
                .clip(0, totalDuration);
        };
        ^anchorScoreTime.clip(0, totalDuration);
    }

    transportAnchor {
        ^(
            scoreID: scoreID,
            revision: revision,
            runID: runID,
            hostMonotonicTime: Main.elapsedTime,
            scorePosition: this.currentScoreTime,
            rate: playbackRate,
            state: transportState,
            currentIndex: currentIndex,
            executionGeneration: executionGeneration,
            committedFrontier: committedFrontier,
            clockClass: (executionClock ? TempoClock.default).class.name,
            scheduledStartHostTime: scheduledStartHostTime
        );
    }

    replaceFuture { |newTimeline, newRevision, expectedRevision,
        expectedGeneration, expectedFrontier|
        var parsed, frontier, nextIndex, replacement, previousRevision;
        var deferredPastCount;

        if(expectedRevision.notNil and: { expectedRevision.asInteger != revision }) {
            ^(
                ok: false, error: \revisionConflict,
                expectedRevision: expectedRevision.asInteger,
                actualRevision: revision
            );
        };
        if(expectedGeneration.notNil and: {
            expectedGeneration.asInteger != executionGeneration
        }) {
            ^(
                ok: false, error: \generationConflict,
                expectedGeneration: expectedGeneration.asInteger,
                actualGeneration: executionGeneration
            );
        };
        frontier = committedFrontier.asFloat;
        if(expectedFrontier.notNil and: {
            (expectedFrontier.asFloat - frontier).abs > 0.000001
        }) {
            ^(
                ok: false, error: \frontierConflict,
                expectedFrontier: expectedFrontier.asFloat,
                actualFrontier: frontier
            );
        };
        if(newRevision.asInteger < revision) {
            ^(
                ok: false, error: \staleRevision,
                incomingRevision: newRevision.asInteger,
                actualRevision: revision
            );
        };
        if(newRevision.asInteger == revision) {
            ^(
                ok: true, code: \alreadyCurrent,
                scoreID: scoreID, revision: revision,
                executionGeneration: executionGeneration,
                committedFrontier: frontier
            );
        };
        if(currentPlayer.isNil or: { runID.isNil } or: {
            [\playing, \paused, \queued].includes(transportState).not
        }) {
            ^this.replaceScore(newTimeline, newRevision, expectedRevision);
        };

        parsed = this.parseTimeline(newTimeline ? []);
        deferredPastCount = parsed.count { |item| item.time < (frontier - 0.000001) };
        previousRevision = revision;
        executionGeneration = executionGeneration + 1;
        replacement = this.createFutureStream(parsed, frontier, newRevision.asInteger);
        currentPlayer.stream_(replacement);
        timeline = parsed;
        totalDuration = this.durationForTimeline(timeline);
        revision = newRevision.asInteger;
        nextIndex = timeline.detectIndex { |item| item.time >= (frontier - 0.000001) }
            ? timeline.size;
        startIndex = nextIndex;
        currentIndex = nextIndex;
        NodeManager.register(this, \streamPlayer, this.nodeManagerMetadata);
        this.notifyDependants(\scoreFutureReplaced, (
            scoreID: scoreID,
            previousRevision: previousRevision,
            revision: revision,
            runID: runID,
            executionGeneration: executionGeneration,
            committedFrontier: frontier,
            deferredPastCount: deferredPastCount
        ));
        this.notifyDependants(\transportChanged, this.transportAnchor);
        ^(
            ok: true, code: \futureReplaced,
            scoreID: scoreID, revision: revision, runID: runID,
            executionGeneration: executionGeneration,
            committedFrontier: frontier,
            deferredPastCount: deferredPastCount
        );
    }

    replaceScore { |newTimeline, newRevision, expectedRevision|
        var wasPlaying;

        if(expectedRevision.notNil and: { expectedRevision.asInteger != revision }) {
            ^(
                ok: false,
                error: \revisionConflict,
                expectedRevision: expectedRevision.asInteger,
                actualRevision: revision
            );
        };

        if(newRevision.asInteger < revision) {
            ^(
                ok: false, error: \staleRevision,
                incomingRevision: newRevision.asInteger,
                actualRevision: revision
            );
        };
        if(newRevision.asInteger == revision) {
            ^(ok: true, code: \alreadyCurrent,
                scoreID: scoreID, revision: revision);
        };

        wasPlaying = isPlaying;
        if(currentPlayer.notNil) { this.stopAll };
        this.initializeData(newTimeline);
        revision = newRevision.asInteger;
        executionGeneration = executionGeneration + 1;
        committedFrontier = 0.0;
        runID = nil;
        realizationSerial = 0;
        releasedRealizations.clear;
        endedRealizations.clear;
        pendingSeekPlan = nil;
        lastSeekReport = nil;
        this.setTransportAnchor(\stopped, 0.0);
        this.notifyDependants(\scoreReplaced, (
            scoreID: scoreID,
            revision: revision,
            entryCount: timeline.size,
            wasPlaying: wasPlaying
        ));
        ^(ok: true, scoreID: scoreID, revision: revision);
    }
}
