// ToolInstanceControls
//
// The strip every ToolGUI carries - ToolGUIContract requires an
// `instanceControls`, so this is the one piece genuinely shared across tool
// windows rather than reimplemented in each.
//
// It answers three things a tool window otherwise cannot:
//
//   NodeManager   is this instance tracked, is it recording, where is the take
//   context         which harmonic context is this tool reading through
//   authority     may it SET that context, and is that context the live one
//
// The last two come from spec 8C. A tool showing only which context it is
// looking at is how a composer ends up exploring a candidate scale believing
// they are reading the piece - and a tool that cannot see it is read-only
// will keep offering edits that silently do nothing.
ToolInstanceControls {
    var <instance, <view, <trackButton, <recordButton, <pathLabel;
    var <contextLabel;
    var contextWatcher;
    var <promoteSnapshotButton, <promoteSelectionButton;
    var <closeButton, <loadPresetButton, <presetDialog;
    var callback, updating, promoteSnapshotAction, promoteSelectionAction;
    var toolPresetLibrary;

    *new { |parent, bounds, instance, promoteSnapshotAction, promoteSelectionAction,
        toolPresetLibrary|
        ^super.new.init(parent, bounds, instance,
            promoteSnapshotAction, promoteSelectionAction, toolPresetLibrary);
    }

    init { |parent, bounds, anInstance, snapshotAction, selectionAction, aLibrary|
        instance = anInstance;
        promoteSnapshotAction = snapshotAction;
        promoteSelectionAction = selectionAction;
        toolPresetLibrary = aLibrary ? ToolPresets.default;
        updating = false;
        view = View(parent, bounds);
        StaticText(view, Rect(0, 2, 48, 22)).string_("Instance");
        trackButton = Button(view, Rect(52, 0, 78, 26))
            .states_([["Track"], ["Tracked"]])
            .action_({ |button| this.setTracking(button.value == 1) });
        recordButton = Button(view, Rect(138, 0, 82, 26))
            .states_([["Record"], ["Recording"]])
            .action_({ |button| this.setRecording(button.value == 1) });
        pathLabel = StaticText(view, Rect(228, 2, bounds.width - 364, 22))
            .stringColor_(Color.gray(0.35));
        loadPresetButton = Button(view, Rect(bounds.width - 128, 0, 128, 26))
            .states_([["Load preset..."]])
            .action_({ this.openPresetLoader });
        promoteSnapshotButton = Button(view, Rect(52, 30, 150, 26))
            .states_([["Promote snapshot"]])
            .action_({ this.promoteSnapshot });
        promoteSelectionButton = Button(view, Rect(210, 30, 150, 26))
            .states_([["Promote selection"]])
            .action_({ this.promoteSelection });
        closeButton = Button(view, Rect(bounds.width - 78, 30, 78, 26))
            .states_([["Close"]])
            .action_({ instance.close });
        // The harmonic context can change from ANY window, so this row has to
        // follow the registry rather than only this instance.
        contextLabel = StaticText(view, Rect(52, 60, max(120, bounds.width - 52), 22))
            .font_(Font("Monaco", 10))
            .stringColor_(Color.gray(0.3));
        contextWatcher = { |object, what| { this.refresh }.defer };
        try { HarmonicContext.addDependant(contextWatcher) } { contextWatcher = nil };
        callback = { |object, what|
            if([\opened, \trackingChanged, \trackingUnavailable, \recordingChanged,
                \recordingFailed, \presetApplied, \closed].includes(what)) {
                { this.refresh }.defer;
            };
        };
        instance.addDependant(callback);
        toolPresetLibrary.addObserver(this);
        this.refresh;
        ^this;
    }

    // Which context this tool reads through, and on what authority.
    //
    // A tool that names a `context` is asked directly; otherwise the registry is
    // asked what this tool holds. A tool with neither simply has no harmonic
    // context, and says so rather than leaving the row blank - blank reads as
    // "nothing to report" when it means "not answered".
    contextSummary {
        var tool, context, out;
        tool = instance.tool;
        if(tool.isNil) { ^"no tool attached" };
        context = if(tool.respondsTo(\harmonicContext)) {
            tool.harmonicContext
        } {
            HarmonicContext.heldBy(tool).first;
        };
        if(context.isNil) { ^"context: none - this tool has no harmonic context" };
        out = "context: " ++ context.name ++ " (" ++ context.kind ++ ")  " ++ context.anchor ++ " Hz";
        if(tool.respondsTo(\isMaster)) {
            out = out ++ if(tool.isMaster) { "   master" } { "   READ ONLY" };
        };
        // Stated separately from the name, because looking at a context and
        // that context governing the composition are independent facts.
        out = out ++ if(context.isPromoted) {
            "   · ACTIVE CONTEXT"
        } {
            "   · held, not live"
        };
        ^out;
    }

    setTracking { |enabled|
        if(updating) { ^this };
        try {
            instance.setTracking(enabled);
        } { |error|
            pathLabel.string_(error.errorString);
        };
        this.refresh;
        ^this;
    }

    setRecording { |enabled|
        if(updating) { ^this };
        try {
            if(enabled) { instance.startRecording } { instance.stopRecording };
        } { |error|
            pathLabel.string_(error.errorString);
        };
        this.refresh;
        ^this;
    }

    promoteSnapshot {
        var candidate;
        try {
            candidate = instance.interfaceData(\promotionCandidate);
            if(promoteSnapshotAction.notNil) {
                promoteSnapshotAction.value(candidate.deepCopy);
            };
            this.changed(\promotionRequested, (
                kind: \snapshot,
                candidate: candidate.deepCopy
            ));
        } { |error|
            pathLabel.string_(error.errorString);
        };
        ^candidate;
    }

    promoteSelection {
        var candidate;
        try {
            candidate = if(instance.tool.respondsTo(\selectionPromotionCandidate)) {
                instance.interfaceData(\selectionPromotionCandidate)
            } {
                instance.interfaceData(\promotionCandidate)
            };
            if(promoteSelectionAction.notNil) {
                promoteSelectionAction.value(candidate.deepCopy);
            };
            this.changed(\promotionRequested, (
                kind: \selection,
                candidate: candidate.deepCopy
            ));
        } { |error|
            pathLabel.string_(error.errorString);
        };
        ^candidate;
    }

    openPresetLoader {
        if(presetDialog.notNil) { presetDialog.close };
        presetDialog = ToolPresetLoadDialog.open(
            instance,
            toolPresetLibrary,
            { |preset|
                pathLabel.string_("Loaded preset: " ++ preset.name);
                presetDialog = nil;
            }
        );
        ^presetDialog;
    }

    toolPresetLibraryChanged { |action, preset|
        if(view.isClosed.not) { { this.refresh }.defer };
    }

    refresh {
        var recording, hasPromotion;

        if(view.isClosed) { ^this };
        updating = true;
        recording = instance.recordingState == \recording;
        hasPromotion = instance.tool.notNil
            and: { instance.tool.respondsTo(\promotionCandidate) };
        trackButton.value_(if(instance.trackingEnabled) { 1 } { 0 });
        trackButton.enabled_(instance.trackingAvailable and: { recording.not });
        recordButton.value_(if(recording) { 1 } { 0 });
        recordButton.enabled_(instance.trackingAvailable
            and: { instance.status != \closed });
        promoteSnapshotButton.enabled_(hasPromotion
            and: { promoteSnapshotAction.notNil }
            and: { instance.status == \active });
        promoteSelectionButton.enabled_(instance.tool.notNil
            and: { instance.tool.respondsTo(\selectionPromotionCandidate) }
            and: { promoteSelectionAction.notNil }
            and: { instance.status == \active });
        loadPresetButton.enabled_(instance.status == \active);
        closeButton.enabled_(instance.status != \closed);
        pathLabel.string_(case
            { instance.trackingAvailable.not } { "NodeManager unavailable" }
            { recording } { "Writing " ++ instance.recordingPath }
            { instance.recordingState == \failed } {
                "Recording failed - partial: " ++ (instance.recordingPath ? "unavailable")
            }
            { instance.recordingPath.notNil } { "Last take: " ++ instance.recordingPath }
            { instance.trackingEnabled } { "Visible in NodeManager" }
            { "Not visible in NodeManager" }
        );
        contextLabel.string_(this.contextSummary);
        updating = false;
        ^this;
    }

    prReleaseContextWatcher {
        contextWatcher !? { HarmonicContext.removeDependant(contextWatcher) };
        contextWatcher = nil;
        ^this;
    }

    close {
        if(presetDialog.notNil) {
            presetDialog.close;
            presetDialog = nil;
        };
        toolPresetLibrary.removeObserver(this);
        this.prReleaseContextWatcher;
        if(callback.notNil) {
            instance.removeDependant(callback);
            callback = nil;
        };
        ^this;
    }
}
