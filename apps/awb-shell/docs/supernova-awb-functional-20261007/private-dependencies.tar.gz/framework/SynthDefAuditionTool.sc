SynthDefAuditionTool {
    *register {
        var existing;

        existing = ToolRegistry.at(\synthdefAudition);
        if(existing.notNil) { ^existing };
        ^ToolRegistry.register(ToolDefinition(
            \synthdefAudition,
            "SynthDef Audition",
            version: "0.1.0",
            interfaceKind: \native,
            capabilities: [\audition, \hostedExecution],
            defaultConfig: (),
            emissionTypes: [],
            dependencies: (protocol: \synthDefAuditionV1),
            multipleInstances: true,
            cleanupPolicy: \terminateOwned,
            factory: { nil }
        ));
    }

    *openClient { |instanceID, config|
        this.register;
        ^ToolLauncher.openNamed(
            \synthdefAudition,
            instanceID.asString,
            config ? (),
            (launchInterface: false, track: true)
        );
    }
}
