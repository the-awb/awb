// HarmonicContext
//
// The harmonic object itself: a set of pitch relations plus an anchor. A
// scale + note centre. A lattice + reference. A CPS + reference.
//
// Spec 8C names three layers that had been conflated:
//
//   1. harmonic context   THIS - the harmonic object
//   2. tools            create, edit, audition and visualise contexts
//   3. live context     what is sounding, read THROUGH the active context
//
// A context is a VALUE. It can be saved, recalled and switched, which a tool
// cannot, and it may exist with no tool at all - loaded from a file, set from
// code, recalled from a preset. `tool` is a property a context MAY have, never
// a precondition for existing. A registry keyed by tool would quietly
// reinstate "the owner of harmonic context is a tool", which 8C exists to
// correct.
//
//
// HOLDING IS NOT PROMOTION
//
// Two relations that must not collapse into one:
//
//   holding     MANY contexts exist at once. Tools hold their own.
//   promotion   exactly ONE context governs the session.
//
// So a lattice may be opened onto a scale you are CONSIDERING while the piece
// stays governed by the scale it is actually in. Requiring the explored context
// to be the promoted one would make every act of exploration seize the live
// frame, which is precisely what a composer does not want mid-piece.
//
//
// CLOSED AND OPEN
//
// A scale and a lattice are both "pitch relations plus an anchor", so the
// interface here is real - but it must not flatten them:
//
//   closed   a scale, a CPS. A finite pitch set. Membership is a LOOKUP,
//            degrees are ordered, and it projects onto ~scale / ~tuning.
//   open     a lattice. Membership is a COMPUTATION, neighbours are
//            multi-axial, and there is no finite degree list to project.
//
// `asTuning` therefore belongs to closed contexts. An open context answers nil
// and does not invent a slice.
//
//
// RATIOS ARE THE TRUTH
//
// Contexts hold ratios, never cents. A ratio carries its prime factorisation;
// 386.3 cents does not, and membership, Tenney height and the
// near-in-cents / far-on-the-lattice comparison all need it. Cents and
// Tuning are ONE-WAY exports computed at the boundary. Never round-trip.

HarmonicContext {
    var <name, <anchor, <tool;
    var consumers;

    // The registry: what contexts exist, plus one promoted slot. Small, because
    // a context is a value - a list and a slot, not a lifecycle manager.
    classvar <all, <promoted;
    // Whether promoting a context installs its scale into SuperCollider's
    // own harmony layer. Switching harmonic context switching the global
    // scale is the INTENDED behaviour, so this is on - but it is global and
    // invasive, so it can be turned off.
    classvar <>installsScale;
    // What was there before we touched it, restored when an OPEN context is
    // promoted or none is.
    classvar originalScale, originalScaleSaved;

    *initClass {
        all = [];
        promoted = nil;
        installsScale = true;
        originalScaleSaved = false;
    }

    *new { |name, anchor = 1.0, tool|
        ^super.new.prInitContext(name, anchor, tool);
    }

    prInitContext { |aName, anAnchor, aTool|
        name = aName ? this.class.name.asSymbol;
        anchor = anAnchor ? 1.0;
        tool = aTool;
        consumers = [];
        ^this;
    }

    // --- what every context answers ---------------------------------------------

    kind { ^this.subclassResponsibility(thisMethod) }

    // Closed contexts look membership up; open ones compute it.
    isClosed { ^this.subclassResponsibility(thisMethod) }
    isOpen { ^this.isClosed.not }

    includes { |freq| ^this.subclassResponsibility(thisMethod) }

    // The frequency as a ratio against the anchor, or nil if it is not a
    // member. [low, high] integer pair - see JI.
    ratioFor { |freq| ^this.subclassResponsibility(thisMethod) }

    anchor_ { |hz|
        anchor = hz ? 1.0;
        this.changed(\anchor, anchor);
        this.prPushFrame;
        if(this.isPromoted) { HarmonicContext.prAnnouncePromoted };
        ^this;
    }

    tool_ { |aTool| tool = aTool; ^this }
    name_ { |aName| name = aName; this.changed(\name, name); ^this }

    // --- the closed/open boundary ---------------------------------------------

    // Ordered ratios, closed contexts only. An open context has no finite list.
    degrees { ^nil }

    // A ONE-WAY export into SuperCollider's own harmony layer. Closed contexts
    // override; an open context answers nil rather than choosing a slice for
    // the composer.
    asTuning { ^nil }

    // --- the frame a context offers ---------------------------------------------

    // What a consumer reads. The DECLARED frame only - what is sounding
    // belongs to the live context layer, which composes the two (spec 8C).
    //
    // `axes` is the 8B direction: a SCALE names the primes it needs, and a
    // lattice may be built from them. A consumer asking for axes gets an
    // answer from either kind without knowing which it is talking to.
    frame {
        ^(
            context: this,
            kind: this.kind,
            name: name,
            reference: anchor,
            primes: this.axes,
            closed: this.isClosed,
            degrees: this.degrees
        );
    }

    // The primes this context needs. A lattice's axes; a scale's suggestedAxes.
    axes { ^[] }

    // --- consumers ------------------------------------------------------------
    //
    // A tool handed the frame ONCE goes stale the moment the frame moves, and
    // stale is the worst failure here: the generator answers confidently
    // inside a frame the composer has already left. It does not look stale
    // either - a generator's default integer set is [1,3,5,7,9,11], odd and
    // lattice-shaped and entirely plausible as something a lattice handed it.
    //
    // Consumers live on the SCOPE, not on the live context, so a tool can
    // subscribe to a context that is being CONSIDERED and not only to the
    // promoted one (8C). That is the whole point of holding being separate
    // from promotion.

    addConsumer { |aTool, options|
        if(aTool.isNil) { ^this };
        if(aTool.respondsTo(\applyContext).not) {
            ("HarmonicContext: " ++ aTool.class
                ++ " has no applyContext, so it cannot take the frame").warn;
            ^this;
        };
        consumers = (consumers ? []).reject { |each| each[\tool] === aTool };
        consumers = consumers.add((tool: aTool, options: options ? ()));
        // Hand it the frame at once, so subscribing and pulling agree.
        aTool.applyContext(this.frame, options ? ());
        ^this;
    }

    removeConsumer { |aTool|
        consumers = (consumers ? []).reject { |each| each[\tool] === aTool };
        ^this;
    }

    consumerCount { ^(consumers ? []).size }

    // Called by subclasses whenever the DECLARED frame moves. What is
    // sounding changes constantly; a generator that re-planned every time a
    // note started would be a different instrument from one that holds still
    // while you work.
    prPushFrame {
        var offer;
        this.changed(\frame, this);
        if((consumers ? []).isEmpty) { ^this };
        // Built once for all of them.
        offer = this.frame;
        consumers.do { |each|
            try {
                each[\tool].applyContext(offer, each[\options]);
            } { |error|
                ("HarmonicContext: consumer " ++ each[\tool].class
                    ++ " rejected the frame - " ++ error.errorString).warn;
            };
        };
        ^this;
    }

    // --- promotion ------------------------------------------------------------

    isPromoted { ^HarmonicContext.promoted === this }

    promote { ^HarmonicContext.promote(this) }

    // --- registry -------------------------------------------------------------

    *register { |context|
        if(context.isNil) { ^nil };
        if(all.includes(context).not) {
            all = all.add(context);
            this.changed(\registered, context);
        };
        ^context;
    }

    *deregister { |context|
        if(context.isNil) { ^nil };
        // Deregistering the promoted context leaves the session with none, and
        // says so, rather than silently promoting an arbitrary survivor.
        if(promoted === context) { this.demote };
        all = all.reject { |each| each === context };
        this.changed(\deregistered, context);
        ^context;
    }

    // Contexts a given tool holds. Tools may hold several; a context may hold no
    // tool at all, and those simply do not appear here.
    *heldBy { |aTool| ^all.select { |each| each.tool === aTool } }

    *untooled { ^all.select { |each| each.tool.isNil } }

    *named { |aName| ^all.detect { |each| each.name == aName.asSymbol } }

    // Exactly one context governs the session. Promotion is a single
    // assignment - tools do not negotiate ownership between themselves,
    // because a context is a value (8C).
    *promote { |context|
        if(context.isNil) { ^this.demote };
        this.register(context);
        if(promoted === context) { ^context };
        promoted = context;
        this.prAnnouncePromoted;
        ^context;
    }

    *demote {
        if(promoted.isNil) { ^nil };
        promoted = nil;
        this.prAnnouncePromoted;
        ^nil;
    }

    *isAnyPromoted { ^promoted.notNil }

    // One place for everything that must follow the promoted context. Step 5
    // hangs the parent-Event install here, so that switching harmonic context
    // switches the global scale - which is the INTENDED behaviour, not a side
    // effect (8C).
    *prAnnouncePromoted {
        this.prInstallScale;
        this.changed(\promoted, promoted);
        ^this;
    }

    // The promoted context reaches SuperCollider's own harmony layer, so a
    // bare `(degree: 2).play` resolves through it without naming a scale.
    //
    // THE TARGET MATTERS. `Event.default` returns a fresh COPY on every call
    // - `Event.default === Event.default` is false - so writing to it is
    // silently discarded. The live, shared parent is
    // `Event.parentEvents[\default]`, and that is what an event actually
    // resolves against.
    //
    // A CLOSED context installs its scale. An OPEN one installs nothing and
    // RESTORES what was there, rather than leaving the previous context's
    // scale in place: a lattice has no finite degree list, and a stray
    // `degree:` should fall through to 12ET rather than quietly resolve
    // against a scale that is no longer promoted.
    *prInstallScale {
        var parent, scale;
        if(installsScale.not) { ^this };
        parent = Event.parentEvents[\default];
        if(parent.isNil) { ^this };
        // Saved once, on first touch, so restoring cannot install something
        // we ourselves put there.
        if(originalScaleSaved.not) {
            originalScale = parent[\scale];
            originalScaleSaved = true;
        };
        scale = promoted !? { |context|
            if(context.isClosed) { context.tryPerform(\asScale) } { nil };
        };
        parent[\scale] = scale ?? { originalScale };
        ^this;
    }

    // Put the harmony layer back as we found it. For teardown and for tests,
    // which must not leak a scale into whatever runs next.
    *restoreScale {
        var parent;
        parent = Event.parentEvents[\default];
        if(parent.notNil and: { originalScaleSaved }) {
            parent[\scale] = originalScale;
        };
        ^this;
    }

    // --- reporting ------------------------------------------------------------

    // Both questions, because they are independent and a window showing only
    // the first is how someone explores a candidate scale believing they are
    // reading the piece.
    describe {
        ^"% (%)  anchor % Hz  %  %".format(
            name,
            this.kind,
            anchor,
            if(this.isClosed) { "closed" } { "open" },
            if(this.isPromoted) { "PROMOTED" } { "held" }
        );
    }

    printOn { |stream| stream << this.describe }

    *report {
        var out;
        out = "HARMONIC SCOPES  ·  % held  ·  %\n".format(
            all.size,
            if(promoted.notNil) { "promoted: " ++ promoted.name } { "none promoted" }
        );
        all.do { |each|
            out = out ++ "   " ++ each.describe
                ++ if(each.tool.notNil) { "   tool: " ++ each.tool.class } { "   (no tool)" }
                ++ "\n";
        };
        ^out;
    }
}
