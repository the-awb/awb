ToolRegistry {
    // One catalogue identity, potentially several immutable definitions.
    classvar <definitions, versionedDefinitions;
    *initClass { definitions = IdentityDictionary.new; versionedDefinitions = IdentityDictionary.new }
    *register { |definition, makeDefault=true|
        var versions, existing;
        if(definition.isKindOf(ToolDefinition).not) { Error("ToolRegistry only accepts ToolDefinition objects").throw };
        versions = versionedDefinitions[definition.id] ?? { Dictionary.new };
        existing = versions[definition.version.asString];
        if(existing === definition) {
            if(makeDefault) { this.setDefault(definition.id, definition.version) };
            ^definition;
        };
        versions[definition.version.asString] = definition;
        versionedDefinitions[definition.id] = versions;
        if(makeDefault or: { definitions[definition.id].isNil }) { definitions[definition.id] = definition };
        this.changed(\registered, definition);
        ^definition;
    }
    *at { |id, version|
        if(version.isNil) { ^definitions[id.asSymbol] };
        ^versionedDefinitions[id.asSymbol] !? { |versions| versions[version.asString] };
    }
    *versionsFor { |id|
        var versions = versionedDefinitions[id.asSymbol];
        ^if(versions.isNil) { [] } { versions.keys.asArray.sort };
    }
    // The station opens the newest installed dotted numeric version, even
    // when an explicit registry default is older. Other callers keep defaults.
    *latestVersionFor { |id|
        ^this.versionsFor(id).sort { |a, b|
            var left = a.split($.).collect(_.asInteger);
            var right = b.split($.).collect(_.asInteger);
            var index = 0, size = left.size.max(right.size);
            while { index < size and: { (left[index] ? 0) == (right[index] ? 0) } } {
                index = index + 1;
            };
            if(index < size) { (left[index] ? 0) < (right[index] ? 0) } { a < b };
        }.last;
    }
    *setDefault { |id, version|
        var definition = this.at(id, version);
        if(definition.isNil) { Error("ToolRegistry: unavailable version % / %".format(id, version)).throw };
        if(definitions[id.asSymbol] === definition) { ^definition };
        definitions[id.asSymbol] = definition;
        this.changed(\registered, definition);
        ^definition;
    }
    *requiresExactVersion { |id|
        ^versionedDefinitions[id.asSymbol] !? { |versions|
            versions.values.any { |d| d.metadata[\exactPresetVersion] == true }
        } ? false;
    }
    *unregister { |id|
        versionedDefinitions.removeAt(id.asSymbol);
        ^definitions.removeAt(id.asSymbol);
    }
    *includes { |id| ^definitions.includesKey(id.asSymbol) }
    *all { ^definitions.values.asArray }
    *ids { ^definitions.keys.asArray }
    *clear { definitions.clear; versionedDefinitions.clear; this.changed(\cleared) }
}
