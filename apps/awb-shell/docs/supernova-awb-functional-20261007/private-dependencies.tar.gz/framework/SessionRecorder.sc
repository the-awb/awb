SessionRecorder {
    var <instance, <scope, <recordingID, <partialPath, <completedPath;
    var <state, <error;
    var file, callback;

    *new { |instance, scope, directory|
        ^super.new.init(instance, scope, directory);
    }

    init { |anInstance, aScope, directory|
        var baseDirectory, stem;

        instance = anInstance;
        scope = aScope ? (kind: \toolInstance, id: instance.instanceID);
        if(scope[\kind] != \toolInstance or: {
            scope[\id].asString != instance.instanceID.asString
        }) {
            Error("ToolInstanceRecorder first slice requires this exact toolInstance scope").throw;
        };
        recordingID = "%:%".format(instance.instanceID, UniqueID.next);
        baseDirectory = directory ? (PathName.tmp +/+ "awbCollider-session-recordings");
        File.mkdir(baseDirectory);
        stem = instance.instanceID.replace(":", "-") ++ "-" ++ UniqueID.next;
        partialPath = baseDirectory +/+ (stem ++ ".partial.jsonl");
        completedPath = baseDirectory +/+ (stem ++ ".jsonl");
        state = \created;
        ^this;
    }

    start {
        if(state != \created) {
            Error("SessionRecorder cannot start from %".format(state)).throw;
        };
        file = File(partialPath, "w");
        if(file.isOpen.not) {
            Error("Cannot open recording path: %".format(partialPath)).throw;
        };
        callback = { |object, what, envelope|
            if(what == \toolEvent) { this.write(envelope) };
        };
        instance.addDependant(callback);
        state = \recording;
        this.write((
            schema: \awbToolInstanceEventV1,
            recordingID: recordingID,
            sequence: 0,
            kind: \recordingHeader,
            toolID: instance.definition.id,
            toolInstance: instance.instanceID,
            configRevision: instance.configRevision,
            wallTime: Date.getDate.asString,
            elapsedTime: 0.0,
            requestID: nil,
            origin: \recorder,
            payload: (
                recordingID: recordingID,
                scope: scope.deepCopy,
                snapshot: instance.snapshot
            )
        ));
        ^this;
    }

    write { |record|
        var persistedRecord;

        if(state != \recording) { ^false };
        persistedRecord = record.copy;
        persistedRecord[\recordingID] = recordingID;
        try {
            file.write(ToolInstanceRecordCodec.encode(persistedRecord));
            file.write(Char.nl.asString);
            file.flush;
        } { |caught|
            this.fail(caught);
            ^false;
        };
        ^true;
    }

    stop {
        var command, exitCode;

        if(state == \completed) { ^completedPath };
        if(state != \recording) { ^partialPath };
        state = \stopping;
        instance.removeDependant(callback);
        try {
            file.flush;
            file.close;
        } { |caught|
            this.fail(caught);
            ^partialPath;
        };
        file = nil;
        command = "mv -f -- % %".format(
            partialPath.shellQuote,
            completedPath.shellQuote
        );
        exitCode = command.systemCmd;
        if(exitCode != 0) {
            this.fail(Error("Could not finalize recording (mv exit %): %"
                .format(exitCode, partialPath)));
            ^partialPath;
        };
        state = \completed;
        ^completedPath;
    }

    fail { |caught|
        error = caught;
        if(callback.notNil) { instance.removeDependant(callback) };
        if(file.notNil) {
            try { file.flush } { |ignored| nil };
            try { file.close } { |ignored| nil };
            file = nil;
        };
        state = \failed;
        instance.recorderFailed(this, caught);
        ^this;
    }
}
