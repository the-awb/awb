/*
 * FIFO Playlist System - Live Performance Resource Management
 * 
 * Provides automatic tracking and cleanup of playing SuperCollider objects
 * to prevent runaway synth accumulation during live performance and exploration.
 * 
 * KEY FEATURES:
 * 1. FIFO Resource Management: Automatic cleanup when limits reached
 * 2. OSC Monitoring: Real-time /n_end message tracking for immediate cleanup
 * 3. Type-Aware Handling: Different strategies for Events, Synths, Patterns
 * 4. Observer Pattern: GUI updates and external system notifications
 * 5. Manual Override: Stop specific items, types, or all items
 * 
 * ARCHITECTURE INTEGRATION:
 * - EventPreset.play() automatically registers with global playlist
 * - PlaylistGUI provides real-time monitoring interface
 * - Designed for expansion to multi-type preset system
 * 
 * OSC MONITORING STRATEGY:
 * Events and Synths use immediate OSC /n_end cleanup for consistency.
 * Patterns use polling since they're containers for individual nodes.
 * 
 * PERFORMANCE CONSIDERATIONS:
 * - Minimal overhead: OSC responders auto-cleanup on node end
 * - Efficient updates: Observer pattern prevents unnecessary work
 * - Resource limits: Configurable FIFO prevents memory bloat
 * 
 * USAGE EXAMPLES:
 *   // Automatic via EventPreset
 *   Presets[\myPreset].play;  // Auto-registers with global playlist
 *   
 *   // Manual management
 *   Playlist.add(~synth, \myKey, \synth);
 *   Playlist.stopAll;
 *   Playlist.setMaxItems(10);
 * 
 * API ISSUES (see code_review.md):
 * - Missing playingCount method (test expects this)
 * - Missing clear method (test expects this)
 * - These should be added for API consistency
 */

Playlist {
    classvar <global;
    var <maxItems, <items, <observers, <oscResponders;

    *initClass {
        global = Playlist(20); // Default max 20 playing items
    }

    *new { |maxItems=8|
        ^super.newCopyArgs(maxItems, [], Set.new, [])
    }

    // Add a playing object to the playlist
    add { |playingObject, presetKey, presetType=\event|
        var item = (
            object: playingObject,
            presetKey: presetKey,
            presetType: presetType,
            startTime: Date.getDate,
            isPlaying: true
        );

        // Add to end of list
        items = items.add(item);

        // Set up cleanup when object stops playing
        this.setupCleanup(item);

        // Enforce FIFO limit
        this.enforceFIFO;

        // Notify observers
        this.notifyObservers(\added, item);

        ("Playlist: Added " ++ presetType ++ " '" ++ presetKey ++ "' | Total: " ++ items.size).postln;

        ^item;
    }

    // Set up automatic cleanup when object stops playing
    setupCleanup { |item|
        var object, originalFreeFunc, nodeIDs, synth, originalReleaseFunc;
        object = item.object;

        // Handle different object types
        switch(object.class.name,
            \Synth, {
                // OSC monitoring for consistent behavior with Events
                this.setupSynthOSCMonitoring(item);
            },
            \Event, {
                // OSC monitoring for immediate cleanup when nodes end
                this.setupEventOSCMonitoring(item);
            },
            \EventStreamPlayer, {
                // For event patterns - monitor in a separate thread
                {
                    while { object.isPlaying } { 0.1.wait };
                    item.isPlaying = false;
                    this.removeFinished;
                }.fork;
            },
            \Task, {
                // For tasks - monitor in a separate thread
                {
                    while { object.isPlaying } { 0.1.wait };
                    item.isPlaying = false;
                    this.removeFinished;
                }.fork;
            },
            // Generic fallback for objects with isPlaying method
            {
                if(object.respondsTo(\isPlaying)) {
                    {
                        while { object.isPlaying } { 0.1.wait };
                        item.isPlaying = false;
                        this.removeFinished;
                    }.fork;
                } {
                    ("Warning: Don't know how to monitor " ++ object.class ++ " for cleanup").warn;
                };
            }
        );
    }

    // Set up OSC monitoring for Event node lifecycle
    setupEventOSCMonitoring { |item|
        var object, nodeIDs, server, responder, trackedNodes;
        object = item.object;
        
        // Get node IDs and server from the event
        nodeIDs = object[\id];
        server = object[\server] ? Server.default;
        
        // Handle both single nodes and arrays of nodes
        if(nodeIDs.notNil) {
            // Make a copy of the nodeIDs for tracking
            trackedNodes = nodeIDs.asArray.copy;
            
            ("Setting up OSC monitoring for nodes: " ++ trackedNodes).postln;
            
            // Create OSC responder for /n_end messages
            responder = OSCFunc({ |msg|
                var endedNodeID = msg[1];
                
                ("Received /n_end for node: " ++ endedNodeID).postln;
                
                // Check if this /n_end is for one of our tracked nodes
                if(trackedNodes.includes(endedNodeID)) {
                    ("✓ Node " ++ endedNodeID ++ " ended - updating tracking").postln;
                    
                    // Remove this nodeID from tracking
                    trackedNodes.remove(endedNodeID);
                    
                    ("Remaining tracked nodes: " ++ trackedNodes).postln;
                    
                    // If all nodes ended, mark item as finished
                    if(trackedNodes.isEmpty) {
                        ("✓ All nodes ended - cleaning up item").postln;
                        item.isPlaying = false;
                        
                        // CRITICAL: Update the Event's [\isPlaying] status too
                        object[\isPlaying] = false;
                        
                        this.removeFinished;
                        
                        // Clean up the OSC responder
                        responder.free;
                        oscResponders.remove(responder);
                    };
                };
            }, '/n_end', server.addr);
            
            // Track the responder for cleanup
            oscResponders = oscResponders.add(responder);
        } {
            ("Warning: Event has no node IDs to monitor").warn;
        };
    }

    // Set up OSC monitoring for Synth node lifecycle
    setupSynthOSCMonitoring { |item|
        var object, nodeID, server, responder;
        object = item.object;
        
        // Get node ID and server from the synth
        nodeID = object.nodeID;
        server = object.server ? Server.default;
        
        if(nodeID.notNil) {
            ("Setting up OSC monitoring for synth node: " ++ nodeID).postln;
            
            // Create OSC responder for /n_end messages
            responder = OSCFunc({ |msg|
                var endedNodeID = msg[1];
                
                ("Received /n_end for node: " ++ endedNodeID).postln;
                
                // Check if this /n_end is for our synth
                if(endedNodeID == nodeID) {
                    ("✓ Synth node " ++ endedNodeID ++ " ended - cleaning up").postln;
                    item.isPlaying = false;
                    
                    // For Synths, we don't need to update object status since 
                    // Synth.isPlaying works correctly on its own
                    
                    this.removeFinished;
                    
                    // Clean up the OSC responder
                    responder.free;
                    oscResponders.remove(responder);
                };
            }, '/n_end', server.addr);
            
            // Track the responder for cleanup
            oscResponders = oscResponders.add(responder);
        } {
            ("Warning: Synth has no node ID to monitor").warn;
        };
    }

    // Clean up OSC responders for a specific item
    cleanupOSCResponders { |item|
        // Note: In current implementation, OSC responders clean themselves up
        // when nodes end, so this is mainly for manual cleanup scenarios.
        // Future enhancement: Track responder-to-item mapping for precise cleanup.
        
        // For now, this is a placeholder - responders auto-cleanup on /n_end
    }

    // Remove finished items from the playlist
    removeFinished {
        var beforeSize, afterSize;
        beforeSize = items.size;
        items = items.select({ |item| 
            // Use correct Event status checking - [\isPlaying] for Events, .isPlaying for others
            if(item.object.class.name == \Event) {
                item.object[\isPlaying] ? false
            } {
                item.object.isPlaying ? false
            }
        });
        afterSize = items.size;

        if(beforeSize != afterSize) {
            ("Playlist: Cleaned up " ++ (beforeSize - afterSize) ++ " finished items | Remaining: " ++ afterSize).postln;
            this.notifyObservers(\cleaned, afterSize);
        };
    }

    // Enforce FIFO limit by stopping oldest items
    enforceFIFO {
        while { items.size > maxItems } {
            var oldest = items.removeAt(0);
            this.stopAndRemove(oldest);
            ("Playlist: FIFO limit reached - stopped oldest: " ++ oldest.presetKey).postln;
        };
    }

    // Stop and remove a specific item
    stopAndRemove { |item|
        var object = item.object;

        // Try to stop the object gracefully
        if(object.respondsTo(\stop)) {
            object.stop;
        } {
            if(object.respondsTo(\free)) {
                object.free;
            };
        };

        // Clean up any OSC responders for this item
        this.cleanupOSCResponders(item);

        // Remove from playlist
        items.remove(item);
        item.isPlaying = false;

        this.notifyObservers(\removed, item);
    }

    // Get currently playing items
    playing {
        this.removeFinished; // Clean up first - works with OSC for belt-and-suspenders approach
        ^items.select({ |item| 
            // Use correct Event status checking - [\isPlaying] for Events, .isPlaying for others
            if(item.object.class.name == \Event) {
                item.object[\isPlaying] ? false
            } {
                item.object.isPlaying ? false
            }
        });
    }

    // Stop all items
    stopAll {
        var playingCount = this.playing.size;
        items.copy.do({ |item| this.stopAndRemove(item) });
        this.cleanupAllOSCResponders; // Extra safety cleanup
        ("Playlist: Stopped all " ++ playingCount ++ " playing items").postln;
    }

    // Clean up all OSC responders
    cleanupAllOSCResponders {
        oscResponders.copy.do({ |responder|
            try {
                responder.free;
            } { |error|
                // Responder might already be freed
            };
        });
        oscResponders = [];
    }

    // Stop items of a specific type
    stopType { |presetType|
        var typeItems = items.select({ |item| item.presetType == presetType });
        typeItems.do({ |item| this.stopAndRemove(item) });
        ("Playlist: Stopped " ++ typeItems.size ++ " " ++ presetType ++ " items").postln;
    }

    // Stop specific preset by key
    stopPreset { |presetKey|
        var presetItems = items.select({ |item| item.presetKey == presetKey });
        presetItems.do({ |item| this.stopAndRemove(item) });
        ("Playlist: Stopped " ++ presetItems.size ++ " instances of " ++ presetKey).postln;
    }

    // Set maximum items
    setMaxItems { |newMax|
        maxItems = newMax.max(1);
        this.enforceFIFO; // Apply new limit immediately
        this.notifyObservers(\maxItemsChanged, maxItems);
    }

    // Observer pattern for GUI updates
    addObserver { |observer|
        observers.add(observer);
    }

    removeObserver { |observer|
        observers.remove(observer);
    }

    notifyObservers { |action, data|
        observers.do({ |observer|
            if(observer.respondsTo(\playlistChanged)) {
                observer.playlistChanged(action, data);
            };
        });
    }

    // Status display
    status {
        this.removeFinished; // Keep this for GUI updates - OSC should have already cleaned up Events
        ("=== Playlist Status ===").postln;
        ("Max items: " ++ maxItems).postln;
        ("Total items: " ++ items.size).postln;
        ("Playing items: " ++ this.playing.size).postln;

        if(items.size > 0) {
            "Items:".postln;
            items.do({ |item, i|
                var age = Date.getDate.rawSeconds - item.startTime.rawSeconds;
                var status = item.isPlaying.if("♪", "◦");
                ("  " ++ status ++ " " ++ item.presetKey ++ " (" ++ item.presetType ++ ") - " ++ age.round(0.1) ++ "s").postln;
            });
        } {
            "  (empty)".postln;
        };
    }

    // Class methods for global playlist
    *add { |playingObject, presetKey, presetType=\event|
        ^global.add(playingObject, presetKey, presetType);
    }

    *playing {
        ^global.playing;
    }

    *stopAll {
        global.stopAll;
    }

    *stopType { |presetType|
        global.stopType(presetType);
    }

    *stopPreset { |presetKey|
        global.stopPreset(presetKey);
    }

    *status {
        global.status;
    }

    *setMaxItems { |newMax|
        global.setMaxItems(newMax);
    }
}