/*
PStreamPlayer - Base class for navigable stream players with event capture
=========================================================================

Universal foundation for navigable musical streams with dual interface:
1. Score Navigation - navigate through compositional structure
2. Play History - record what actually happened during performance

Core Innovation:
- Stream regeneration: Stop → Rebuild → Restart pattern for true navigation
- Dual tracking: Score position + performance history
- Type-specific stream creation with universal capture infrastructure
- Event notification system for real-time GUI integration

Architecture:
- Subclasses implement createStreamFrom() for their data type
- Base class provides event capture, notifications, and navigation wrapper
- All streams flow from current position to end (not single events)
- Performance history captured automatically regardless of score jumping

Usage:
Subclasses: PTimelinePlayer, PSequencePlayer, PPatternPlayer
Score Navigation: jumpToIndex, stepForward, stepBackward, getScoreContext
Play History: getPlayHistory, getSessionRecording
*/

PStreamPlayer {
    // Universal navigation state
    var <startIndex = 0, <isPlaying = false;
    var <currentPlayer, <templateEvent;
    var <isStreamExhausted = false;  // Track if pattern finished generating
    var <>currentIndex = 0;  // Real-time tracking of current playback position

    // Dual tracking system
    var <playedEvents;    // Performance history - what actually played
    var <dependants;      // Event notification system
	// var <allCurrentEvents; // Accumulated events from all streams (persists across navigation) not working need proper implementation
    
    // Container interface compatibility for NodeManagerState
    children { ^playedEvents }

    *new { |data, templateEvent|
        ^super.new.initPStreamPlayer(data, templateEvent);
    }

    initPStreamPlayer { |data, event|
        templateEvent = event ? Event.default;
        startIndex = 0;
        currentIndex = 0;
        currentPlayer = nil;
        isPlaying = false;
        isStreamExhausted = false;
        playedEvents = [];
        dependants = [];
		// allCurrentEvents = [];

        // Let subclass initialize its data
        this.initializeData(data);
        ^this;
    }

    // ABSTRACT INTERFACE - Subclasses must implement

    initializeData { |data|
        // Subclass stores data in its natural format
        this.subclassResponsibility(\initializeData);
    }

    createStreamFrom { |position|
        // Subclass creates stream from position to end
        // Returns PIndexedStream with events from position onwards
        ^this.subclassResponsibility(\createStreamFrom);
    }

    eventAtIndex { |index|
        // Return event at specific index, or nil if out of range
        ^this.subclassResponsibility(\eventAtIndex);
    }

    hasHorizon {
        // Does this stream type know its future events?
        ^this.subclassResponsibility(\hasHorizon);
    }

    size {
        // Total size if known, nil if infinite
        ^this.subclassResponsibility(\size);
    }

    // UNIVERSAL NAVIGATION INTERFACE (Score Navigation)

    setStartIndex { |index|
        var wasPlaying;

        // Validate index with subclass
        if(this.eventAtIndex(index).isNil) {
            ("PStreamPlayer: setStartIndex % out of range").format(index).warn;
            ^this;
        };

        wasPlaying = isPlaying;

        // Stop current player and kill active nodes immediately
        if(currentPlayer.notNil) {
            currentPlayer.stopAll;
        };

        // Update start position and sync current position
        startIndex = index;
        currentIndex = index;

        // Create and start new stream from this position if was playing
        if(wasPlaying) {
            this.createAndStartPlayer;
        } {
            currentPlayer = nil;
            isPlaying = false;
        };

        ^this;
    }

    stepForward {|mono=false|
        var nextIndex = startIndex + 1;
        if(this.eventAtIndex(nextIndex).notNil) {
            if(isPlaying) {
                // If playing, instant jump to next position (preserves existing notes)
             if(mono, this.play(index:nextIndex), this.playI(nextIndex));
            } {
                // If stopped, just update start position
                this.setStartIndex(nextIndex);
            };
        } {
            "PStreamPlayer: Already at end".postln;
        };
    }

    stepBackward {|mono=false|
        var prevIndex = startIndex - 1;
        if(prevIndex >= 0) {
            if(isPlaying) {
                // If playing, instant jump to previous position (preserves existing notes)
				if(mono, this.play(index:prevIndex), this.playI(prevIndex));
            } {
                // If stopped, just update start position
                this.setStartIndex(prevIndex);
            };
        } {
            "PStreamPlayer: Already at beginning".postln;
        };
    }


    // PLAYBACK CONTROL

    nodeManagerMetadata {
        ^(
            playerType: this.class.name,
            startIndex: startIndex,
            currentIndex: currentIndex,
            streamSize: this.size,
            hasHorizon: this.hasHorizon,
            underlyingPlayer: currentPlayer
        );
    }

    play { |clock, quant, index|
        var registrationMetadata;

        // If index provided, jump to that position first
        if(index.notNil) {
            if(this.eventAtIndex(index).isNil) {
                ("PStreamPlayer: play(index: %) out of range").format(index).warn;
                ^this;
            };
            // Update both indices for the new position
            startIndex = index;
            currentIndex = index;
        };

        // If already playing and we're jumping, stop current stream first
        if(isPlaying and: { index.notNil }) {
            if(currentPlayer.notNil) {
                currentPlayer.stopAll;
            };
        } {
            if(isPlaying) {
                "PStreamPlayer: Already playing".warn;
                ^this;
            };
        };

        // Reset stream state for new playback session
        isStreamExhausted = false;
        currentIndex = startIndex;  // Set current position to where we're starting playback

        this.createAndStartPlayer;
        if(currentPlayer.notNil) {
            // Set up stream end detection
            this.setupStreamEndDetection;

            // Register the container before the first zero-delta Event can be
            // emitted, so NodeManager can attach that Event to this player.
            registrationMetadata = this.nodeManagerMetadata;
            NodeManager.register(this, \streamPlayer, registrationMetadata);

            // EventStreamPlayer's second argument is doReset; quant is third.
            currentPlayer.play(clock, false, quant);
            isPlaying = true;

            if(index.notNil) {
                ("PStreamPlayer: Playing from index " ++ index).postln;
            };

            NodeManager.notifyObservers(\streamPlayerStarted, registrationMetadata.copy.putAll((
                player: this,
                playerType: this.class.name
            )));
        };
        ^this;
    }

    playI { |index, mono=false|
        // Instant jump - jump to index while playing without stopping current notes
        // This preserves the old liveJumpToIndex behavior
        if(mono, {this.play(index:index)},{


		if(index.isNil) {
            "PStreamPlayer: playI requires an index argument".warn;
            ^this;
        };

        if(this.eventAtIndex(index).isNil) {
            ("PStreamPlayer: playI(%) out of range").format(index).warn;
            ^this;
        };

        if(isPlaying) {
            // Live jump: stop current stream but don't kill active nodes
            if(currentPlayer.notNil) {
                currentPlayer.stop;  // Stop stream but keep nodes playing
            };

            // Update position and restart from new position
            startIndex = index;
            currentIndex = index;
            this.createAndStartPlayer;
            if(currentPlayer.notNil) {
                currentPlayer.play;
                ("PStreamPlayer: Live jump to index " ++ index).postln;
            };
        } {
            // Not playing, just do normal position setting and start playing
            startIndex = index;
            currentIndex = index;
            this.play;
        };
		})

        ^this;
    }

    playTracked { |clock, quant|
        // Same as play - we already use EventStreamPlayerWithTracking internally
        ^this.play(clock, quant);
    }

    stop {
        if(currentPlayer.notNil) {
            currentPlayer.stop;

            // Unregister from NodeManager
            NodeManager.unregister(this);

            // Notify NodeManager of stream player stopping
            NodeManager.notifyObservers(\streamPlayerStopped, (
                player: this,
                playerType: this.class.name
            ));
        };
        isPlaying = false;
        currentPlayer = nil;
    }

    stopAll {
        // Stop stream AND free all active nodes immediately
        if(currentPlayer.notNil) {
            currentPlayer.stop;

            // Notify NodeManager of stream player stopping (with node cleanup)
            NodeManager.notifyObservers(\streamPlayerStoppedAll, (
                player: this,
                playerType: this.class.name
            ));
        };
        this.freeActiveNodes;
        NodeManager.unregister(this);
        isPlaying = false;
        currentPlayer = nil;
    }

    pause {
        if(currentPlayer.notNil and: { isPlaying }) {
            if(currentPlayer.respondsTo(\pauseForNavigation)) {
                currentPlayer.pauseForNavigation;
            } {
                currentPlayer.pause;
            };
            isPlaying = false;
            ("PStreamPlayer: Paused at index " ++ currentIndex).postln;
        } {
            "PStreamPlayer: Not playing".warn;
        };
    }

    resume { |clock, quant|
        if(currentPlayer.notNil and: { isPlaying.not }) {
            // Try to resume, but if that fails, restart from current position
            try {
                if(currentPlayer.respondsTo(\resumeForNavigation)) {
                    currentPlayer.resumeForNavigation(clock, quant);
                } {
                    currentPlayer.resume(clock, quant);
                };
                isPlaying = true;
                ("PStreamPlayer: Resumed from index " ++ currentIndex).postln;
            } { |error|
                // Resume failed, restart from current position
                ("PStreamPlayer: Resume failed, restarting from index " ++ currentIndex).postln;
                this.createAndStartPlayer;
                if(currentPlayer.notNil) {
                    currentPlayer.play(clock, false, quant);
                    isPlaying = true;
                };
            };
        } {
            "PStreamPlayer: Already playing or no player".warn;
        };
    }

    // STREAM END DETECTION AND TWO-CONDITION ISPLAYING LOGIC

    setupStreamEndDetection {
        // Set up detection for when the EventStreamPlayer finishes generating events
        if(currentPlayer.notNil and: { currentPlayer.respondsTo(\addDependant) }) {
            currentPlayer.addDependant({ |player, what, event|
                switch(what,
                    \streamEnded, {
                        this.onStreamExhausted;
                    },
                    \eventStarted, {
                        // NodeManager receives this through the tracked-player
                        // emission adapter and owns lifecycle projection.
                    },
                    \eventEnded, {
                        // Remove from accumulated events list
						// allCurrentEvents.remove(event);
                        this.onNodeEnd(event);
                    }
                );
            });
        };
    }

    onStreamExhausted {
        isStreamExhausted = true;
        ("PStreamPlayer: Stream exhausted, checking if fully finished...").postln;
        this.checkIfFullyFinished;
    }

    onNodeEnd { |finishedEvent|
        // This should be called when individual nodes finish
        // Remove from currentStreamEvents (handled by EventStreamPlayerWithTracking)
        var currentEvents = this.currentStreamEvents;
        ("PStreamPlayer: Node ended (freq:" ++ finishedEvent[\freq] ++ "), " ++ currentEvents.size ++ " events remaining").postln;
        this.checkIfFullyFinished;
    }

    checkIfFullyFinished {
        var currentEvents = this.currentStreamEvents;

        ("PStreamPlayer: checkIfFullyFinished - isStreamExhausted:" ++ isStreamExhausted ++ " currentEvents.isEmpty:" ++ currentEvents.isEmpty ++ " currentEvents.size:" ++ currentEvents.size).postln;

        if(isStreamExhausted and: { currentEvents.isEmpty }) {
            isPlaying = false;
            ("PStreamPlayer: ✅ FULLY FINISHED - stream exhausted and all nodes ended. Ready to replay.").postln;

            // Notify observers of completion
            this.notifyDependants(\fullyFinished, this);

            // Notify NodeManager
            NodeManager.notifyObservers(\streamPlayerFinished, (
                player: this,
                playerType: this.class.name
            ));
        } {
            if(isStreamExhausted) {
                ("PStreamPlayer: Stream exhausted but " ++ currentEvents.size ++ " events still playing...").postln;
            } {
                ("PStreamPlayer: Stream still generating, " ++ currentEvents.size ++ " events playing...").postln;
            };
        };
    }

    // STREAM CREATION AND MANAGEMENT

    createAndStartPlayer {
        var stream;
        stream = this.createStreamFrom(startIndex);
        if(stream.notNil) {
            // Use tracking player for individual event access

            currentPlayer = EventStreamPlayerWithTracking(stream, templateEvent);
            currentPlayer.parentPlayer = this;  // Set parent reference for index tracking
            if(NodeManager.ensureEnabled) {
                NodeManager.watch(currentPlayer, \EventStreamPlayerWithTracking, (
                    streamContainer: this,
                    playerType: \EventStreamPlayerWithTracking
                ), nil);
            } {
                "PStreamPlayer: NodeManager is disabled; playing without lifecycle tracking".warn;
            };
        } {
            currentPlayer = nil;
        };
    }

    // ACTIVE NODE MANAGEMENT

    freeActiveNodes {
        // Free all currently active nodes from this stream
        var activeEvents = this.activeStreamEvents;
        activeEvents.do { |event|
            var nodeIDs = event[\id];
            if(nodeIDs.notNil) {
                nodeIDs.asArray.do { |nodeID|
                    (event[\server] ? Server.default).sendMsg('/n_free', nodeID);
                };
            };
        };
    }

    // PERFORMANCE HISTORY TRACKING

    addToHistory { |event, scoreIndex|
        var historyEntry = (
            event: event.copy,
            scoreIndex: scoreIndex,
            timestamp: Date.getDate
        );
        playedEvents = playedEvents.add(historyEntry);

        // Notify dependants about performance event
        this.notifyDependants(\eventPlayed, event, scoreIndex);
    }

    getPlayHistory { |maxItems = 50|
        // Return recent performance history, most recent first
        ^playedEvents.reverse[..maxItems-1];
    }

    clearPlayHistory {
        playedEvents = [];
    }

    getSessionRecording {
        // Return complete performance session as events
        ^playedEvents.collect(_.event);
    }

    // SCORE NAVIGATION CONTEXT

    getScoreContext { |beforeCount = 5, afterCount = 5|
        // Return events around current score position
        var beforeEvents, afterEvents, currentEvent;

        currentEvent = this.eventAtIndex(currentIndex);

        beforeEvents = [];
        ((currentIndex - beforeCount).max(0)..(currentIndex - 1)).do { |i|
            var event = this.eventAtIndex(i);
            if(event.notNil) {
                beforeEvents = beforeEvents.add((index: i, event: event));
            };
        };

        afterEvents = [];
        ((currentIndex + 1)..(currentIndex + afterCount)).do { |i|
            var event = this.eventAtIndex(i);
            if(event.notNil) {
                afterEvents = afterEvents.add((index: i, event: event));
            };
        };

        ^(
            before: beforeEvents,
            current: (index: currentIndex, event: currentEvent),
            after: afterEvents
        );
    }

    // EVENT NOTIFICATION SYSTEM

    addDependant { |dependant|
        if(dependants.includes(dependant).not) {
            dependants = dependants.add(dependant);
        };
    }

    removeDependant { |dependant|
        dependants.remove(dependant);
    }

    notifyDependants { |what ...args|
        dependants.do { |dep|
            dep.update(this, what, *args);
        };
    }


    // INSPECTION METHODS

    currentEvent {
        ^this.eventAtIndex(startIndex);
    }

    status {
        "PStreamPlayer Status:".postln;
        "  Start Position: %".format(startIndex).postln;
        "  Current Position: % / %".format(currentIndex, this.size ? "unknown").postln;
        "  Is Playing: %".format(isPlaying).postln;
        "  Play History: % events".format(playedEvents.size).postln;
        "  Has Horizon: %".format(this.hasHorizon).postln;
        if(this.hasHorizon) {
            "  Total Size: %".format(this.size).postln;
        };
    }

    // INDIVIDUAL EVENT ACCESS

    currentStreamEvents {
		// Get all currently playing events (accumulated across stream changes)
		// Get currently playing events from the stream
		if(currentPlayer.notNil and: { currentPlayer.respondsTo(\currentEvents) }) {
			^currentPlayer.currentEvents;
		} {
			^[];
		};
		// ^allCurrentEvents.copy;
	}

    activeStreamEvents {
        // Get events with active nodes from the stream
        if(currentPlayer.notNil and: { currentPlayer.respondsTo(\activeEvents) }) {
            ^currentPlayer.activeEvents;
        } {
            ^[];
        };
    }

    streamEventCount {
        // Get count of events in stream history
        if(currentPlayer.notNil and: { currentPlayer.respondsTo(\eventCount) }) {
            ^currentPlayer.eventCount;
        } {
            ^0;
        };
    }

    // GUI DATA ACCESS

    getNavigationData {
        // Return data structure for consistent GUI display
        ^(
            // Score navigation
            startIndex: startIndex,
            currentIndex: currentIndex,
            currentEvent: this.currentEvent,
            scoreContext: this.getScoreContext,
            hasHorizon: this.hasHorizon,
            streamSize: this.size,

            // Performance tracking
            playHistory: this.getPlayHistory(10),
            isPlaying: isPlaying,

            // Individual event access
            currentStreamEvents: this.currentStreamEvents,
            activeStreamEvents: this.activeStreamEvents,
            streamEventCount: this.streamEventCount
        );
    }
}
