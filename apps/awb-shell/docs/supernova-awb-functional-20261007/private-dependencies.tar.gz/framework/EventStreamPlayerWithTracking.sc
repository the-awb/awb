/*
EventStreamPlayerWithTracking - Enhanced EventStreamPlayer with Individual Event Access
======================================================================================

Extends EventStreamPlayer to expose each emitted Event to NodeManager. NodeManager owns
the live-event registry and server-node lifecycle; this player owns stream evaluation only.

Core Innovation:
- Uses Event.playPlusDelta to capture played events with node info
- Registers emitted Events with NodeManager through observer callbacks
- Delegates current/active queries to NodeManager
- Never installs its own /n_end responder

Usage:
~player = EventStreamPlayerWithTracking(stream, templateEvent);
~player.play;
~currentEvents = ~player.currentEvents;  // Get all currently playing events
~activeNodes = ~player.activeEvents;     // Get events with active nodes
*/

EventStreamPlayerWithTracking : EventStreamPlayer {
    var <dependants;  // Observer pattern for GUI updates
    var <streamEndedNaturally = false;  // Track if stream ended vs manual stop
    var <isNavigationPaused = false;
    var <>parentPlayer;  // Reference to parent PStreamPlayer for index tracking

    init {
        super.init;
        dependants = [];
    }

    prNext { arg inTime;
        var playPlusResult, playedEvent, nextTime;
        var outEvent = stream.next(event.copy);
        
        if (outEvent.isNil) {
            // PStreamPlayer can suspend this scheduler without exhausting the
            // underlying stream. Ignore a clock wake-up racing that suspension.
            if(isNavigationPaused) {
                nextBeat = nil;
                ^nil;
            };

            streamHasEnded = stream.notNil;
            streamEndedNaturally = true;
            cleanup.clear;
            
            // Notify dependants that stream has ended
            this.notifyDependants(\streamEnded, this);
            
            this.removedFromScheduler;
            ^nil
        } {
            // Use playPlusDelta to get both event result and timing
            playPlusResult = outEvent.playPlusDelta(cleanup, muteCount > 0);
            playedEvent = playPlusResult[0];    // Event with node info
            nextTime = playPlusResult[1];       // Delta timing
            
            // Publish the emitted Event. NodeManager owns registration and /n_end.
            if(playedEvent.notNil and: { playedEvent[\type] != \rest }) {
                // Update parent's current index (naughty little increment!)
                if(parentPlayer.notNil) {
                    parentPlayer.currentIndex = parentPlayer.currentIndex + 1;
                };

                this.notifyDependants(\eventStarted, playedEvent);
            };
            
            // Continue with normal EventStreamPlayer logic
            if (nextTime.isNil) { 
                this.removedFromScheduler; 
                ^nil 
            };
            nextBeat = inTime + nextTime;
            ^nextTime
        };
    }

    // QUERY METHODS

    currentEvents {
        ^NodeManager.eventsForStreamPlayer(this);
    }

    activeEvents {
        ^NodeManager.eventsForStreamPlayer(this);
    }

    eventCount {
        ^this.currentEvents.size;
    }
    
    // GUI compatibility method - return events for container display
    children {
        ^this.activeEvents;
    }

    // OBSERVER PATTERN

    addDependant { |dependant|
        if(dependants.includes(dependant).not) {
            dependants = dependants.add(dependant);
        };
    }

    removeDependant { |dependant|
        dependants.remove(dependant);
    }

    notifyDependants { |what ...args|
        dependants.do { |dep|
            dep.update(this, what, *args);
        };
    }

    trackedEventEnded { |event|
        this.notifyDependants(\eventEnded, event);
        ^this;
    }

    // CLEANUP METHODS

    stop {
        isNavigationPaused = false;
        super.stop;
        this.notifyDependants(\stopped, this);
    }

    pauseForNavigation {
        if(this.isPlaying) {
            this.setActiveNodesRunning(false);
            isNavigationPaused = true;
            clock.clear(this);
            this.prStop;
            this.changed(\paused);
        };
        ^this;
    }

    resumeForNavigation { arg argClock, quant;
        if(isNavigationPaused) {
            isNavigationPaused = false;
            this.setActiveNodesRunning(true);
            super.resume(argClock, quant);
        };
        ^this;
    }

    setActiveNodesRunning { |running = true|
        this.activeEvents.do { |event|
            var nodeIDs, server;
            nodeIDs = event[\id];
            server = event[\server] ? Server.default;
            if(nodeIDs.notNil) {
                nodeIDs.asArray.do { |nodeID|
                    server.sendMsg('/n_run', nodeID, running.asInteger);
                };
            };
        };
        ^this;
    }

    stopAll {
        // Stop stream AND free all active nodes immediately
        var activeEvents;

        activeEvents = this.activeEvents;
        
        // Free all active nodes
        activeEvents.do { |event|
            var nodeIDs, server;
            nodeIDs = event[\id];
            server = event[\server] ? Server.default;
            if(nodeIDs.notNil) {
                nodeIDs.asArray.do { |nodeID|
                    server.sendMsg('/n_free', nodeID);
                };
            };
        };
        
        // Then do normal stop
        this.stop;
    }

    removedFromScheduler { arg freeNodes = true;
        // EventStreamPlayer cleanup may release nodes. NodeManager retains
        // lifecycle authority until their actual /n_end replies arrive.
        super.removedFromScheduler(freeNodes);
    }

    play { arg argClock, doReset = false, quant;
        isNavigationPaused = false;
        streamEndedNaturally = false;
        ^super.play(argClock, doReset, quant);
    }

    // INSPECTION METHODS

    status {
        var currentEvents;
        currentEvents = this.currentEvents;
        "EventStreamPlayerWithTracking Status:".postln;
        "  Is Playing: %".format(this.isPlaying).postln;
        "  Current Events: %".format(currentEvents.size).postln;
        "  Active Events: %".format(this.activeEvents.size).postln;

        if(currentEvents.notEmpty) {
            "  Recent Events:".postln;
            currentEvents.do { |evt, i|
                var nodeInfo = evt[\id];
                "    %: freq=%, nodes=%".format(i, evt[\freq] ? "?", nodeInfo).postln;
            };
        };
    }
}
