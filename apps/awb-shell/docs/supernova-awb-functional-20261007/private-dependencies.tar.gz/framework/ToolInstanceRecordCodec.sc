ToolInstanceRecordCodec {
    *encode { |record|
        var jsonClass;

        jsonClass = \JSONlib.asClass;
        if(jsonClass.isNil) {
            Error("ToolInstanceRecordCodec requires JSONlib").throw;
        };
        ^jsonClass.convertToJSON(this.normalize(record), postWarnings: false);
    }

    *normalize { |value|
        var result, name, ratios, tuning;

        if(value.isNil) { ^nil };
        if(value.isKindOf(Boolean) or: { value.isKindOf(SimpleNumber) }
            or: { value.isKindOf(String) }) {
            ^value;
        };
        if(value.isKindOf(Symbol)) {
            ^(awbType: "symbol", value: value.asString);
        };
        if(value.isKindOf(Char)) {
            ^(awbType: "char", value: value.asString);
        };
        if(value.isKindOf(Scale)) {
            name = if(value.respondsTo(\name)) { value.name } { nil };
            ratios = if(value.respondsTo(\ratios)) { value.ratios } { [] };
            tuning = if(value.respondsTo(\tuning)) { value.tuning } { nil };
            ^(
                awbType: "scale",
                name: this.normalize(name),
                ratios: this.normalize(ratios),
                tuning: this.normalize(tuning)
            );
        };
        if(value.isKindOf(Tuning)) {
            name = if(value.respondsTo(\name)) { value.name } { nil };
            ratios = if(value.respondsTo(\ratios)) { value.ratios } { [] };
            ^(
                awbType: "tuning",
                name: this.normalize(name),
                ratios: this.normalize(ratios)
            );
        };
        if(value.isKindOf(Dictionary)) {
            result = Dictionary.new;
            result["awbType"] = if(value.isKindOf(Event)) { "event" } { "dictionary" };
            value.keysValuesDo { |key, item|
                result[key.asString] = this.normalize(item);
            };
            ^result;
        };
        if(value.isKindOf(SequenceableCollection)) {
            ^value.collect { |item| this.normalize(item) }.asArray;
        };
        if(value.isKindOf(Date)) {
            ^(awbType: "date", value: value.asString);
        };
        ^(
            awbType: "unsupported",
            class: value.class.name.asString
        );
    }
}
