/*
 * EventPreset System - Interactive Code Library for SuperCollider Events
 *
 * Core component of the awbCollider preset system providing organized storage,
 * retrieval, and manipulation of SuperCollider Event objects with rich metadata.
 *
 * ARCHITECTURE OVERVIEW:
 * - EventPreset: Individual preset with metadata (this class)
 * - EventPresetLibrary: Collection manager with persistence
 * - Presets: Global singleton for Ndef-like access (Presets[\name])
 * - EventPresetGUI: Visual browser with drag/drop workflows
 *
 * KEY FEATURES:
 * 1. Clean Event Storage: Events cleaned of runtime contamination before storage
 * 2. Hierarchical Addressing: Folder-like organization independent of preset names
 * 3. Connected Events: Bracket notation returns events that sync back to library
 * 4. Rich Event Workflows: Events can carry preset metadata for round-trip editing
 * 5. Derivation System: Create variations with automatic origin tracking
 * 6. Resource Management: Integration with Playlist system for live performance
 *
 * DESIGN PATTERNS (see claude.md):
 * - Constructor Pattern: Automatic initialization, no separate .init() calls
 * - Observer Pattern: GUI updates via library change notifications
 * - Graceful Integration: Works standalone or with broader awbCollider ecosystem
 * - Event Cleaning: Robust separation of musical vs runtime parameters
 *
 * USAGE EXAMPLES:
 *   // Basic creation
 *   ~preset = EventPreset(\myPreset, (instrument: \sine, freq: 440), "music/test");
 *
 *   // Via global singleton
 *   Presets.add((instrument: \sine, freq: 440), \myPreset, "music/test");
 *
 *   // Connected event access
 *   ~connectedEvent = Presets[\myPreset];  // Returns connected event
 *   ~connectedEvent[\freq] = 880;          // Modify parameters
 *   Presets.library.updateFromConnectedEvent(~connectedEvent);  // Sync back
 *
 *   // Rich event workflow
 *   (instrument: \sine, freq: 440,
 *    presetName: \myPreset, presetAddress: "music/test").addPreset;
 *
 * INTEGRATION WITH AWBCOLLIDER:
 * - Designed for sonic attunement research and musical discovery workflows
 * - Integrates with performance system via Playlist resource management
 * - Compatible with awbCollider synthesis tools (substrate, beatExplorer, etc.)
 * - Supports hierarchical organization for frequency-based therapeutic work
 */

EventPreset {
    var <name, <event, <address, <tags, <notes, <timestamp;
    var <playingInstances;
    var <presetOrigin, <presetOverrides; // For derivation tracking
    var <isFavourite; // Star/favourite status
    var <origin; // Durable cross-domain provenance, separate from musical Event data

    *new { |name, event, address="uncategorized", tags=#[], notes=""|
        // Validate that name is not nil
        if(name.isNil) {
            "Error: Cannot create EventPreset with nil name".error;
            ^nil;
        };
        ^super.newCopyArgs(name, this.cleanEvent(event), address, tags, notes,
            Date.getDate, [], nil, nil, false, nil)
    }

    /*
     * Clean an event of runtime contamination before saving
     *
     * Removes all keys that are added by Event.play() and SuperCollider runtime,
     * keeping only musical parameters suitable for preset storage.
     *
     * CRITICAL FUNCTION: This ensures preset events contain only musical intent,
     * not implementation artifacts that could cause issues on reload.
     *
     * Args:
     *   event - SuperCollider Event to clean
     *
     * Returns:
     *   New Event containing only musical parameters
     *
     * Implementation Note:
     *   The runtimeKeys array is carefully curated based on SuperCollider internals.
     *   Changes to this list should be tested thoroughly as they affect all presets.
     */
    *cleanEvent { |event|
        var cleanedEvent, runtimeKeys;

		//original event cleaning. seems a bit to aggressive

        // Keys added by Event.play and runtime that should not be saved
        /*runtimeKeys = #[server, isPlaying, hasGate, id, msgFunc, delta, sustain,
                       parent, proto, know, eventTypes, parentTypes, addAction, group,
                       schedBundle, schedBundleArray, getBundleArgs, synthDefName,
                       getMsgFunc, defaultMsgFunc, freeServerNode, releaseServerNode,
                       schedStrummedNote, detunedFreq, midinote, note, freqToNote,
                       freqToScale, play, type, out, lag, strum, strumEndsTogether,
                       timingOffset, genflags, gencmd, genarray, midicmd, midiEventFunctions,
                       args, velocity, pan, trig, db, octave, root, degree, scale,
                       stepsPerOctave, octaveRatio, harmonic, mtranspose, gtranspose,
                       ctranspose, detune, legato, stretch, frame, numframes,
                       numchannels, bufnum, bufpos, leaveOpen, filename];*/

		runtimeKeys = #[server, isPlaying, hasGate, id, msgFunc,
			parent, proto, know, eventTypes, parentTypes, schedBundle, schedBundleArray,
			getBundleArgs, getMsgFunc, defaultMsgFunc, freeServerNode, releaseServerNode,
			schedStrummedNote, freqToNote,
			freqToScale, play, lag, strum, strumEndsTogether,
			genflags, gencmd, genarray, midicmd, midiEventFunctions,
			args, velocity,stepsPerOctave, mtranspose, gtranspose,
			ctranspose, stretch, frame, numframes,
			leaveOpen];

        // Create clean event with only musical parameters
        cleanedEvent = Event.new;

        event.keysValuesDo({ |key, value|
            // Only save keys that are NOT in the runtime contamination list or preset metadata
            var isPresetMetadata = [\presetName, \presetAddress, \presetTags,
                \presetNotes].includes(key);
            var isReservedMetadata = key.asString.beginsWith("__");
            if(runtimeKeys.includes(key).not
                && isPresetMetadata.not
                && isReservedMetadata.not) {
                cleanedEvent[key] = value;
            };
        });

        ^cleanedEvent;
    }

    // Create preset from current event with metadata
    *fromEvent { |event, name, address="uncategorized", tags=#[], notes=""|
        ^this.new(name, this.cleanEvent(event), address, tags, notes)
    }

    // Create preset from event with default address
    *fromEventAuto { |event, name, tags=#[], notes=""|
        ^this.new(name, this.cleanEvent(event), "uncategorized event", tags, notes)
    }

    // Play the stored event with self-tracking and observer callbacks
    play { |server, overrides|
        var playedEvent, finalEvent;

        // Apply any overrides to the base event
        finalEvent = if(overrides.notNil) {
            event.copy.putAll(overrides)
        } {
            event.copy
        };

        // Event.play takes no server argument; route explicitly through the event.
        if(server.notNil) {
            finalEvent[\server] = server;
        };
        playedEvent = finalEvent.play;
        ("Playing preset: " ++ name ++ if(overrides.notNil) { " (with overrides)" } { "" }).postln;

        // Self-manage: add to own instance tracking
        playingInstances = playingInstances.add(playedEvent);

        // Set up observer callback for this specific instance
        this.setupInstanceTracking(playedEvent, overrides);

        // Register with NodeManager for tracking
        NodeManager.register(playedEvent, \preset, (
            preset: this,
            presetName: name,
            address: address,
            tags: tags,
            overrides: overrides,
            parentPreset: this,
            origin: if(origin.notNil) { origin.deepCopy } { nil }
        ));

        // Notify NodeManager of new instance
        NodeManager.notifyObservers(\presetInstanceStarted, (
            preset: this,
            event: playedEvent,
            overrides: overrides,
            address: address,
            tags: tags
        ));

        // Register with Playlist for backward compatibility (will be deprecated)
        Playlist.add(playedEvent, name.asSymbol, \event);

        ^playedEvent;
    }

    // Alias for tracking (same as play since EventPreset.play already registers)
    playTracked { |server, overrides|
        ^this.play(server, overrides);
    }

    // Set up lifecycle tracking for a specific instance
    setupInstanceTracking { |playedEvent, overrides|
        var nodeIDs, server, responder;

        // Get node information for OSC monitoring
        nodeIDs = playedEvent[\id];
        server = playedEvent[\server] ? Server.default;

        if(nodeIDs.notNil) {
            // Set up OSC monitoring for when this instance ends
            responder = OSCFunc({ |msg|
                var endedNodeID = msg[1];

                if(nodeIDs.asArray.includes(endedNodeID)) {
                    // Self-manage: remove from own tracking when instance ends
                    playingInstances.remove(playedEvent);

                    // Notify NodeManager of instance ending
                    NodeManager.notifyObservers(\presetInstanceEnded, (
                        preset: this,
                        event: playedEvent,
                        overrides: overrides
                    ));

                    // Clean up the OSC responder
                    responder.free;

                    ("Preset instance ended: " ++ name).postln;
                };
            }, '/n_end', server.addr);
        };
    }

    // Container methods to access all instances (EventPreset self-manages these)
    getAllInstances {
        ^playingInstances.copy;
    }

    stopAllInstances {
        var instancesCopy = playingInstances.copy;
        instancesCopy.do({ |playedEvent|
            // Stop the event
            if(playedEvent.respondsTo(\stop)) {
                playedEvent.stop;
            } {
                // For Events, try to free the nodes
                if(playedEvent[\id].notNil) {
                    playedEvent[\id].asArray.do({ |nodeID|
                        if(nodeID.notNil) {
                            (playedEvent[\server] ? Server.default).sendMsg("/n_free", nodeID);
                        };
                    });
                };
            };
        });

        // Clear our tracking (OSC callbacks will handle the rest)
        playingInstances = [];

        ("Stopped all instances of preset: " ++ name).postln;
    }

    // Get count of currently playing instances
    getInstanceCount {
        ^playingInstances.size;
    }

    // Check if any instances are playing (existing method compatibility)
    // This overrides the existing isPlaying method to use our self-tracked state
    isPlaying {
        ^playingInstances.size > 0;
    }

    // Group control methods - query Playlist for all instances of this preset

    // Get all currently playing instances of this preset (including derivatives/overrides)
    playing {
        ^Playlist.playing.select({ |item| item.presetKey == name.asSymbol });
    }

    // Count of all playing instances (for backward compatibility)
    playingCount {
        ^this.getInstanceCount;
    }

    // Stop all playing instances of this preset
    stopAll {
        Playlist.stopPreset(name.asSymbol);
        ("Stopped all instances of preset: " ++ name).postln;
    }

    // Get playing instances with their ages
    playingStatus {
        var instances = this.playing;
        if(instances.isEmpty) {
            (name.asString ++ ": not playing").postln;
        } {
            (name.asString ++ ": " ++ instances.size ++ " playing instances").postln;
            instances.do({ |item, i|
                var age = Date.getDate.rawSeconds - item.startTime.rawSeconds;
                ("  [" ++ (i+1) ++ "] " ++ item.presetType ++ " - " ++ age.round(0.1) ++ "s").postln;
            });
        };
    }

    // Get the event as a pattern (useful for sequences)
    asPattern { |repeats=1|
        ^Pseq([event], repeats)
    }

    // Convenience method for creating overrides - returns connected event with overrides
    with { |overrides|
        ^this.asConnectedEvent.with(overrides);
    }

    // Add/modify metadata
    addTag { |tag|
        if(tags.includes(tag).not) {
            tags = tags ++ [tag];
        };
    }

    removeTag { |tag|
        tags = tags.reject({ |t| t == tag });
    }

    setAddress { |newAddress|
        address = newAddress;
    }

    // Get address components as array
    addressParts {
        ^address.split($/)
    }

    // Get top-level namespace (e.g., "sonic_attunement" from "sonic_attunement/144Hz/opening")
    namespace {
        ^this.addressParts[0]
    }

    // Get sub-address (everything after first /)
    subAddress {
        var parts = this.addressParts;
        if(parts.size > 1) {
            ^parts[1..].join("/")
        } {
            ^""
        }
    }

    addNotes { |additionalNotes|
        if(notes.isEmpty) {
            notes = additionalNotes;
        } {
            notes = notes ++ "\n" ++ additionalNotes;
        };
    }

    setNotes { |newNotes|
        notes = newNotes;
    }

    // Favourite management
    setFavourite { |state=true|
        isFavourite = state;
    }

    toggleFavourite {
        isFavourite = isFavourite.not;
        ^isFavourite;
    }

    star {
        this.setFavourite(true);
    }

    unstar {
        this.setFavourite(false);
    }

    // Get preset info as a readable string
    info {
        ^"Preset: % | Address: % | Tags: % | Created: %\nNotes: %\nEvent: %".format(
            name, address, tags, timestamp.format("%Y-%m-%d %H:%M"),
            notes.isEmpty.if("(none)", notes), event
        );
    }

    // Convert to dictionary for saving
    asDict {
        ^(
            name: name,
            event: event,
            address: address,
            tags: tags,
            notes: notes,
            timestamp: timestamp,
            isFavourite: isFavourite,
            origin: if(origin.notNil) { origin.deepCopy } { nil },
            version: "1.2"
        );
    }

    // Create from saved dictionary
    *fromDict { |dict|
        var preset = this.new(
            dict.name,
            dict.event,
            dict.address ? (dict.category ? "uncategorized"), // backward compatibility
            dict.tags ? #[],
            dict.notes ? ""
        ).timestamp_(dict.timestamp ? Date.getDate);

        // Set favourite status (default false for backward compatibility)
        preset.setFavourite(dict.isFavourite ? false);
        preset.setDurableOrigin(dict.origin);

        ^preset;
    }

    // Private setter for timestamp (used when loading)
    timestamp_ { |ts| timestamp = ts; }

    // Private setter for event (used when syncing from connected events)
    event_ { |newEvent| event = newEvent; }

    /*
     * Create a connected preset event that syncs back to this preset
     *
     * CORE INNOVATION: Connected events enable bi-directional workflows where
     * modifications to events can sync back to the original preset.
     *
     * Connected events contain special metadata keys:
     * - __presetKey: Symbol identifying the source preset
     * - __presetModel: Tool model for intelligent handling
     * - __presetOrigin: If derived, the original preset key
     * - __presetOverrides: If derived, the parameter overrides
     *
     * WORKFLOW INTEGRATION:
     * 1. User gets connected event: Presets[\name]
     * 2. User modifies parameters: connectedEvent[\freq] = 880
     * 3. System syncs back: Presets.library.updateFromConnectedEvent(connectedEvent)
     * 4. Original preset updated with modifications
     *
     * This enables live editing workflows where preset modifications persist
     * automatically, bridging the gap between exploration and organization.
     *
     * Returns:
     *   Event with original musical parameters plus connection metadata
     */
    asConnectedEvent {
        var connectedEvent = event.copy;

        // Add preset metadata for sync tracking
        connectedEvent[\__presetKey] = name.asSymbol;
        connectedEvent[\__presetModel] = this.detectModel(event);

        // Add origin information if this is a derived preset
        if(presetOrigin.notNil) {
            connectedEvent[\__presetOrigin] = presetOrigin;
            connectedEvent[\__presetOverrides] = presetOverrides;
        };
        if(origin.notNil) {
            connectedEvent[\__presetSource] = origin.deepCopy;
        };

        ^connectedEvent;
    }

    // Detect which tool model should handle this event
    detectModel { |event|
        var instrument = event[\instrument];

        // Simple detection based on instrument - can be extended
        switch(instrument,
            \harmonicOrgan, { \harmonicOrgan },
            \substrate, { \substrate },
            \beatTones, { \beatExplorer },
            // Default fallback
            { \generic }
        );
    }

    // Create derived preset with overrides
    derive { |newName, overrides, newAddress, newTags=#[], newNotes=""|
        var newEvent, derivedPreset, addResult;

        newEvent = event.copy;

        // Apply overrides to event
        overrides.keysValuesDo({ |key, value|
            newEvent[key] = value;
        });

        // Create new preset with derivation metadata
        derivedPreset = EventPreset.new(
            newName,
            newEvent,
            newAddress ? address,
            newTags,
            newNotes
        );

        // Add derivation tracking (stored as preset metadata, not in event)
        derivedPreset.setOrigin(name.asSymbol, overrides);

        // Add to library automatically - derived presets should be accessible
        addResult = Presets.default.addPreset(derivedPreset);

        // Only return the preset if it was successfully added to the library
        if(addResult.notNil) {
            ^derivedPreset;
        } {
            ^nil;  // Addition was blocked (collision, etc.)
        };
    }

    // Set origin information for derived presets
    setOrigin { |originKey, overrides|
        presetOrigin = originKey;
        presetOverrides = overrides;
    }

    setDurableOrigin { |anOrigin|
        origin = if(anOrigin.notNil) { anOrigin.deepCopy } { nil };
        ^this;
    }
}

EventPresetLibrary {
    var <presets, <addresses, <libraryPath, <observers;

    *new { |libraryPath|
        var defaultPath;

        // Get the directory where this class file lives and put presets there
        defaultPath = PathName(EventPresetLibrary.filenameSymbol.asString).pathOnly +/+ "EventPresets.scd";

        ^super.newCopyArgs(Dictionary.new, Set.new,
            libraryPath ? defaultPath, Set.new)
        .init
    }

    init {
        // Try to load existing library
        this.load;
    }

    // Get preset by name
    get { |name|
        ("Looking for preset: " ++ name ++ " | Available: " ++ presets.keys).postln;
        ^presets[name.asSymbol];
    }

    // Play preset by name
    play { |name, server|
        var preset = this.get(name);
        if(preset.notNil) {
            preset.play(server);
        } {
            ("Preset not found: " ++ name).warn;
        };
    }

    // Get the raw event from a preset by name
    getEvent { |name|
        var preset = this.get(name);
        if(preset.notNil) {
            ^preset.event;
        } {
            ("Preset not found: " ++ name).warn;
            ^nil;
        };
    }

    // Remove preset
    remove { |name|
        var nameSymbol = name.asSymbol;
        var preset = presets[nameSymbol];
        if(preset.notNil) {
            presets.removeAt(nameSymbol);
            // Update addresses set
            addresses = Set.new;
            presets.do({ |p| addresses.add(p.address) });
            ("Removed preset: " ++ name).postln;

            // Notify observers of the change
            this.notifyObservers(\removed, preset);
        } {
            ("Preset not found: " ++ name).warn;
        };
    }

    // List all presets organized by address hierarchy
    list { |addressFilter|
        if(presets.isEmpty) {
            "No presets in library".postln;
            ^this;
        };

        "=== Event Preset Library ===".postln;

        if(addressFilter.notNil) {
            ("Filtering by: " ++ addressFilter).postln;
            this.byAddress(addressFilter).keysValuesDo { |name, preset|
                ("  " ++ name ++ " [" ++ preset.address ++ "] [" ++ preset.tags.join(", ") ++ "]").postln;
            };
        } {
            this.getNamespaces.asArray.sort.do { |namespace|
                ("\n" ++ namespace.asString.toUpper ++ ":").postln;
                this.byNamespace(namespace).keysValuesDo { |name, preset|
                    ("  " ++ name ++ " [" ++ preset.address ++ "] [" ++ preset.tags.join(", ") ++ "]").postln;
                };
            };
        };
    }

    // Get all unique namespaces (top-level address parts)
    getNamespaces {
        ^Set.newFrom(presets.collect({ |preset| preset.namespace }));
    }

    // Get all unique addresses under a namespace or address prefix
    getSubAddresses { |addressPrefix=""|
        var filteredPresets = this.byAddress(addressPrefix);
        var subAddresses = Set.new;

        filteredPresets.do({ |preset|
            var parts = preset.addressParts;
            var prefixParts = addressPrefix.split($/);

            if(parts.size > prefixParts.size) {
                var nextPart = prefixParts.join("/") ++ "/" ++ parts[prefixParts.size];
                subAddresses.add(nextPart);
            };
        });

        ^subAddresses;
    }

    // Find presets by exact address
    byExactAddress { |address|
        ^presets.select({ |preset| preset.address == address });
    }

    // Find presets by address prefix (hierarchical filtering)
    byAddress { |addressPrefix=""|
        if(addressPrefix.isEmpty) {
            ^presets;
        };
        ^presets.select({ |preset| preset.address.beginsWith(addressPrefix) });
    }

    // Find presets by namespace (top-level address part)
    byNamespace { |namespace|
        ^presets.select({ |preset| preset.namespace == namespace });
    }

    // Find presets by tag
    byTag { |tag|
        ^presets.select({ |preset| preset.tags.includes(tag) });
    }

    // Reverse provenance lookups for Events promoted from Tools.
    bySourceTool { |toolID|
        if(toolID.isNil) { Error("Source Tool ID is required").throw };
        toolID = toolID.asSymbol;
        ^presets.select { |preset|
            preset.origin.notNil
                and: { preset.origin[\toolID] == toolID }
        };
    }

    byToolInstance { |instanceID|
        if(instanceID.isNil) { Error("ToolInstance ID is required").throw };
        instanceID = instanceID.asString;
        ^presets.select { |preset|
            preset.origin.notNil
                and: { preset.origin[\toolInstance].asString == instanceID }
        };
    }

    bySourceToolPreset { |presetRefOrKey|
        var key, domain, revision, fingerprint;

        if(presetRefOrKey.isNil) { Error("Source ToolPreset reference is required").throw };
        if(presetRefOrKey.isKindOf(Event)) {
            key = presetRefOrKey[\key].asSymbol;
            domain = presetRefOrKey[\domain] ? \tool;
            revision = presetRefOrKey[\revision];
            fingerprint = presetRefOrKey[\fingerprint];
        } {
            key = presetRefOrKey.asSymbol;
            domain = \tool;
        };
        ^presets.select { |preset|
            var sourceRef;
            sourceRef = if(preset.origin.notNil) {
                preset.origin[\sourceToolPreset]
            } { nil };
            sourceRef.notNil
                and: { sourceRef[\domain] == domain }
                and: { sourceRef[\key] == key }
                and: { revision.isNil or: { sourceRef[\revision] == revision } }
                and: { fingerprint.isNil
                    or: { sourceRef[\fingerprint] == fingerprint } }
        };
    }

    // Find favourite presets
    favourites {
        ^presets.select({ |preset| preset.isFavourite });
    }

    // Find non-favourite presets
    nonFavourites {
        ^presets.select({ |preset| preset.isFavourite.not });
    }

    // Find exact duplicates or subsets
    findDuplicates { |newEvent|
        var duplicates = [];

        presets.do({ |preset|
            var existingEvent = preset.event;

            // Exact match
            if(this.eventsEqual(newEvent, existingEvent)) {
                duplicates = duplicates.add((preset: preset, type: \exact));
            } {
                // Subset check - new event is contained within existing
                if(this.isSubsetOf(newEvent, existingEvent)) {
                    duplicates = duplicates.add((preset: preset, type: \subset));
                };
            };
        });

        ^duplicates;
    }

    // Check if two events are exactly equal
    eventsEqual { |event1, event2|
        var keys1 = event1.keys.asSet;
        var keys2 = event2.keys.asSet;

        // Must have same keys
        if(keys1 != keys2) { ^false };

        // Must have same values for all keys
        ^keys1.every({ |key|
            event1[key] == event2[key]
        });
    }

    // Check if event1 is a subset of event2
    isSubsetOf { |event1, event2|
        // All keys in event1 must exist in event2 with same values
        ^event1.keys.every({ |key|
            event2[key] == event1[key]
        });
    }

    // Search presets by name, address, or tags
    search { |query|
        var queryLower = query.asString.toLower;
        ^presets.select({ |preset|
            preset.name.asString.toLower.contains(queryLower) ||
            preset.address.asString.toLower.contains(queryLower) ||
            preset.tags.any({ |tag| tag.asString.toLower.contains(queryLower) }) ||
            preset.notes.asString.toLower.contains(queryLower)
        });
    }

    // Save library to disk
    save {
        var presetsDict = Dictionary.new;
        var data;

        // Convert presets to dictionary format
        presets.keysValuesDo { |name, preset|
            presetsDict[name] = preset.asDict;
        };

        data = (
            presets: presetsDict,
            addresses: addresses.asArray,
            saved: Date.getDate,
            version: "1.0"
        );

        File.use(libraryPath, "w", { |file|
            file.write(data.asCompileString);
        });

        ("Saved " ++ presets.size ++ " presets to: " ++ libraryPath).postln;
    }

    // Load library from disk
    load {
        if(File.exists(libraryPath)) {
            var data = libraryPath.load;
            if(data.notNil && data.presets.notNil) {
                var loadedCount = 0, skippedCount = 0;
                presets = Dictionary.new;
                data.presets.keysValuesDo { |name, presetDict|
                    var preset;
                    // Skip corrupted entries with nil names
                    if(name.isNil || name.asString == "nil") {
                        ("Skipping corrupted preset with nil name").warn;
                        skippedCount = skippedCount + 1;
                    } {
                        preset = EventPreset.fromDict(presetDict);
                        if(preset.notNil) {
                            presets[name.asSymbol] = preset;
                            loadedCount = loadedCount + 1;
                        } {
                            ("Skipping corrupted preset: " ++ name).warn;
                            skippedCount = skippedCount + 1;
                        };
                    };
                };
                // Handle both old (categories) and new (addresses) format
                addresses = Set.newFrom(data.addresses ? data.categories ? []);
                ("Loaded " ++ loadedCount ++ " presets from: " ++ libraryPath).postln;
                if(skippedCount > 0) {
                    ("Skipped " ++ skippedCount ++ " corrupted presets").warn;
                };
            };
        } {
            ("No existing library found at: " ++ libraryPath).postln;
            ("Will create new library when first preset is saved.").postln;
        };
    }

    // Auto-save (call this periodically if desired)
    autoSave {
        this.save;
    }

    // Add method with auto-detection of address
    add { |event, name, address, tags=#[], notes="", checkDuplicates=true|
        var preset;

        // If first argument is already an EventPreset, use the original add method
        if(event.isKindOf(EventPreset)) {
            ^this.addPreset(event, checkDuplicates: checkDuplicates);
        };

        // Auto-detect address if not provided
        if(address.isNil) {
            preset = EventPreset.fromEventAuto(event, name, tags, notes);
        } {
            preset = EventPreset.fromEvent(event, name, address, tags, notes);
        };

        ^this.addPreset(preset, checkDuplicates: checkDuplicates);
    }

    // Observer pattern for GUI updates
    addObserver { |observer|
        observers.add(observer);
    }

    removeObserver { |observer|
        observers.remove(observer);
    }

    notifyObservers { |action, data|
        observers.do({ |observer|
            observer.libraryChanged(action, data);
        });
    }

    // Internal method for adding EventPreset objects with collision checking
    addPreset { |preset, allowOverwrite=false, checkDuplicates=true|
        var nameSymbol, existingPreset, choice, newName, duplicates, similar, action;

        // Validate preset is not nil
        if(preset.isNil) {
            "Error: Cannot add nil preset to library".error;
            ^nil;
        };

        // Validate preset name is not nil
        if(preset.name.isNil) {
            "Error: Cannot add preset with nil name to library".error;
            ^nil;
        };

        nameSymbol = preset.name.asSymbol;
        existingPreset = presets[nameSymbol];

        if(preset.isKindOf(EventPreset).not) {
            "Error: Can only add EventPreset objects".error;
            ^nil;
        };

        // Check for collision
        if(existingPreset.notNil && allowOverwrite.not) {
            choice = this.promptForOverwrite(preset, existingPreset);
            if(choice == \cancel) {
                ("Cancelled adding preset: " ++ preset.name).postln;
                ^nil;
            };
            if(choice == \rename) {
                newName = this.promptForNewName(preset.name);
                if(newName.notNil) {
                    preset = EventPreset.new(newName, preset.event, preset.address, preset.tags, preset.notes);
                    nameSymbol = newName.asSymbol;
                } {
                    ("Cancelled adding preset: " ++ preset.name).postln;
                    ^nil;
                };
            };
            // If choice == \overwrite, proceed with original name
        };

        // Check for duplicates
        if(checkDuplicates) {
            duplicates = this.findDuplicates(preset.event);

            if(duplicates.size > 0) {
                ("=== DUPLICATE DATA WARNING ===").warn;
                duplicates.do({ |dup|
                    switch(dup.type,
                        \exact, {
                            ("Exact duplicate of preset '" ++ dup.preset.name ++ "' [" ++ dup.preset.address ++ "]").warn;
                        },
                        \subset, {
                            ("This event is contained within preset '" ++ dup.preset.name ++ "' (which has additional parameters)").postln;
                        }
                    );
                });
                "Proceeding anyway - consider if you need this duplicate".postln;
            };
        };

        presets[nameSymbol] = preset;
        addresses.add(preset.address);

        action = existingPreset.notNil.if(\updated, \added);
        ("Added preset: " ++ preset.name ++ " | Address: " ++ preset.address ++ " | Total presets: " ++ presets.size).postln;

        // Notify observers of the change
        this.notifyObservers(action, preset);

        ^preset;
    }

    // Prompt user for overwrite decision with GUI dialog
    promptForOverwrite { |newPreset, existingPreset|
        ^this.showCollisionDialog(newPreset, existingPreset);
    }

    // Show collision info window and block addition
    showCollisionDialog { |newPreset, existingPreset|
        var infoWindow;

        // Create larger info window to show full preset details
        infoWindow = Window("⚠️ PRESET COLLISION WARNING ⚠️", Rect(200, 100, 700, 500))
            .background_(Color.yellow(0.9))
            .alwaysOnTop_(true);

        // Big warning
        StaticText(infoWindow, Rect(20, 20, 660, 40))
            .string_("COLLISION: Preset '" ++ newPreset.name ++ "' already exists!")
            .font_(Font.default.size_(18).bold_(true))
            .align_(\center)
            .stringColor_(Color.red);

        // Existing preset section
        StaticText(infoWindow, Rect(20, 80, 200, 25))
            .string_("EXISTING PRESET:")
            .font_(Font.default.size_(14).bold_(true))
            .stringColor_(Color.red);

        // Existing preset metadata
        StaticText(infoWindow, Rect(30, 110, 80, 20)).string_("Address:");
        StaticText(infoWindow, Rect(110, 110, 250, 20))
            .string_(existingPreset.address)
            .font_(Font.monospace(10));

        StaticText(infoWindow, Rect(380, 110, 80, 20)).string_("Created:");
        StaticText(infoWindow, Rect(460, 110, 220, 20))
            .string_(existingPreset.timestamp.format("%Y-%m-%d %H:%M"))
            .font_(Font.monospace(10));

        StaticText(infoWindow, Rect(30, 135, 80, 20)).string_("Tags:");
        StaticText(infoWindow, Rect(110, 135, 550, 20))
            .string_(existingPreset.tags.join(", "))
            .font_(Font.monospace(10));

        // Existing preset event data
        StaticText(infoWindow, Rect(30, 160, 150, 20))
            .string_("Event Data:")
            .font_(Font.default.size_(12).bold_(true));
        TextView(infoWindow, Rect(30, 185, 640, 80))
            .string_(existingPreset.event.cs)
            .font_(Font.monospace(9))
            .editable_(false)
            .background_(Color.white);

        // New preset section
        StaticText(infoWindow, Rect(20, 280, 200, 25))
            .string_("NEW PRESET:")
            .font_(Font.default.size_(14).bold_(true))
            .stringColor_(Color.blue);

        // New preset metadata
        StaticText(infoWindow, Rect(30, 310, 80, 20)).string_("Address:");
        StaticText(infoWindow, Rect(110, 310, 250, 20))
            .string_(newPreset.address)
            .font_(Font.monospace(10));

        StaticText(infoWindow, Rect(380, 310, 80, 20)).string_("Tags:");
        StaticText(infoWindow, Rect(460, 310, 220, 20))
            .string_(newPreset.tags.join(", "))
            .font_(Font.monospace(10));

        // New preset event data
        StaticText(infoWindow, Rect(30, 335, 150, 20))
            .string_("Event Data:")
            .font_(Font.default.size_(12).bold_(true));
        TextView(infoWindow, Rect(30, 360, 640, 80))
            .string_(newPreset.event.cs)
            .font_(Font.monospace(9))
            .editable_(false)
            .background_(Color.white);

        // Action taken notice
        StaticText(infoWindow, Rect(20, 450, 660, 40))
            .string_("❌ PRESET ADDITION BLOCKED ❌\nClose this window and rename your preset or modify the data")
            .font_(Font.default.size_(12).bold_(true))
            .align_(\center)
            .stringColor_(Color.red);

        infoWindow.front;

        ("=== PRESET COLLISION - BLOCKING ADD ===").error;
        ("Preset '" ++ newPreset.name ++ "' already exists!").error;
        ("EXISTING: " ++ existingPreset.address ++ " (created " ++ existingPreset.timestamp.format("%Y-%m-%d %H:%M") ++ ")").warn;
        ("  Event: " ++ existingPreset.event.cs).warn;
        ("NEW: " ++ newPreset.address).warn;
        ("  Event: " ++ newPreset.event.cs).warn;
        ("ACTION: Preset addition BLOCKED to prevent data loss").error;

        ^\cancel; // Block the addition
    }

    // Prompt for new name
    promptForNewName { |originalName|
        var baseName = originalName.asString;
        var counter = 1;
        var newName;

        // Auto-generate a non-conflicting name
        loop {
            newName = (baseName ++ "_" ++ counter).asSymbol;
            if(presets[newName].isNil) {
                ("Auto-generated new name: " ++ newName).postln;
                ^newName;
            };
            counter = counter + 1;
            if(counter > 99) {
                "Could not generate unique name".error;
                ^nil;
            };
        };
    }

    // Update preset from connected event (called when connected events are played/modified)
    updateFromConnectedEvent { |connectedEvent|
        var presetKey = connectedEvent[\__presetKey];
        var preset = presets[presetKey];
        var cleanEvent;

        if(preset.notNil) {
            // Create clean event without preset metadata
            cleanEvent = connectedEvent.copy;
            cleanEvent.removeAt(\__presetKey);
            cleanEvent.removeAt(\__presetModel);
            cleanEvent.removeAt(\__presetOrigin);
            cleanEvent.removeAt(\__presetOverrides);
            cleanEvent.removeAt(\__presetSource);
            cleanEvent.parent = nil; // Remove parent reference

            // Update the preset's event
            preset.event = cleanEvent;

            ("Updated preset '" ++ presetKey ++ "' from connected event").postln;

            // Notify observers of the change
            this.notifyObservers(\updated, preset);
        } {
            ("Warning: Connected event references unknown preset: " ++ presetKey).warn;
        };
    }
}

// Global singleton access - like Ndef but for presets
Presets {
    classvar <default;

    *initClass {
        default = EventPresetLibrary.new;
    }

    // Enable bracket notation: Presets[\name] - returns connected preset event
    *at { |key|
        var preset = default.presets[key.asSymbol];
        if(preset.notNil) {
            ^preset.asConnectedEvent;
        } {
            ^nil;
        };
    }

    // Get the raw EventPreset object (not connected event)
    *preset { |key|
        ^default.presets[key.asSymbol];
    }

    // Handle bracket notation via doesNotUnderstand (class method)
    *doesNotUnderstand { |selector ...args|
        if(selector == \add && args.size == 1) {
            // This is bracket notation: Presets[\key]
            ^this.at(args[0]);
        } {
            ^super.doesNotUnderstand(selector, *args);
        };
    }

    // Handle bracket notation via doesNotUnderstand (instance method)
    doesNotUnderstand { |selector ...args|
        if(selector == \add && args.size == 1) {
            // This is bracket notation on an instance: redirect to class method
            ^this.class.at(args[0]);
        } {
            ^super.doesNotUnderstand(selector, *args);
        };
    }

    // Add presets: Presets.add(event, name, address, tags, notes)
    *add { |event, name, address, tags=#[], notes=""|
        ^default.add(event, name, address, tags, notes);
    }

    // Remove presets: Presets.remove(name)
    *remove { |name|
        ^default.remove(name);
    }

    // Find presets by tag
    *byTag { |tag|
        ^default.byTag(tag);
    }

    // Favourite management
    *favourites {
        ^default.favourites;
    }

    *star { |presetKey|
        var preset = default.presets[presetKey.asSymbol];
        if(preset.notNil) {
            preset.star;
            ("Starred preset: " ++ presetKey).postln;
        } {
            ("Preset not found: " ++ presetKey).warn;
        };
    }

    *unstar { |presetKey|
        var preset = default.presets[presetKey.asSymbol];
        if(preset.notNil) {
            preset.unstar;
            ("Unstarred preset: " ++ presetKey).postln;
        } {
            ("Preset not found: " ++ presetKey).warn;
        };
    }

    *toggleStar { |presetKey|
        var preset = default.presets[presetKey.asSymbol];
        if(preset.notNil) {
            var newState = preset.toggleFavourite;
            ("Preset " ++ presetKey ++ (newState.if(" starred", " unstarred"))).postln;
            ^newState;
        } {
            ("Preset not found: " ++ presetKey).warn;
            ^nil;
        };
    }

    // Group control methods - global access

    // Get all playing instances of a preset: Presets.playingInstances(\mysticalPad)
    *playingInstances { |presetKey|
        var preset = default.presets[presetKey.asSymbol];
        if(preset.notNil) {
            ^preset.playing;
        } {
            ("Preset not found: " ++ presetKey).warn;
            ^[];
        };
    }

    // Count playing instances: Presets.playingCount(\mysticalPad)
    *playingCount { |presetKey|
        ^this.playingInstances(presetKey).size;
    }

    // Check if any instances are playing: Presets.isPlaying(\mysticalPad)
    *isPlaying { |presetKey|
        ^this.playingCount(presetKey) > 0;
    }

    // Stop all instances: Presets.stopAllInstances(\mysticalPad)
    *stopAllInstances { |presetKey|
        var preset = default.presets[presetKey.asSymbol];
        if(preset.notNil) {
            preset.stopAll;
        } {
            ("Preset not found: " ++ presetKey).warn;
        };
    }

    // Show status of all playing instances: Presets.instanceStatus(\mysticalPad)
    *instanceStatus { |presetKey|
        var preset = default.presets[presetKey.asSymbol];
        if(preset.notNil) {
            preset.playingStatus;
        } {
            ("Preset not found: " ++ presetKey).warn;
        };
    }

    // Duplicate detection methods
    *findDuplicates { |event|
        ^default.findDuplicates(event);
    }

    *checkSimilarity { |event|
        ^default.checkForSimilarity(event);
    }

    *addWithoutDuplicateCheck { |event, name, address, tags=#[], notes=""|
        ^default.add(event, name, address, tags, notes, false); // checkDuplicates=false
    }

    // Set/add presets: Presets[\name] = preset
    *put { |name, preset|
        if(preset.isKindOf(EventPreset)) {
            default.addPreset(preset);
        } {
            ("Cannot add non-EventPreset to Presets").warn;
        };
    }

    // Play preset: Presets[\name].play
    *play { |name, server|
        var preset = this.at(name);
        if(preset.notNil) {
            preset.play(server);
        } {
            ("Preset not found: " ++ name).warn;
        };
    }

    // Get the raw event: Presets[\name].event
    *event { |name|
        var preset = this.at(name);
        if(preset.notNil) {
            ^preset.event;
        } {
            ("Preset not found: " ++ name).warn;
            ^nil;
        };
    }

    // Access the default library
    *library {
        ^default;
    }

    // GUI access
    *gui {
        ^default.gui;
    }

    // List all presets
    *list {
        ^default.list;
    }

    // Save the library
    *save {
        ^default.save;
    }

    // Playlist management convenience methods
    *playing {
        ^Playlist.playing;
    }

    *stopAll {
        Playlist.stopAll;
    }

    *stopPreset { |presetKey|
        Playlist.stopPreset(presetKey);
    }

    *playlistStatus {
        Playlist.status;
    }

    *playlistGUI {
        ^PlaylistGUI.open;
    }

    // Create derived preset: Presets.derive(\original, \new_name, (freq: 200))
    *derive { |originalName, newName, overrides, newAddress, newTags=#[], newNotes=""|
        var originalPreset = this.preset(originalName);  // Get EventPreset object, not connected event
        var derivedPreset;

        if(originalPreset.notNil) {
            // Use EventPreset's derive method (doesn't auto-add to library)
            derivedPreset = originalPreset.derive(newName, overrides, newAddress, newTags, newNotes);
            if(derivedPreset.notNil) {
                // Add the derived preset to the library
                this.library.addPreset(derivedPreset);
                ^derivedPreset;
            };
        } {
            ("Original preset not found: " ++ originalName).warn;
        };
        ^nil;
    }
}

// Event Sequence - a named collection of presets with playback control
EventSequence {
    var <name, <presets, <address, <tags, <notes, <timestamp;
    var <player, <isPlaying, <tempo, <repeats;

    *new { |name, presets=#[], address="sequences", tags=#[], notes="", tempo=1, repeats=1|
        ^super.newCopyArgs(name, presets, address, tags, notes, Date.getDate,
            nil, false, tempo, repeats)
    }

    // Create sequence from selected presets
    *fromPresets { |presets, name, address="sequences", tags=#[], notes="", tempo=1, repeats=1|
        ^this.new(name, presets, address, tags, notes, tempo, repeats)
    }

    // Add preset to sequence
    addPreset { |preset|
        if(preset.isKindOf(EventPreset)) {
            presets = presets.add(preset);
        } {
            "Error: Can only add EventPreset objects to sequence".error;
        };
    }

    // Remove preset from sequence
    removePreset { |preset|
        presets.remove(preset);
    }

    // Get events array for pattern creation
    events {
        ^presets.collect({ |preset| preset.event });
    }

    // Play the sequence
    play { |server, clock|
		 var pattern;
        if(isPlaying) {
            this.stop;
        };

        pattern = Pseq(this.events, repeats);
        player = pattern.play(clock ? TempoClock.default, quant: 1);
        isPlaying = true;

        // Add to playlist for resource management
        Playlist.add(player, name.asSymbol, \sequence);

        ("Playing sequence: " ++ name ++ " (" ++ presets.size ++ " events)").postln;

        // Monitor for completion in a separate thread
        {
            while { player.isPlaying } { 0.1.wait };
            isPlaying = false;
            ("Sequence finished: " ++ name).postln;
        }.fork;

        ^player;
    }

    // Stop the sequence
    stop {
        if(player.notNil && isPlaying) {
            player.stop;
            isPlaying = false;
            ("Stopped sequence: " ++ name).postln;
        };
    }

    // Pause/resume the sequence
    pause {
        if(player.notNil && isPlaying) {
            player.pause;
            ("Paused sequence: " ++ name).postln;
        };
    }

    resume {
        if(player.notNil && player.isPlaying.not) {
            player.resume;
            ("Resumed sequence: " ++ name).postln;
        };
    }

    // Get sequence info
    info {
        ^"Sequence: % | Address: % | Events: % | Tags: %\nNotes: %\nCreated: %".format(
            name, address, presets.size, tags,
            notes.isEmpty.if("(none)", notes), timestamp.format("%Y-%m-%d %H:%M")
        );
    }

    // Convert to dictionary for saving
    asDict {
        ^(
            name: name,
            presets: presets.collect({ |p| p.name }),  // Store preset names, not full objects
            address: address,
            tags: tags,
            notes: notes,
            timestamp: timestamp,
            tempo: tempo,
            repeats: repeats,
            version: "1.0"
        );
    }

    // Create from saved dictionary (requires preset library for lookup)
    *fromDict { |dict, presetLibrary|
        var sequence = this.new(
            dict.name,
            [],  // Will populate presets below
            dict.address ? "sequences",
            dict.tags ? #[],
            dict.notes ? "",
            dict.tempo ? 1,
            dict.repeats ? 1
        );

        // Look up presets by name
        dict.presets.do({ |presetName|
            var preset = presetLibrary.get(presetName);
            if(preset.notNil) {
                sequence.addPreset(preset);
            } {
                ("Warning: Preset not found when loading sequence: " ++ presetName).warn;
            };
        });

        sequence.timestamp_(dict.timestamp ? Date.getDate);
        ^sequence;
    }

    // Private setter for timestamp
    timestamp_ { |ts| timestamp = ts; }
}

// Sequence Library - manages collections of sequences
EventSequenceLibrary {
    var <sequences, <libraryPath, <observers;

    *new { |libraryPath|
        var defaultPath;

        // Put sequences next to presets
        defaultPath = PathName(EventPreset.filenameSymbol.asString).pathOnly +/+ "EventSequences.scd";

        ^super.newCopyArgs(Dictionary.new,
            libraryPath ? defaultPath, Set.new)
        .init
    }

    init {
        this.load;
    }

    // Observer pattern for GUI updates
    addObserver { |observer|
        observers.add(observer);
    }

    removeObserver { |observer|
        observers.remove(observer);
    }

    notifyObservers { |action, data|
        observers.do({ |observer|
            observer.sequenceLibraryChanged(action, data);
        });
    }

    // Add sequence
    add { |sequence|
        if(sequence.isKindOf(EventSequence).not) {
            "Error: Can only add EventSequence objects".error;
            ^this;
        };

        sequences[sequence.name.asSymbol] = sequence;
        ("Added sequence: " ++ sequence.name ++ " | Events: " ++ sequence.presets.size).postln;

        this.notifyObservers(\added, sequence);
        ^sequence;
    }

    // Get sequence by name
    get { |name|
        ^sequences[name.asSymbol];
    }

    // Remove sequence
    remove { |name|
        var nameSymbol = name.asSymbol;
        var sequence = sequences[nameSymbol];
        if(sequence.notNil) {
            // Stop if playing
            sequence.stop;
            sequences.removeAt(nameSymbol);
            ("Removed sequence: " ++ name).postln;
            this.notifyObservers(\removed, sequence);
        } {
            ("Sequence not found: " ++ name).warn;
        };
    }

    // Get all playing sequences
    playing {
        ^sequences.select({ |seq| seq.isPlaying });
    }

    // Stop all sequences
    stopAll {
        sequences.do({ |seq| seq.stop });
        "Stopped all sequences".postln;
    }

    // Save to disk
    save { |presetLibrary|
        var sequencesDict = Dictionary.new;
        var data;

        sequences.keysValuesDo { |name, sequence|
            sequencesDict[name] = sequence.asDict;
        };

        data = (
            sequences: sequencesDict,
            saved: Date.getDate,
            version: "1.0"
        );

        File.use(libraryPath, "w", { |file|
            file.write(data.asCompileString);
        });

        ("Saved " ++ sequences.size ++ " sequences to: " ++ libraryPath).postln;
    }

    // Load from disk
    load { |presetLibrary|
        if(File.exists(libraryPath)) {
            var data = libraryPath.load;
            if(data.notNil && data.sequences.notNil) {
                sequences = Dictionary.new;
                data.sequences.keysValuesDo { |name, sequenceDict|
                    var sequence = EventSequence.fromDict(sequenceDict, presetLibrary ? Presets.library);
                    sequences[name.asSymbol] = sequence;
                };
                ("Loaded " ++ sequences.size ++ " sequences from: " ++ libraryPath).postln;
            };
        } {
            ("No existing sequence library found at: " ++ libraryPath).postln;
        };
    }

    // List all sequences
    list {
        if(sequences.isEmpty) {
            "No sequences in library".postln;
            ^this;
        };

        "=== Event Sequence Library ===".postln;
        sequences.keysValuesDo { |name, sequence|
            var status = sequence.isPlaying.if("♪ PLAYING", "  ");
            (status ++ " " ++ name ++ " (" ++ sequence.presets.size ++ " events) [" ++ sequence.tags.join(", ") ++ "]").postln;
        };
    }
}

// Global singleton for sequences
Sequences {
    classvar <default;

    *initClass {
        default = EventSequenceLibrary.new;
    }

    // Enable bracket notation: Sequences[\name]
    *at { |key|
        ^default.sequences[key.asSymbol];
    }

    // Handle bracket notation via doesNotUnderstand (class method)
    *doesNotUnderstand { |selector ...args|
        if(selector == \add && args.size == 1) {
            // This is bracket notation: Sequences[\key]
            ^this.at(args[0]);
        } {
            ^super.doesNotUnderstand(selector, *args);
        };
    }

    // Handle bracket notation via doesNotUnderstand (instance method)
    doesNotUnderstand { |selector ...args|
        if(selector == \add && args.size == 1) {
            // This is bracket notation on an instance: redirect to class method
            ^this.class.at(args[0]);
        } {
            ^super.doesNotUnderstand(selector, *args);
        };
    }

    // Add sequences: Sequences.add(sequence)
    *add { |sequence|
        ^default.add(sequence);
    }

    // Play sequence: Sequences[\name].play
    *play { |name|
        var sequence = this.at(name);
        if(sequence.notNil) {
            ^sequence.play;
        } {
            ("Sequence not found: " ++ name).warn;
        };
    }

    // Stop sequence: Sequences[\name].stop
    *stop { |name|
        var sequence = this.at(name);
        if(sequence.notNil) {
            sequence.stop;
        } {
            ("Sequence not found: " ++ name).warn;
        };
    }

    // Stop all sequences
    *stopAll {
        default.stopAll;
    }

    // Get playing sequences
    *playing {
        ^default.playing;
    }

    // Access the library
    *library {
        ^default;
    }

    // List all sequences
    *list {
        ^default.list;
    }

    // Save sequences
    *save {
        ^default.save(Presets.library);
    }
}

// Add simple with method to Event class
+ Event {
    // Simple with method for preset events - checks if it's a connected preset
    with { |overrides|
        var result;

        // Handle nil overrides
        if(overrides.isNil) {
            "Event.with: overrides parameter is nil - use (key: value) syntax".warn;
            ^this;
        };

        result = this ++ overrides;

        // If this is a connected preset event, sync changes back
        if(this[\__presetKey].notNil) {
            Presets.library.updateFromConnectedEvent(result);
        };

        ^result;
    }


    // Derive method for connected preset events
    derive { |newName, overrides, newAddress, newTags, newNotes|
        var originalPresetKey = this[\__presetKey];

        if(originalPresetKey.notNil) {
            // Use the robust static method implementation
            ^Presets.derive(originalPresetKey, newName, overrides, newAddress, newTags, newNotes);
        } {
            "Error: Cannot derive from connected event - missing preset key".error;
            ^nil;
        };
    }

    // Convenience method for adding presets - detects derivation automatically
    addPreset { |name, address, tags=#[], notes=""|
        var preset, originalPresetKey, originalPreset, overrides;
        var finalName, finalAddress, finalTags, finalNotes;
        var cleanedEvent;

        // Extract rich event metadata if available
        if(this[\presetName].notNil) {
            finalName = name ? this[\presetName];
            finalAddress = address ? this[\presetAddress] ? "uncategorized";
            finalTags = (tags.isEmpty).if(this[\presetTags] ? #[], tags);
            finalNotes = notes.isEmpty.if(this[\presetNotes] ? "", notes);

            // Clean the event to remove preset metadata before processing
            cleanedEvent = EventPreset.cleanEvent(this);

            // Check if this should be derivation: rich event with existing presetName but different target name
            if(name.notNil && name.asSymbol != this[\presetName].asSymbol) {
                // Rich event derivation: existing presetName + different target name
                originalPreset = Presets.preset(this[\presetName].asSymbol);

                if(originalPreset.notNil) {
                    // Calculate overrides by comparing cleaned event to original
                    overrides = ();
                    cleanedEvent.keysValuesDo({ |key, value|
                        var keyString = key.asString;
                        var isMetadataKey = keyString.beginsWith("__") ||
                                          [\presetName, \presetAddress, \presetTags, \presetNotes].includes(key);

                        if(isMetadataKey.not && originalPreset.event[key] != value) {
                            overrides[key] = value;
                        };
                    });

                    // Create derived preset
                    preset = originalPreset.derive(name, overrides, finalAddress, finalTags, finalNotes);
                    ("Created derived preset '" ++ name ++ "' from '" ++ this[\presetName] ++ "' with overrides: " ++ overrides).postln;
                } {
                    // Original preset not found, create regular preset
                    preset = EventPreset.fromEvent(cleanedEvent, finalName, finalAddress, finalTags, finalNotes);
                    if(Presets.default.addPreset(preset).isNil) {
                        ^nil;  // Addition failed due to collision
                    };
                    ("Warning: Original preset '" ++ this[\presetName] ++ "' not found, created regular preset").warn;
                };
            } {
                // Simple rich event creation - same name or no name override
                preset = EventPreset.fromEvent(cleanedEvent, finalName, finalAddress, finalTags, finalNotes);
                if(Presets.default.addPreset(preset).isNil) {
                    ^nil;  // Addition failed due to collision
                };
                ("Created preset '" ++ finalName ++ "' from rich event metadata").postln;
            };
        } {
            // Check if this is a connected event from a preset
            originalPresetKey = this[\__presetKey];

            if(originalPresetKey.notNil && name.asSymbol != originalPresetKey) {
            // Different key from parent - create derived preset
            originalPreset = Presets.preset(originalPresetKey);

            if(originalPreset.notNil) {
                // Calculate overrides by comparing this event to original
                overrides = ();
                this.keysValuesDo({ |key, value|
                    // Skip all metadata keys and check for differences
                    var keyString = key.asString;
                    var isMetadataKey = keyString.beginsWith("__") ||
                                      [\presetName, \presetAddress, \presetTags, \presetNotes].includes(key);

                    if(isMetadataKey.not && originalPreset.event[key] != value) {
                        overrides[key] = value;
                    };
                });

                // Use derive method to create proper derived preset
                preset = originalPreset.derive(
                    name,
                    overrides,
                    address ? originalPreset.address,  // Use original address if not specified
                    tags,
                    notes
                );

                ("Created derived preset '" ++ name ++ "' from '" ++ originalPresetKey ++ "' with overrides: " ++ overrides).postln;
            } {
                "Warning: Original preset not found, creating regular preset".warn;
                cleanedEvent = EventPreset.cleanEvent(this);
                preset = EventPreset.fromEvent(cleanedEvent, name, address ? "uncategorized", tags, notes);
                if(Presets.default.addPreset(preset).isNil) {
                    ^nil;  // Addition failed due to collision
                };
            };
            };

            if(originalPresetKey.notNil && name.asSymbol == originalPresetKey) {
                // Same key as parent - update/redefine existing preset
                cleanedEvent = EventPreset.cleanEvent(this);
                preset = EventPreset.fromEvent(cleanedEvent, name, address ? "uncategorized", tags, notes);
                if(Presets.default.addPreset(preset, allowOverwrite: true).isNil) {  // Allow overwrite for redefinition
                    ^nil;  // Addition failed due to collision
                };
                ("Updated existing preset '" ++ name ++ "' with modifications").postln;
            };

            if(originalPresetKey.isNil) {
                // Regular event (no parent) - create normal preset
                cleanedEvent = EventPreset.cleanEvent(this);
                preset = EventPreset.fromEvent(cleanedEvent, name, address ? "uncategorized", tags, notes);
                if(Presets.default.addPreset(preset).isNil) {
                    ^nil;  // Addition failed due to collision
                };
            };
        };

        ^preset;
    }
}

// Add convenience method to Array for adding sequences of presets
+ Array {
    addPresetSequence { |address, tags=#[], notes="", createSequenceObject=true|
        var presets = [];
        var sequenceName, sequence;

        // Extract sequence name from address (last part after /)
        sequenceName = address.split($/).last;

        this.do({ |event, index|
            var presetName, preset;

            // Create indexed name: sequenceName_01, sequenceName_02, etc.
            presetName = sequenceName ++ "_" ++ (index + 1).asString.padLeft(2, "0");

            // Use the address as-is (folder structure only)
            // Name is independent of folder structure
            preset = EventPreset.fromEvent(event, presetName, address, tags, notes);
            Presets.default.addPreset(preset);
            presets = presets.add(preset);
        });

        ("Added sequence '" ++ sequenceName ++ "' with " ++ this.size ++ " presets").postln;

        // Also create an EventSequence object if requested
        if(createSequenceObject) {
            sequence = EventSequence.fromPresets(presets, sequenceName, address, tags, notes);
            Sequences.add(sequence);
            ("Created EventSequence object: Sequences[\\" ++ sequenceName ++ "]").postln;
        };

        ^(presets: presets, sequence: sequence);
    }
}
