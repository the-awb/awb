Tool {
    // Semantic Tool contract. Concrete tools remain independently useful and
    // own their domain operations; ToolInstance owns runtime lifecycle.

    definition {
        this.subclassResponsibility;
    }

    content {
        this.subclassResponsibility;
    }

    contentAt { |key|
        ^this.content[key].deepCopy;
    }

    results {
        ^[];
    }

    resultAt { |index|
        var values;
        values = this.results;
        if(index.isKindOf(Integer).not
            or: { index < 0 }
            or: { index >= values.size }) {
            Error("Tool: result index is out of range").throw;
        };
        ^values[index].deepCopy;
    }

    selection {
        ^nil;
    }

    promotionCandidate {
        this.subclassResponsibility;
    }

    applyPresetConfig { |config, selectedState|
        this.subclassResponsibility;
    }
}
