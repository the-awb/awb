/*
PSequencePlayer - Sequence Navigation with Order-Based Access
============================================================

Simple sequence navigation for arrays of events without timestamps.
Provides random access navigation through event sequences.

Usage:
~events = [(freq: 440), (freq: 880), (freq: 660)];
~player = PSequencePlayer(~events);
~player.play;
~player.jumpToIndex(1);  // Jump to second event
~player.stepForward;     // Next event
*/

PSequencePlayer : PStreamPlayer {
    // Sequence-specific data
    var <sequence;

    *new { |eventArray, templateEvent|
        ^super.new(eventArray, templateEvent);
    }

    // IMPLEMENT ABSTRACT INTERFACE
    
    initializeData { |eventArray|
        sequence = eventArray ? [];
    }
    
    createStreamFrom { |targetIndex|
        var events, callback;
        
        if(sequence.isEmpty) { ^nil };
        if(targetIndex < 0 or: { targetIndex >= sequence.size }) { ^nil };
        
        events = [];
        
        // Convert sequence from targetIndex onwards to stream events
        sequence[targetIndex..].do { |event, i|
            var streamEvent, currentIndex;
            currentIndex = targetIndex + i;
            
            // Use event's own delta/dur, or default
            streamEvent = event.copy;
            if(streamEvent[\delta].isNil) {
                streamEvent[\delta] = streamEvent[\dur] ? 1;
            };
            
            events = events.add(streamEvent);
        };
        
        // Create callback to capture events to performance history
        callback = { |event, streamIndex|
            var sequenceIndex = targetIndex + streamIndex;
            this.addToHistory(event, sequenceIndex);
        };
        
        ^PIndexedStream(events, callback);
    }
    
    eventAtIndex { |index|
        if(index < 0 or: { index >= sequence.size }) { ^nil };
        ^sequence[index].copy;
    }
    
    hasHorizon { ^true }
    
    size { ^sequence.size }

    // SEQUENCE-SPECIFIC METHODS
    
    // Container interface compatibility - return sequence events as children
    children { ^sequence }
    
    getSequenceData {
        // Return sequence data for GUI display
        ^(
            sequence: sequence,
            currentSequenceIndex: currentIndex,
            totalEvents: sequence.size
        );
    }

    // FACTORY METHODS
    
    *fromEvents { |events|
        ^this.new(events);
    }
    
    *fromPattern { |pattern, maxEvents = 100|
        var stream = pattern.asStream;
        var events = [];
        var event, count = 0;
        
        while { 
            event = stream.next;
            event.notNil and: { count < maxEvents }
        } {
            events = events.add(event);
            count = count + 1;
        };
        
        ^this.new(events);
    }

    // ENHANCED NAVIGATION DATA FOR GUI
    
    getNavigationData {
        var baseData = super.getNavigationData;
        
        // Add sequence-specific data
        baseData.put(\sequenceData, this.getSequenceData);
        ^baseData;
    }

    // CONVERSION METHODS
    
    asTimelinePlayer { |startTime = 0, defaultDelta = 1|
        // Convert sequence to timeline with generated timestamps
        var timeline = [];
        var currentTime = startTime;
        
        sequence.do { |event, i|
            var delta = event[\delta] ? event[\dur] ? defaultDelta;
            timeline = timeline.add((time: currentTime, event: event));
            currentTime = currentTime + delta;
        };
        
        ^PTimelinePlayer(timeline, templateEvent);
    }
}