/*
Event Extensions for Stream Player Integration
============================================

Extends Event with playPlusDelta method to capture both played event results
and timing information for stream player tracking systems.
*/

+ Event {
    playPlusDelta { | cleanup, mute |
        var playResult;
        if (mute) { this.put(\type, \rest) };
        cleanup.update(this);
        playResult = this.play;  // Capture the return value with node info
        ^[playResult, this.delta];  // Return [eventWithNodes, timing]
    }
    
    // NodeManager integration - safe wrapper that doesn't override core play method
    playWithTracking { |clock, protoEvent, quant|
        var playedEvent;

        if(NodeManager.ensureEnabled.not) {
            "Event.playWithTracking: NodeManager is disabled; playing untracked".warn;
            ^this.play(clock, protoEvent, quant);
        };
        
        // Call normal play method
        playedEvent = this.play(clock, protoEvent, quant);
        
        // Auto-register with NodeManager if this event creates nodes
        if(playedEvent.notNil and: { playedEvent[\id].notNil }) {
            var registrationType, metadata;
            
            // Check registration type based on event metadata
            case
            { playedEvent[\__preset].notNil } {
                // Register as preset instance
                registrationType = \preset;
                metadata = (
                    presetName: playedEvent[\__preset],
                    freq: playedEvent[\freq],
                    instrument: playedEvent[\instrument],
                    dur: playedEvent[\dur],
                    amp: playedEvent[\amp],
                    server: playedEvent[\server] ? Server.default,
                    nodeIDs: playedEvent[\id].asArray
                );
            }
            { playedEvent[\__toolSource].notNil } {
                // Register as tool-generated event
                registrationType = \toolEvent;
                metadata = (
                    toolSource: playedEvent[\__toolSource],
                    toolState: playedEvent[\__toolState],
                    toolInstance: playedEvent[\__toolInstance],
                    freq: playedEvent[\freq],
                    instrument: playedEvent[\instrument],
                    dur: playedEvent[\dur],
                    amp: playedEvent[\amp],
                    server: playedEvent[\server] ? Server.default,
                    nodeIDs: playedEvent[\id].asArray
                );
            }
            {
                // Register as manual event (including events with __preset that don't match other categories)
                registrationType = \event;
                metadata = (
                    presetName: playedEvent[\__preset],  // Include __preset if present
                    freq: playedEvent[\freq],
                    instrument: playedEvent[\instrument],
                    dur: playedEvent[\dur],
                    amp: playedEvent[\amp],
                    server: playedEvent[\server] ? Server.default,
                    nodeIDs: playedEvent[\id].asArray
                );
            };
            
            NodeManager.register(playedEvent, registrationType, metadata);
        };
        
        ^playedEvent;
    }
    
    // Alias for more intuitive naming
    playTracked { |clock, protoEvent, quant|
        ^this.playWithTracking(clock, protoEvent, quant);
    }
}

+ Function {
    // NodeManager integration for UGen functions
    playWithTracking { |target, outbus, fadeTime, addAction=\addToHead|
        var synth;

        if(NodeManager.ensureEnabled.not) {
            "Function.playWithTracking: NodeManager is disabled; playing untracked".warn;
            ^this.play(target, outbus, fadeTime, addAction);
        };
        
        // Call normal play method
        synth = this.play(target, outbus, fadeTime, addAction);
        
        // Auto-register with NodeManager if synth was created
        if(synth.notNil) {
            NodeManager.register(synth, \tempSynth, (
                server: synth.server,
                nodeID: synth.nodeID,
                defName: synth.defName,
                target: target,
                outbus: outbus,
                fadeTime: fadeTime,
                addAction: addAction,
                functionSource: this.asCompileString  // Capture function source
            ));
        };
        
        ^synth;
    }
    
    // Alias for more intuitive naming
    playTracked { |target, outbus, fadeTime, addAction=\addToHead|
        ^this.playWithTracking(target, outbus, fadeTime, addAction);
    }
}
