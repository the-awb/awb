/*
Preset Subclasses - Specialized preset types for different SuperCollider objects
===============================================================================

These classes provide type-specific behavior for different kinds of SuperCollider
objects while inheriting the universal interface from the base Preset class.

DESIGN PATTERN: Each subclass implements the abstract methods from Preset base class:
- play() - appropriate playback behavior for the object type
- stop() - appropriate stop behavior
- asCode() - code representation
- createDerivedObject() - derivation logic
- serializeObject() - storage format
*/

// =============================================================================
// SYNTHDEF PRESET - Source code library management
// =============================================================================

SynthDefPreset : Preset {
    var <synthDef;

    *new { |name, synthDef, address="uncategorized", tags=#[], notes=""|
        var instance = super.new(name, synthDef, address, tags, notes);
        if(instance.notNil) {
            instance.synthDef = synthDef;
        };
        ^instance;
    }

    play { |server|
        // SynthDefs don't "play" - they get added to the server
        synthDef.add(server ? Server.default);
        ("Added SynthDef to server: " ++ name).postln;
        ^synthDef;
    }

    stop {
        // SynthDefs can't be "stopped" once added, but we can remove instances
        "SynthDef % is now available on server (cannot be removed)".format(name).postln;
    }

    asCode {
        ^"Presets[\\%]; // SynthDef: %".format(name, synthDef.name);
    }

    createDerivedObject { |overrides|
        // Derivation for SynthDefs is complex - would need to modify source code
        "Derivation not yet supported for SynthDefPresets".warn;
        ^nil;
    }

    serializeObject {
        // Store SynthDef as dictionary with source code if available
        ^(
            name: synthDef.name,
            func: synthDef.func,
            rates: synthDef.rates,
            prependArgs: synthDef.prependArgs,
            variants: synthDef.variants,
            metadata: synthDef.metadata
        );
    }

    *fromDict { |dict|
        // Recreate SynthDefPreset from stored data
        var objectData = dict.objectData;
        var synthDef;

        // Try to recreate SynthDef from stored data
        if(objectData.notNil && objectData.func.notNil) {
            synthDef = SynthDef(objectData.name, objectData.func);
        } {
            "Warning: Could not recreate SynthDef from stored data".warn;
            ^nil;
        };

        ^this.new(dict.name, synthDef, dict.address, dict.tags, dict.notes);
    }

    // SynthDef-specific methods
    addToServer { |server|
        ^this.play(server);
    }
}

// =============================================================================
// PATTERN PRESET - Sequences and generative patterns
// =============================================================================

PatternPreset : Preset {
    var <pattern;
    var <player; // Current EventStreamPlayer if playing

    *new { |name, pattern, address="uncategorized", tags=#[], notes=""|
        var instance = super.new(name, pattern, address, tags, notes);
        if(instance.notNil) {
            instance.pattern = pattern;
            instance.player = nil;
        };
        ^instance;
    }

    play { |clock|
        // Patterns play as EventStreamPlayers
        if(player.notNil && player.isPlaying) {
            this.stop; // Stop existing player first
        };

        player = pattern.play(clock ? TempoClock.default);
        ("Playing pattern: " ++ name).postln;

        // Register with Playlist system using PStreamPlayer
        Playlist.add(player, name.asSymbol, \pattern);

        ^player;
    }

    stop {
        if(player.notNil) {
            player.stop;
            ("Stopped pattern: " ++ name).postln;
        };
        Playlist.stopPreset(name.asSymbol);
    }

    asCode {
        ^"Presets[\\%].play".format(name);
    }

    createDerivedObject { |overrides|
        // For patterns, overrides typically modify the source pattern
        // This is complex and pattern-specific
        "Derivation not yet fully implemented for PatternPresets".warn;
        ^pattern; // Return original for now
    }

    serializeObject {
        // Patterns are complex to serialize - store as much as possible
        ^(
            patternClass: pattern.class.name,
            patternData: pattern.asDict, // If pattern supports asDict
            warning: "Pattern serialization is limited"
        );
    }

    *fromDict { |dict|
        var objectData = dict.objectData;

        // Pattern reconstruction is complex - this is a basic implementation
        "Warning: Pattern reconstruction from storage is limited".warn;

        ^this.new(dict.name, Pseq([]), dict.address, dict.tags, dict.notes);
    }

    // Pattern-specific methods
    isPlaying {
        ^(player.notNil && player.isPlaying);
    }

    pause {
        if(player.notNil) {
            player.pause;
        };
    }

    resume {
        if(player.notNil) {
            player.resume;
        };
    }
}

// =============================================================================
// SYNTH PRESET - Running synth instances with infinite duration
// =============================================================================

SynthPreset : Preset {
    var <synth;
    var <>synthDef, <>params;

    *new { |name, synth, address="uncategorized", tags=#[], notes=""|

		var instance = super.new(name, synth, address, tags, notes);
        if(instance.notNil) {
			// instance.synth = synth;
            // Extract info from synth if it's a Synth object
			// WARNING - this does't have any view over mapped busses and their values, but shows only Control values
            if(synth.isKindOf(Synth)) {


				var params;
				var size;
				var synthDef = SynthDescLib.global[synth.defName].def;
				var controls = synthDef.controls;
				synth.getn(0,controls.size,action:{|v| params = controls.collect({|x, i| [x.name.asSymbol,v[i]].postln })});
				instance.params = params.flatten;
				instance.synthDef = synth.defName;

				// this could also be implmented with synthDef.variants
				// controls = SynthDescLib.global[synth.defName].def.variants = (test:params)
            };
        };
        ^instance;
    }

    play { |server|
        // If we have a SynthDef and params, create new synth
        if(synthDef.notNil) {
            synth = Synth(synthDef, params ? [], server ? Server.default);
            ("Playing synth: " ++ name).postln;

            // Register with Playlist
            Playlist.add(synth, name.asSymbol, \synth);

            ^synth;
        } {
            "Cannot play SynthPreset % - no SynthDef information".format(name).warn;
            ^nil;
        };
    }

    stop {
        if(synth.notNil) {
            synth.free;
            ("Stopped synth: " ++ name).postln;
        };
        Playlist.stopPreset(name.asSymbol);
    }

    asCode {
        if(synthDef.notNil) {
            ^"Synth(\\%, %)".format(synthDef, params ? []);
        } {
            ^"Presets[\\%].play".format(name);
        };
    }

    createDerivedObject { |overrides|
        // Create new parameter set with overrides
        var newParams = (params ? []).copy;

        if(overrides.notNil) {
            overrides.keysValuesDo({ |key, value|
                newParams[key] = value;
            });
        };

        // Return parameter array for new Synth
        ^newParams;
    }

    serializeObject {
        ^(
            synthDef: synthDef,
            params: params,
            nodeID: synth.notNil.if(synth.nodeID, nil)
        );
    }

    *fromDict { |dict|
        var objectData = dict.objectData;
        var preset = this.new(dict.name, nil, dict.address, dict.tags, dict.notes);

        if(preset.notNil && objectData.notNil) {
            preset.synthDef = objectData.synthDef;
            preset.params = objectData.params;
        };

        ^preset;
    }

    // Synth-specific methods
    set { |...args|
        if(synth.notNil) {
            synth.set(*args);
            // Update stored params
            if(params.isNil) { params = [] };
            args.pairsDo({ |key, value|
                params[key] = value;
            });
        };
    }

    get { |key, action|
        if(synth.notNil) {
            synth.get(key, action);
        };
    }

    isPlaying {
        ^(synth.notNil && synth.isPlaying);
    }
}

// =============================================================================
// FUNCTION PRESET - Function-based tools and generators
// =============================================================================

FunctionPreset : Preset {
    var <function;

    *new { |name, function, address="uncategorized", tags=#[], notes=""|
        var instance = super.new(name, function, address, tags, notes);
        if(instance.notNil) {
            instance.function = function;
        };
        ^instance;
    }

    play { |...args|
        // Functions get called/evaluated
        var result = function.value(*args);
        ("Evaluated function: " ++ name).postln;
        ^result;
    }

    stop {
        // Functions can't really be "stopped" once called
        ("Function % evaluation complete".format(name)).postln;
    }

    asCode {
        ^"Presets[\\%].play".format(name);
    }

    createDerivedObject { |overrides|
        // Functions are hard to derive - return original
        "Derivation not supported for FunctionPresets".warn;
        ^function;
    }

    serializeObject {
        ^(
            source: function.asString,
            warning: "Function serialization is limited"
        );
    }

    *fromDict { |dict|
        // Function reconstruction is very limited
        "Warning: Function reconstruction from storage is not supported".warn;
        ^this.new(dict.name, {}, dict.address, dict.tags, dict.notes);
    }

    // Function-specific methods
    value { |...args|
        ^this.play(*args);
    }
}

// =============================================================================
// TOOL PRESET - Custom tool configurations (generic container)
// =============================================================================

ToolPreset : Preset {
    var <toolID, <toolVersion, <configContract, <config, <selectedState;
    var <origin, <revision, <fingerprint;

    *new { |name, toolID, toolVersion, configContract, config, selectedState,
        address="uncategorized", tags=#[], notes="", origin, revision=1|
        var instance;

        instance = super.new(name, config, address, tags, notes);
        if(instance.notNil) {
            instance.initToolPreset(
                toolID, toolVersion, configContract, config, selectedState,
                origin, revision
            );
        };
        ^instance;
    }

    initToolPreset { |anID, aVersion, aContract, aConfig, aSelection,
        anOrigin, aRevision|
        toolID = anID.asSymbol;
        toolVersion = aVersion.asString;
        configContract = aContract.asSymbol;
        config = aConfig.deepCopy;
        selectedState = if(aSelection.notNil) { aSelection.deepCopy } { nil };
        origin = if(anOrigin.notNil) { anOrigin.deepCopy } { nil };
        revision = aRevision.asInteger.max(1);
        this.validate;
        fingerprint = this.class.fingerprintFor(
            toolID, toolVersion, configContract, config, selectedState
        );
        ^this;
    }

    *fingerprintFor { |toolID, toolVersion, configContract, config, selectedState|
        ^[
            toolID.asSymbol,
            toolVersion.asString,
            configContract.asSymbol,
            config,
            selectedState
        ].asCompileString.hash.asString;
    }

    domain {
        ^\tool;
    }

    codec {
        ^switch(configContract,
            \scaleBeatSelectionV1, { \scaleBeatToolPresetV1 },
            \toneDiamondSelectionV1, { \toneDiamondToolPresetV1 },
            \beatHarmonySelectionV1, { \beatHarmonyToolPresetV1 },
            \gongConfigV1, { \gongToolPresetV1 },
            { configContract }
        );
    }

    qualifiedRef {
        ^(
            domain: \tool,
            key: name.asSymbol,
            revision: revision,
            fingerprint: fingerprint
        );
    }

    validate {
        if(name.isNil) { Error("ToolPreset requires a name").throw };
        if(toolID.isNil) { Error("ToolPreset requires a tool ID").throw };
        if(configContract.isNil) {
            Error("ToolPreset requires a configuration contract").throw;
        };
        if(config.isKindOf(Event).not and: { config.isKindOf(Dictionary).not }) {
            Error("ToolPreset configuration must be dictionary-like").throw;
        };
        ^true;
    }

    open { |options|
        var launchOptions;

        if(ToolRegistry.at(toolID).isNil) {
            Error("ToolPreset cannot open unregistered tool %".format(toolID)).throw;
        };
        launchOptions = (options ? ()).copy;
        if(ToolRegistry.requiresExactVersion(toolID)) {
            if(ToolRegistry.at(toolID, toolVersion).isNil) {
                Error("ToolPreset: install % version % to open this preset"
                    .format(toolID, toolVersion)).throw;
            };
            launchOptions[\toolVersion] = toolVersion;
        };
        launchOptions[\sourcePresetRef] = this.qualifiedRef;
        launchOptions[\sourcePresetFingerprint] = fingerprint;
        ^ToolLauncher.open(toolID, config.deepCopy, launchOptions);
    }

    compatibilityErrorFor { |instance|
        var expectedContract;

        if(instance.isKindOf(ToolInstance).not) {
            ^"Target must be a ToolInstance";
        };
        if(instance.status != \active) {
            ^"Target ToolInstance is not active";
        };
        if(instance.definition.id != toolID) {
            ^"ToolPreset % targets %, not %"
                .format(name, toolID, instance.definition.id);
        };
        if(ToolRegistry.requiresExactVersion(toolID) and: {
            instance.definition.version.asString != toolVersion
        }) {
            ^"Preset needs % version %; target is %. Open as a new instance."
                .format(toolID, toolVersion, instance.definition.version);
        };
        expectedContract = instance.definition.dependencies[\promotionContract];
        if(expectedContract.notNil and: { expectedContract != configContract }) {
            ^"ToolPreset contract % is incompatible with %"
                .format(configContract, expectedContract);
        };
        if(instance.tool.isNil
            or: { instance.tool.respondsTo(\applyPresetConfig).not }) {
            ^"Tool % does not implement preset application".format(toolID);
        };
        ^nil;
    }

    isCompatibleWith { |instance|
        ^this.compatibilityErrorFor(instance).isNil;
    }

    applyTo { |instance|
        var issue;

        issue = this.compatibilityErrorFor(instance);
        if(issue.notNil) { Error(issue).throw };
        ^instance.applyPreset(this);
    }

    play { |...args|
        ^this.open(args.at(0));
    }

    stop {
        // A durable ToolPreset owns no running ToolInstance.
        ^this;
    }

    asCode {
        ^"ToolPresets[\\%].open".format(name);
    }

    createDerivedObject { |overrides|
        var derived;
        derived = config.deepCopy;
        derived.putAll(overrides ? ());
        ^derived;
    }

    derive { |newName, overrides, newAddress, newTags, newNotes|
        ^this.copyWith(newName, overrides, newAddress, newTags, newNotes);
    }

    copyWith { |newName, overrides, newAddress, newTags, newNotes|
        var derived;
        derived = this.createDerivedObject(overrides);
        ^this.class.new(
            newName,
            toolID,
            toolVersion,
            configContract,
            derived,
            selectedState,
            newAddress ? address,
            newTags ? tags,
            newNotes ? notes,
            (kind: \derivedToolPreset, parent: this.qualifiedRef),
            1
        );
    }

    serializeObject {
        ^(
            toolID: toolID,
            toolVersion: toolVersion,
            configContract: configContract,
            config: config.deepCopy,
            selectedState: if(selectedState.notNil) { selectedState.deepCopy } { nil },
            origin: if(origin.notNil) { origin.deepCopy } { nil },
            revision: revision,
            fingerprint: fingerprint
        );
    }

    asDict {
        ^(
            schema: \awbPresetV1,
            domain: \tool,
            key: name.asSymbol,
            revision: revision,
            metadata: (
                address: address,
                tags: tags,
                notes: notes,
                timestamp: timestamp
            ),
            codec: this.codec,
            payload: (
                toolID: toolID,
                toolVersion: toolVersion,
                configContract: configContract,
                config: config.deepCopy,
                selectedState: if(selectedState.notNil) {
                    selectedState.deepCopy
                } { nil }
            ),
            origin: if(origin.notNil) { origin.deepCopy } { nil },
            fingerprint: fingerprint
        );
    }

    *fromDict { |dict|
        var data, metadata, storedOrigin, storedRevision, storedFingerprint, preset;

        if(dict[\schema] == \awbPresetV1) {
            if(dict[\domain] != \tool) {
                Error("ToolPreset record has the wrong domain").throw;
            };
            if([
                \scaleBeatToolPresetV1,
                \toneDiamondToolPresetV1,
                \beatHarmonyToolPresetV1,
                \gongToolPresetV1
            ].includes(dict[\codec]).not) {
                Error("Unsupported ToolPreset codec: %".format(dict[\codec])).throw;
            };
            data = dict[\payload];
            if(dict[\codec] == \gongToolPresetV1) {
                if(data[\toolID] != \gong or: { data[\configContract] != \gongConfigV1 }) {
                    Error("Gong preset codec/identity mismatch").throw;
                };
                GongConfig.normalize(data[\toolVersion].asString, data[\config]);
            };
            metadata = dict[\metadata] ? ();
            storedOrigin = dict[\origin];
            storedRevision = dict[\revision] ? 1;
            storedFingerprint = dict[\fingerprint];
        } {
            // Transitional reader for the first WIP archive shape.
            data = dict[\objectData] ? dict[\payload];
            metadata = dict;
            storedOrigin = data[\origin];
            storedRevision = data[\revision] ? 1;
            storedFingerprint = data[\fingerprint];
        };
        if(data.isNil) { Error("ToolPreset record has no object data").throw };
        preset = this.new(
            dict[\name] ? dict[\key],
            data[\toolID],
            data[\toolVersion],
            data[\configContract],
            data[\config],
            data[\selectedState],
            metadata[\address] ? "uncategorized",
            metadata[\tags] ? #[],
            metadata[\notes] ? "",
            storedOrigin,
            storedRevision
        );
        if(metadata[\timestamp].notNil) {
            preset.timestamp_(metadata[\timestamp]);
        };
        if(storedFingerprint.notNil
            and: { storedFingerprint != preset.fingerprint }) {
            Error("ToolPreset fingerprint does not match its stored recipe").throw;
        };
        ^preset;
    }
}

// =============================================================================
// OBJECT PRESET - Generic fallback for any other object type
// =============================================================================

ObjectPreset : Preset {
    var <object;

    *new { |name, object, address="uncategorized", tags=#[], notes=""|
        var instance = super.new(name, object, address, tags, notes);
        if(instance.notNil) {
            instance.object = object;
        };
        ^instance;
    }

    play { |...args|
        // Try common play methods
        if(object.respondsTo(\play)) {
            ^object.play(*args);
        } {
            ("Object % accessed".format(name)).postln;
            ^object;
        };
    }

    stop {
        if(object.respondsTo(\stop)) {
            object.stop;
        } {
            if(object.respondsTo(\free)) {
                object.free;
            } {
                ("Object % interaction complete".format(name)).postln;
            };
        };
    }

    asCode {
        ^"Presets[\\%] // % object".format(name, object.class.name);
    }

    createDerivedObject { |overrides|
        // Generic object derivation
        var newObject = object.copy;

        if(overrides.notNil && newObject.respondsTo(\putAll)) {
            newObject.putAll(overrides);
        };

        ^newObject;
    }

    serializeObject {
        ^(
            objectClass: object.class.name,
            objectString: object.asString
        );
    }

    *fromDict { |dict|
        "Warning: Generic object reconstruction from storage is very limited".warn;
        ^this.new(dict.name, (), dict.address, dict.tags, dict.notes);
    }
}

/*
IMPLEMENTATION NOTES:

1. SPECIALIZED BEHAVIOR: Each preset type implements appropriate play/stop behavior
2. COMMON INTERFACE: All inherit universal methods from base Preset class
3. SERIALIZATION: Storage/reconstruction varies by object type complexity
4. DERIVATION: Parameter override logic adapted to each object type
5. INTEGRATION: All work with Playlist, PNodePlayer, universal registry

LIMITATIONS & FUTURE WORK:

1. Pattern/Function serialization is limited due to SuperCollider constraints
2. SynthDef derivation needs source code manipulation (complex)
3. Tool integration depends on tool-specific APIs
4. Some object types may need custom subclasses for optimal behavior

This provides the foundation for the multi-type preset ecosystem while
maintaining clean separation of concerns between different object types.
*/
