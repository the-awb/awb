/*
PTimelinePlayer - Timeline Navigation with Stream Regeneration
=============================================================

Timeline scrubbing with sophisticated stream regeneration for random access navigation.
Implements the Stop → Rebuild → Restart pattern for true timeline navigation.

Core Innovation:
- Timeline math: converts absolute timestamps to relative deltas
- Rest event injection for precise timing gaps
- Stream regeneration from any timeline position  
- Professional timestamp parsing (HH:MM:SS.mmm, MM:SS.mmm, seconds)

Usage:
~timeline = [
    (time: 0.0, event: (freq: 440, dur: 2)),
    (time: 2.0, event: (freq: 880, dur: 1)),
    (time: 3.0, event: (freq: 660, dur: 0.5))
];
~player = PTimelinePlayer(~timeline);
~player.play;
~player.jumpToTime(1.5);  // Jump to 1.5 seconds
~player.stepForward;      // Next event
*/

PTimelinePlayer : PSequencePlayer {
    // Timeline-specific data
    var <timeline, <totalDuration;
    var <currentTime;

    *new { |timeline, templateEvent|
        ^super.new(timeline, templateEvent);
    }

    // IMPLEMENT ABSTRACT INTERFACE
    
    initializeData { |timelineArray|
        timeline = this.parseTimeline(timelineArray ? []);
        totalDuration = if(timeline.notEmpty) {
            timeline.last.time + (timeline.last.event[\dur] ? 1)
        } { 0 };
        currentTime = 0;
    }
    
    createStreamFrom { |targetIndex|
        var targetTime, startIndex, events, callback;
        
        if(timeline.isEmpty) { ^nil };
        if(targetIndex < 0 or: { targetIndex >= timeline.size }) { ^nil };
        
        // Get target time for this index
        targetTime = timeline[targetIndex].time;
        startIndex = targetIndex;
        
        events = [];
        
        // Handle timing offset with invisible rest if needed
        if(startIndex < timeline.size) {
            var firstEventTime = timeline[startIndex].time;
            var timeOffset = firstEventTime - targetTime;
            
            if(timeOffset > 0) {
                // Add invisible rest event to handle timing gap
                var restEvent = (type: \rest, delta: timeOffset);
                events = events.add(restEvent);
            };
        };
        
        // Convert timeline from startIndex onwards to relative deltas
        timeline[startIndex..].do { |item, i|
            var delta, currentIndex;
            currentIndex = startIndex + i;
            
            // Calculate delta to next event
            if(currentIndex < (timeline.size - 1)) {
                delta = timeline[currentIndex + 1].time - item.time;
            } {
                // Last event: use event's own duration
                delta = item.event[\dur] ? 1;
            };
            
            events = events.add(item.event.copy.put(\delta, delta));
        };
        
        // Create callback to capture events to performance history
        callback = { |event, streamIndex|
            // Map stream index back to timeline index
            var timelineIndex = startIndex + streamIndex;
            if(events[streamIndex][\type] != \rest) {
                this.addToHistory(event, timelineIndex);
            };
        };
        
        ^PIndexedStream(events, callback);
    }
    
    eventAtIndex { |index|
        if(index < 0 or: { index >= timeline.size }) { ^nil };
        ^timeline[index].event.copy;
    }
    
    hasHorizon { ^true }
    
    size { ^timeline.size }

    // TIMELINE-SPECIFIC NAVIGATION
    
    jumpToTime { |targetTime|
        var wasPlaying, targetIndex;
        
        targetTime = this.parseTimeStamp(targetTime);
        
        if(targetTime < 0 or: { targetTime > totalDuration }) {
            "PTimelinePlayer: jumpToTime out of range (0 to %)".format(totalDuration).warn;
            ^this;
        };
        
        wasPlaying = isPlaying;
        
        // Stop current player and kill active nodes immediately
        if(currentPlayer.notNil) {
            currentPlayer.stopAll;
        };
        
        // Update positions
        currentTime = targetTime;
        currentIndex = this.findIndexForTime(targetTime);
        
        // Create and start new stream from this position if was playing
        if(wasPlaying) {
            this.createAndStartPlayer;
            if(currentPlayer.notNil) {
                currentPlayer.play;
                isPlaying = true;
            };
        } {
            currentPlayer = nil;
            isPlaying = false;
        };
        
        ^this;
    }
    
    jumpToEvent { |eventIndex|
        if(eventIndex < 0 or: { eventIndex >= timeline.size }) {
            "PTimelinePlayer: jumpToEvent out of range (0 to %)".format(timeline.size - 1).warn;
            ^this;
        };
        
        this.jumpToTime(timeline[eventIndex].time);
    }
    
    createStreamFromTime { |targetTime|
        // Create stream starting from specific time (for PTimelineSequencer)
        var targetIndex = this.findIndexForTime(targetTime);
        ^this.createStreamFrom(targetIndex);
    }

    // TIMELINE PARSING AND UTILITIES
    
    parseTimeline { |timelineArray|
        ^timelineArray.collect { |item|
            var parsedTime = this.parseTimeStamp(item.time);
            (time: parsedTime, event: item.event);
        };
    }
    
    parseTimeStamp { |timeStamp|
        // Parse various timestamp formats into seconds (float)
        case 
        { timeStamp.isKindOf(String) } {
            ^this.parseTimeString(timeStamp);
        }
        { timeStamp.isKindOf(Event) } {
            // Structured: (minutes: 2, seconds: 30)
            var minutes = timeStamp[\minutes] ? 0;
            var seconds = timeStamp[\seconds] ? 0;
            var hours = timeStamp[\hours] ? 0;
            ^(hours * 3600) + (minutes * 60) + seconds;
        }
        { timeStamp.respondsTo(\asFloat) } {
            ^timeStamp.asFloat;
        }
        {
            "Invalid timestamp format: %".format(timeStamp).warn;
            ^timeStamp.asFloat;
        };
    }
    
    parseTimeString { |timeString|
        var parts, hours, minutes, seconds;
        
        // Handle different string formats
        if(timeString.find(":").notNil) {
            parts = timeString.split($:);
            case 
            { parts.size == 3 } {
                // HH:MM:SS.mmm format
                hours = parts[0].asFloat;
                minutes = parts[1].asFloat;
                seconds = parts[2].asFloat;
                ^(hours * 3600) + (minutes * 60) + seconds;
            }
            { parts.size == 2 } {
                // MM:SS.mmm format
                minutes = parts[0].asFloat;
                seconds = parts[1].asFloat;
                ^(minutes * 60) + seconds;
            }
            {
                "Invalid time string format: %".format(timeString).warn;
                ^timeString.asFloat;
            };
        } {
            // Just seconds as string
            ^timeString.asFloat;
        };
    }
    
    findIndexForTime { |targetTime|
        // Find the event at or after target time
        ^timeline.detectIndex({ |item| item.time >= targetTime }) ? (timeline.size - 1);
    }

    // TIMELINE-SPECIFIC INSPECTION
    
    getTimelineData {
        // Return timeline data for GUI display
        ^(
            timeline: timeline,
            currentTime: currentTime,
            totalDuration: totalDuration,
            currentTimelineIndex: currentIndex
        );
    }

    // FACTORY METHODS
    
    *fromEvents { |events, startTime = 0, defaultDur = 1|
        var timeline = [];
        var currentTime = startTime;
        
        events.do { |event, i|
            var dur = event[\dur] ? defaultDur;
            timeline = timeline.add((time: currentTime, event: event));
            currentTime = currentTime + dur;
        };
        
        ^this.new(timeline);
    }
    
    *fromPattern { |pattern, maxEvents = 100|
        var stream = pattern.asStream;
        var events = [];
        var event, count = 0;
        
        while { 
            event = stream.next;
            event.notNil and: { count < maxEvents }
        } {
            events = events.add(event);
            count = count + 1;
        };
        
        ^this.fromEvents(events);
    }

    // ENHANCED NAVIGATION DATA FOR GUI
    
    getNavigationData {
        var baseData = super.getNavigationData;
        
        // Add timeline-specific data
        baseData.put(\timelineData, this.getTimelineData);
        ^baseData;
    }

    // CONVERSION METHODS
    
    asSequencePlayer {
        // Convert timeline to sequence (loses timestamp information)
        var events = timeline.collect(_.event);
        ^PSequencePlayer(events, templateEvent);
    }
}