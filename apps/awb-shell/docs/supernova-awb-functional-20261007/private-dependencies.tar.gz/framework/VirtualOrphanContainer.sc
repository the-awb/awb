VirtualOrphanContainer {
	var <orphanType, <displayName, <children;
	
	*new { |orphanType, displayName|
		^super.newCopyArgs(orphanType, displayName, IdentitySet.new);
	}
	
	add { |object|
		children = children.add(object);
	}
	
	remove { |object|
		children.remove(object);
	}
	
	releaseAll { |releaseTime|
		var targets, released;

		targets = children.copy;
		released = targets.select { |child|
			NodeManager.releaseObject(child, releaseTime)
		}.size;
		^(requested: targets.size, released: released,
			skipped: targets.size - released);
	}
	
	stopAll {
		var targets, stopped;

		targets = children.copy;
		stopped = targets.select { |child|
			NodeManager.stopAndRemoveObject(child);
		}.size;
		^(requested: targets.size, stopped: stopped,
			skipped: targets.size - stopped);
	}

	freeAll {
		var targets, freed;

		targets = children.copy;
		freed = targets.select { |child|
			NodeManager.freeObject(child)
		}.size;
		^(requested: targets.size, freed: freed,
			skipped: targets.size - freed);
	}
	
	size {
		^children.size;
	}
	
	isEmpty {
		^children.isEmpty;
	}
	
	// Standard name method for NodeManager display
	name {
		^displayName;
	}
	
	// Standard class name for type identification
	asString {
		^("VirtualOrphanContainer(" ++ orphanType ++ ", " ++ displayName ++ ")");
	}
}
