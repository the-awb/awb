/*
Preset - Universal Base Class for All Preset Types
=================================================

Base class providing common interface for EventPresets, SynthPresets, 
PatternPresets, and any other preset types. Enables universal preset
creation via Object extensions.

Universal API:
- Any object can call .asPreset() to create appropriate preset type
- All presets share common methods: play(), derive(), addTag(), etc.
- Unified registry: Presets[key] works regardless of underlying type
- Type-specific behavior through subclass implementations

DESIGN PRINCIPLE: Universal interface, specialized behavior.
*/

Preset {
    var <name, <address, <tags, <notes, <timestamp, <originalObject, <isFavorite;
    
    *new { |name, originalObject, address="uncategorized", tags=#[], notes=""|
        var instance = super.newCopyArgs(
            name, 
            address ? "uncategorized", 
            tags ? #[], 
            notes ? "",
            Date.getDate,
            originalObject,
            false
        );
        
        // Validate required parameters
        if(name.isNil) {
            "Error: Cannot create Preset with nil name".error;
            ^nil;
        };
        
        if(originalObject.isNil) {
            "Warning: Creating Preset with nil originalObject".warn;
        };
        
        ^instance;
    }
    
    // =================================================================
    // FACTORY METHOD - Automatic type detection and preset creation
    // =================================================================
    
    *wrapObject { |object, name, address="uncategorized", tags=#[], notes=""|
        // Dispatch to appropriate preset type based on object class
        
        case 
        { object.isKindOf(Event) } {
            ^EventPreset.fromEvent(object, name, address, tags, notes);
        }
        { object.isKindOf(SynthDef) } {
            ^SynthDefPreset.new(name, object, address, tags, notes);
        }
        { object.isKindOf(Pattern) } {
            ^PatternPreset.new(name, object, address, tags, notes);
        }
        { object.isKindOf(Synth) } {
            ^SynthPreset.new(name, object, address, tags, notes);
        }
        { object.isKindOf(Function) } {
            ^FunctionPreset.new(name, object, address, tags, notes);
        }
        { object.class.name.asString.contains("BeatHarmoniser") } {
            // A live legacy tool is not a durable ToolPreset recipe. Keep the
            // object wrapper behavior until that tool has an explicit adapter.
            ^ObjectPreset.new(name, object, address, tags, notes);
        }
        { 
            // Generic fallback for any other object type
            ^ObjectPreset.new(name, object, address, tags, notes);
        };
    }
    
    // =================================================================
    // UNIVERSAL PRESET INTERFACE - Subclasses must implement
    // =================================================================
    
    play { |server|
        // Subclasses must implement appropriate play behavior
        this.subclassResponsibility;
    }
    
    stop {
        // Subclasses implement appropriate stop behavior
        this.subclassResponsibility;
    }
    
    asCode {
        // Return SuperCollider code representation
        this.subclassResponsibility;
    }
    
    // =================================================================
    // COMMON PRESET FUNCTIONALITY - Works for all types
    // =================================================================

    timestamp_ { |aTimestamp|
        timestamp = aTimestamp;
        ^this;
    }
    
    derive { |newName, overrides, newAddress, newTags, newNotes|
        // Create variation of this preset with parameter overrides
        var derivedObject, newPreset;
        
        // Default new metadata to parent values if not specified
        newAddress = newAddress ? address;
        newTags = newTags ? tags;
        newNotes = newNotes ? (notes ++ " (derived from " ++ name ++ ")");
        
        // Create derived object with overrides (subclass-specific)
        derivedObject = this.createDerivedObject(overrides);
        
        if(derivedObject.isNil) {
            "Error: Could not create derived object from %".format(this).error;
            ^nil;
        };
        
        // Create new preset from derived object
        newPreset = Preset.wrapObject(derivedObject, newName, newAddress, newTags, newNotes);
        
        // Track derivation relationship
        newPreset.setDerivationParent(this);
        
        ^newPreset;
    }
    
    createDerivedObject { |overrides|
        // Subclasses implement object-specific derivation logic
        this.subclassResponsibility;
    }
    
    addTag { |tag|
        if(tag.notNil) {
            tags = tags.add(tag).asSet.asArray.sort;
        };
    }
    
    removeTag { |tag|
        tags = tags.reject(_ == tag);
    }
    
    star {
        isFavorite = true;
    }
    
    unstar {
        isFavorite = false;
    }
    
    // =================================================================
    // METADATA AND ORGANIZATION
    // =================================================================
    
    info {
        ^(
            name: name,
            type: this.class.name,
            address: address,
            tags: tags,
            notes: notes,
            timestamp: timestamp,
            isFavorite: isFavorite,
            hasOriginalObject: originalObject.notNil
        );
    }
    
    setDerivationParent { |parent|
        // Track preset lineage for derivation chains
        this.originalObject = this.originalObject ? ();
        this.originalObject[\derivationParent] = parent.name;
    }
    
    hasPresetMetadata {
        // Check if this object has preset metadata attached
        ^(name.notNil && address.notNil);
    }
    
    // =================================================================
    // PRESET REGISTRY INTEGRATION
    // =================================================================
    
    register {
        // Add this preset to the global registry
        Presets.add(this);
    }
    
    unregister {
        // Remove this preset from global registry
        Presets.remove(name);
    }
    
    // =================================================================
    // SERIALIZATION
    // =================================================================
    
    asDict {
        // Convert to dictionary for file storage
        ^(
            name: name,
            type: this.class.name,
            address: address,
            tags: tags,
            notes: notes,
            timestamp: timestamp,
            isFavorite: isFavorite,
            objectData: this.serializeObject
        );
    }
    
    serializeObject {
        // Subclasses implement object-specific serialization
        this.subclassResponsibility;
    }
    
    *fromDict { |dict|
        // Recreate preset from stored dictionary
        var presetClass, preset;
        
        presetClass = dict[\type].asString.asClass;
        if(presetClass.isNil) {
            "Error: Unknown preset type: %".format(dict[\type]).error;
            ^nil;
        };
        
        preset = presetClass.fromDict(dict);
        ^preset;
    }
    
    // =================================================================
    // UTILITY METHODS
    // =================================================================
    
    == { |other|
        ^(other.isKindOf(Preset) && (other.name == name));
    }
    
    hash {
        ^name.hash;
    }
    
    printOn { |stream|
        stream << this.class.name << "(" << name << ")";
    }
    
    asString {
        ^"%(%)".format(this.class.name, name);
    }
}

/*
TODO: Implement preset subclasses:
- EventPreset (refactor existing to inherit from Preset)
- SynthDefPreset (for source code library)
- SynthPreset (for infinite-duration synths)
- PatternPreset (for sequences and generative patterns)
- ToolPreset (for custom tool configurations)
- ObjectPreset (generic fallback)
*/
