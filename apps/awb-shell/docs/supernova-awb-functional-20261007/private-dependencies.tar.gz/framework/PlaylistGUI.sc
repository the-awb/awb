// Simple GUI for monitoring and controlling the FIFO Playlist system

PlaylistGUI {
    var playlist, window, <itemList, maxItemsSlider, statusText, maxItemsText;
    var stopAllButton, stopEventButton, stopSeqButton, refreshButton;
    var updateTask, <updateInterval;
    
    *new { |playlist|
        ^super.newCopyArgs(playlist ? Playlist.global).init;
    }
    
    init {
        updateInterval = 0.5; // Update every 500ms
        this.createWindow;
        this.startUpdateTask;
        
        // Register as observer for playlist changes
        playlist.addObserver(this);
    }
    
    createWindow {
        window = Window("Playlist Monitor", Rect(100, 100, 400, 350))
            .onClose_({ this.cleanup });
        
        // Header with max items control
        StaticText(window, Rect(10, 10, 80, 20)).string_("Max Items:");
        
        maxItemsSlider = Slider(window, Rect(95, 10, 100, 20))
            .value_(playlist.maxItems / 16.0) // Assume max range 0-16
            .action_({ |slider|
                var newMax = (slider.value * 16).round.asInteger.max(1);
                playlist.setMaxItems(newMax);
                this.updateStatus;
            });
        
        maxItemsText = StaticText(window, Rect(200, 10, 40, 20))
            .string_(playlist.maxItems.asString)
            .background_(Color.gray(0.9));
        
        // Status display
        statusText = StaticText(window, Rect(10, 35, 380, 20))
            .font_(Font.monospace(10))
            .background_(Color.gray(0.95));
        
        // Item list
        StaticText(window, Rect(10, 65, 100, 20)).string_("Playing Items:");
        
        itemList = ListView(window, Rect(10, 90, 380, 180))
            .font_(Font.monospace(9))
            .selectionMode_(\extended);
        
        // Control buttons
        stopAllButton = Button(window, Rect(10, 280, 80, 30))
            .states_([["Stop All", Color.black, Color.red(0.7)]])
            .action_({ playlist.stopAll });
        
        stopEventButton = Button(window, Rect(100, 280, 80, 30))
            .states_([["Stop Events", Color.black, Color.new(1.0, 0.5, 0.0, 0.7)]])
            .action_({ playlist.stopType(\event) });
        
        stopSeqButton = Button(window, Rect(190, 280, 80, 30))
            .states_([["Stop Sequences", Color.black, Color.yellow(0.7)]])
            .action_({ playlist.stopType(\sequence) });
        
        refreshButton = Button(window, Rect(280, 280, 50, 30))
            .states_([["Refresh", Color.black, Color.green(0.7)]])
            .action_({ this.updateDisplay });
        
        // Stop selected button
        Button(window, Rect(340, 280, 50, 30))
            .states_([["Stop Sel", Color.black, Color.gray(0.7)]])
            .action_({ this.stopSelected });
        
        // Instructions
        StaticText(window, Rect(10, 320, 380, 20))
            .string_("• Live updates every 500ms • Select items and click 'Stop Sel' to stop specific items")
            .font_(Font.default.size_(9))
            .stringColor_(Color.gray(0.6));
        
        window.front;
        this.updateDisplay;
    }
    
    updateDisplay {
        this.updateStatus;
        this.updateItemList;
        this.updateMaxItemsDisplay;
    }
    
    updateStatus {
        var playing = playlist.playing.size;
        var total = playlist.items.size;
        var statusString = "Playing: " ++ playing ++ " | Total: " ++ total ++ " | Max: " ++ playlist.maxItems;
        
        if(total >= playlist.maxItems) {
            statusText.stringColor_(Color.red);
            statusString = statusString ++ " (AT LIMIT)";
        } {
            if(total > (playlist.maxItems * 0.8)) {
                statusText.stringColor_(Color.new(1.0, 0.5, 0.0));
                statusString = statusString ++ " (near limit)";
            } {
                statusText.stringColor_(Color.black);
            };
        };
        
        statusText.string_(statusString);
    }
    
    updateItemList {
        var items = playlist.items;
        var displayItems = [];
        
        items.do({ |item, i|
            var age = Date.getDate.rawSeconds - item.startTime.rawSeconds;
            var status = item.isPlaying.if("♪", "◦");
            var typeIcon = switch(item.presetType,
                \event, "🎵",
                \sequence, "🎼", 
                \pattern, "🔄",
                "●"
            );
            var displayString = status ++ " " ++ typeIcon ++ " " ++ item.presetKey ++ " (" ++ age.round(0.1) ++ "s)";
            displayItems = displayItems.add(displayString);
        });
        
        itemList.items_(displayItems);
    }
    
    updateMaxItemsDisplay {
        // Update the text display next to slider
        if(maxItemsText.notNil) {
            maxItemsText.string_(playlist.maxItems.asString);
        };
    }
    
    stopSelected {
        var selectedIndices = itemList.selection;
        var itemsToStop = selectedIndices.collect({ |i| playlist.items[i] });
        
        if(itemsToStop.size > 0) {
            itemsToStop.do({ |item| playlist.stopAndRemove(item) });
            ("Stopped " ++ itemsToStop.size ++ " selected items").postln;
        } {
            "No items selected".warn;
        };
    }
    
    startUpdateTask {
        updateTask = Task({
            loop {
                updateInterval.wait;
                if(window.isClosed.not) {
                    { this.updateDisplay }.defer;
                } {
                    updateTask.stop;
                };
            };
        });
        updateTask.start;
    }
    
    // Observer method for playlist changes
    playlistChanged { |action, data|
        // Update display when playlist changes
        { this.updateDisplay }.defer;
    }
    
    cleanup {
        if(updateTask.notNil) {
            updateTask.stop;
            updateTask = nil;
        };
        playlist.removeObserver(this);
    }
    
    // Static method to open GUI for global playlist
    *open {
        ^PlaylistGUI(Playlist.global);
    }
}

// Add GUI method to Playlist class
+ Playlist {
    gui {
        ^PlaylistGUI(this);
    }
}