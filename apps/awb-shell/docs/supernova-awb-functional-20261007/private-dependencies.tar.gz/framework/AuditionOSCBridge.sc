/*
AuditionOSCBridge
=================

Disposable, requester-scoped SynthDef voices for AWB tools. This is deliberately
separate from score transport. One Play request owns one realization, which may
contain several Synth nodes after SuperCollider-style array expansion in the
requesting editor.
*/
AuditionOSCBridge {
    classvar <default;
    var <clients, <realizations, <nodeIndex, <responders, <requestCache, <requestOrder;
    var <isRunning, <maxCachedRequests;

    *new { |maxCachedRequests = 512|
        ^super.new.init(maxCachedRequests);
    }

    *start { |maxCachedRequests = 512|
        if(default.isNil) { default = this.new(maxCachedRequests) };
        default.start;
        ^default;
    }

    *stop {
        if(default.notNil) { default.stop; default = nil };
    }

    init { |cacheLimit|
        clients = Dictionary.new;
        realizations = Dictionary.new;
        nodeIndex = Dictionary.new;
        responders = List.new;
        requestCache = Dictionary.new;
        requestOrder = List.new;
        maxCachedRequests = cacheLimit.asInteger.max(16);
        isRunning = false;
        ^this;
    }

    start {
        if(isRunning) { ^this };
        SynthDefAuditionTool.register;
        responders.add(OSCFunc({ |msg, time, addr| this.handleHello(msg, addr) },
            '/awb/audition/hello'));
        responders.add(OSCFunc({ |msg, time, addr| this.handlePlay(msg, addr) },
            '/awb/audition/play'));
        responders.add(OSCFunc({ |msg, time, addr| this.handleEvent(msg, addr) },
            '/awb/audition/event'));
        responders.add(OSCFunc({ |msg, time, addr| this.handleCommand(msg, addr) },
            '/awb/audition/command'));
        responders.add(OSCFunc({ |msg, time, addr| this.handleSet(msg, addr) },
            '/awb/audition/set'));
        responders.add(OSCFunc({ |msg, time, addr| this.handleDisconnect(msg, addr) },
            '/awb/audition/disconnect'));
        responders.add(OSCFunc({ |msg| this.nodeStarted(msg[1].asInteger) }, '/n_go'));
        responders.add(OSCFunc({ |msg| this.nodeEnded(msg[1].asInteger) }, '/n_end'));
        isRunning = true;
        ^this;
    }

    stop {
        if(isRunning.not) { ^this };
        responders.do(_.free);
        responders.clear;
        clients.values.copy.do { |client| this.forgetClient(client) };
        clients.clear;
        realizations.clear;
        nodeIndex.clear;
        requestCache.clear;
        requestOrder.clear;
        isRunning = false;
        ^this;
    }

    isAllowedAddress { |addr|
        var ip;
        ip = addr.ip.asString;
        ^ip.beginsWith("127.")
            or: { ip.beginsWith("::1") }
            or: { ip.beginsWith("::ffff:127.") };
    }

    keyFor { |clientID, realizationID|
        ^clientID.asString ++ ":" ++ realizationID.asString;
    }

    cacheKey { |client, requestID|
        ^client.clientID ++ ":" ++ requestID.asString;
    }

    cacheReply { |client, requestID, message|
        var key;
        key = this.cacheKey(client, requestID);
        requestCache[key] = message;
        requestOrder.add(key);
        while { requestOrder.size > maxCachedRequests } {
            requestCache.removeAt(requestOrder.removeAt(0));
        };
    }

    resendCached { |client, requestID|
        var message;
        message = requestCache[this.cacheKey(client, requestID)];
        if(message.isNil) { ^false };
        client.address.sendMsg(*message);
        ^true;
    }

    sendResult { |client, requestID, ok, action, realizationID, code, detail|
        var message;
        message = [
            '/awb/audition/result', client.clientID, requestID.asString,
            if(ok) { 1 } { 0 }, action.asString, realizationID.asString,
            code.asString, detail.asString
        ];
        client.address.sendMsg(*message);
        this.cacheReply(client, requestID, message);
    }

    authorizedClient { |msg, addr|
        var client;
        if(this.isAllowedAddress(addr).not or: { msg.size < 2 }) { ^nil };
        client = clients[msg[1].asString];
        if(client.isNil
            or: { client.sourceIP != addr.ip.asString }
            or: { client.sourcePort != addr.port }) { ^nil };
        ^client;
    }

    handleHello { |msg, addr|
        var clientID, replyPort, requestingToolID, viewID, parentInstanceID;
        var address, instanceID, instance, old;

        if(this.isAllowedAddress(addr).not or: { msg.size < 5 }) { ^this };
        clientID = msg[1].asString;
        replyPort = msg[2].asInteger;
        requestingToolID = msg[3].asString;
        viewID = msg[4].asString;
        parentInstanceID = if(msg.size > 5) { msg[5].asString } { "" };
        if(clientID.isEmpty or: { viewID.isEmpty }
            or: { clientID.size > 256 or: { viewID.size > 256 } }) { ^this };
        address = NetAddr(addr.ip.asString, if(replyPort > 0) { replyPort } { addr.port });
        old = clients[clientID];
        if(old.notNil) { this.forgetClient(old) };
        instanceID = "synthdefAudition:%:%".format(viewID, clientID);
        instance = SynthDefAuditionTool.openClient(instanceID, (
            requestingToolID: requestingToolID,
            requestingViewID: viewID,
            parentToolInstanceID: parentInstanceID,
            shellManaged: true
        ));
        clients[clientID] = (
            clientID: clientID, address: address,
            sourceIP: addr.ip.asString, sourcePort: addr.port,
            instance: instance, instanceID: instanceID
        );
        address.sendMsg('/awb/audition/connected', clientID, 1, instanceID);
        ^this;
    }

    forgetClient { |client|
        var prefix;
        if(client.isNil) { ^this };
        clients.removeAt(client.clientID);
        prefix = client.clientID ++ ":";
        realizations.keys.copy.do { |key|
            var record;
            if(key.beginsWith(prefix)) {
                record = realizations.removeAt(key);
                record.synths.do { |synth| nodeIndex.removeAt(synth.nodeID) };
            };
        };
        requestCache.keys.copy.do { |key|
            if(key.beginsWith(prefix)) { requestCache.removeAt(key) };
        };
        requestOrder.copy.do { |key|
            if(key.beginsWith(prefix)) { requestOrder.remove(key) };
        };
        if(client.instance.notNil) { client.instance.close };
        ^this;
    }

    handleDisconnect { |msg, addr|
        var client;
        client = this.authorizedClient(msg, addr);
        if(client.notNil) { this.forgetClient(client) };
        ^this;
    }

    controlFor { |description, name|
        ^description.controls.detect { |control| control.name.asSymbol == name.asSymbol };
    }

    voiceArguments { |voice, description|
        var scalarArgs, arrays;
        scalarArgs = List.new;
        arrays = List.new;
        voice.keysValuesDo { |rawName, value|
            var name, control, values;
            name = rawName.asString.asSymbol;
            control = this.controlFor(description, name);
            if(control.isNil) { Error("unknown audition control: %".format(name)).throw };
            if(value.isArray) {
                values = value.asArray;
                if(values.isEmpty or: { values.size > 256 }
                    or: { values.any { |item| item.isNumber.not } }) {
                    Error("audition array control is invalid: %".format(name)).throw;
                };
                if(control.numChannels < values.size) {
                    Error("audition array exceeds control width: %".format(name)).throw;
                };
                arrays.add([name, values]);
            } {
                if(value.isNumber.not) {
                    Error("audition control must be numeric: %".format(name)).throw;
                };
                scalarArgs.add(name);
                scalarArgs.add(value);
            };
        };
        ^[scalarArgs, arrays];
    }

    sendState { |record, state|
        var synths, nodeIDs, voiceStates, message;
        record.state = state;
        synths = record.synths;
        nodeIDs = synths.collect(_.nodeID);
        voiceStates = nodeIDs.collect { |nodeID|
            (record.voiceStates[nodeID] ? state).asString
        };
        message = [
            '/awb/audition/state', record.client.clientID,
            record.realizationID, state.asString, record.definition,
            record.contextID, record.draftID, record.runID,
            nodeIDs.size
        ] ++ nodeIDs ++ voiceStates;
        record.client.address.sendMsg(*message);
    }

    targetSynths { |record, targetNodeID|
        var synth;
        if(targetNodeID.asInteger < 0) { ^record.synths.copy };
        synth = record.synths.detect { |item| item.nodeID == targetNodeID.asInteger };
        if(synth.isNil) {
            Error("audition node is not owned by realization: %".format(targetNodeID)).throw;
        };
        ^[synth];
    }

    nodeEnded { |nodeID|
        var record, synth;
        record = nodeIndex.removeAt(nodeID);
        if(record.isNil) { ^this };
        synth = record.synths.detect { |item| item.nodeID == nodeID };
        if(synth.notNil) { this.synthEnded(record, synth) };
        ^this;
    }

    nodeStarted { |nodeID|
        var record;
        record = nodeIndex[nodeID];
        if(record.isNil or: { record.playedEvent.isNil }) { ^this };
        record.startedNodeIDs.add(nodeID);
        if(record.state == \starting
            and: { record.startedNodeIDs.size == record.synths.size }) {
            this.sendState(record, \running);
        };
        ^this;
    }

    synthEnded { |record, synth|
        if(record.playedEvent.isNil) {
            record.instance.ownedObjectEnded(synth, \ended, \sclang);
        };
        record.synths.remove(synth);
        record.voiceStates.removeAt(synth.nodeID);
        if(record.synths.isEmpty) {
            if(record.playedEvent.notNil) {
                record.instance.ownedObjectEnded(record.playedEvent, \ended, \sclang);
            };
            realizations.removeAt(this.keyFor(
                record.client.clientID, record.realizationID));
            this.sendState(record, \ended);
        } {
            this.sendState(record, record.state ? \running);
        };
        ^this;
    }

    handleEvent { |msg, addr|
        var client, requestID, realizationID, contextID, draftID, runID;
        var contextGeneration, fingerprint, payload, source, normalized, event;
        var definition, description, playedEvent, nodeIDs, record, errorText;

        client = this.authorizedClient(msg, addr);
        if(client.isNil or: { msg.size < 10 }) { ^this };
        requestID = msg[2].asString;
        if(this.resendCached(client, requestID)) { ^this };
        realizationID = msg[3].asString;
        contextID = msg[4].asString;
        draftID = msg[5].asString;
        runID = msg[6].asString;
        contextGeneration = msg[7].asInteger;
        fingerprint = msg[8].asString;
        payload = msg[9].asString;
        errorText = nil;
        try {
            if(Server.default.serverRunning.not) {
                Error("The desktop SuperCollider server is offline.").throw;
            };
            if(realizationID.isEmpty or: {
                realizations[this.keyFor(client.clientID, realizationID)].notNil
            }) { Error("audition realization already exists").throw };
            source = JSONlib.convertToSC(payload, useEvent: false);
            if(source.isKindOf(Dictionary).not) {
                Error("event audition payload must be an object").throw;
            };
            normalized = ScoreSclangConnector.normalizedEntry((
                id: realizationID, time: 0, path: [], event: source
            ), 0);
            event = normalized.event;
            if(event[\type] != \note) {
                Error("event audition currently supports note events only").throw;
            };
            definition = event[\instrument];
            if(definition.isNil) { Error("event audition requires an instrument").throw };
            description = SynthDescLib.global.at(definition.asSymbol);
            if(description.isNil) {
                Error("SynthDef is not installed: %".format(definition)).throw;
            };
            if(event[\dur].asString == "inf") {
                event[\dur] = inf;
                event[\sendGate] = false;
            };
            playedEvent = event.play;
            nodeIDs = playedEvent[\id].asArray.collect(_.asInteger);
            if(nodeIDs.isEmpty or: { nodeIDs.size > 128 }) {
                Error("native Event did not produce 1-128 node IDs").throw;
            };
            record = (
                client: client, instance: client.instance,
                realizationID: realizationID, definition: definition.asString,
                contextID: contextID, draftID: draftID, runID: runID,
                contextGeneration: contextGeneration, fingerprint: fingerprint,
                description: description, synths: List.new,
                voiceStates: IdentityDictionary.new, state: \starting,
                playedEvent: playedEvent, startedNodeIDs: Set.new
            );
            realizations[this.keyFor(client.clientID, realizationID)] = record;
            nodeIDs.do { |nodeID, voiceIndex|
                var synth;
                synth = Synth.basicNew(definition.asSymbol, Server.default, nodeID);
                record.synths.add(synth);
                record.voiceStates[nodeID] = \running;
                nodeIndex[nodeID] = record;
            };
            client.instance.own(playedEvent, \event, (
                role: \auditionEvent,
                realizationID: realizationID,
                auditionRunID: runID,
                auditionContextID: contextID,
                draftID: draftID,
                synthDefContextGeneration: contextGeneration,
                synthDefFingerprint: fingerprint,
                synthDefName: definition.asSymbol
            ));
        } { |error|
            errorText = error.errorString;
            if(record.notNil) {
                record.synths.do { |synth| nodeIndex.removeAt(synth.nodeID) };
                if(record.playedEvent.notNil) {
                    record.playedEvent[\id].asArray.do { |nodeID|
                        Server.default.sendMsg(\n_free, nodeID);
                    };
                };
                realizations.removeAt(this.keyFor(client.clientID, realizationID));
            };
        };
        if(errorText.notNil) {
            this.sendResult(client, requestID, false, \event,
                realizationID, \eventFailed, errorText);
        } {
            this.sendResult(client, requestID, true, \event,
                realizationID, \started, "");
        };
        ^this;
    }

    handlePlay { |msg, addr|
        var client, requestID, realizationID, definition, contextID, draftID;
        var runID, contextGeneration, fingerprint, payload;
        var description, voices, record, errorText;

        client = this.authorizedClient(msg, addr);
        if(client.isNil or: { msg.size < 11 }) { ^this };
        requestID = msg[2].asString;
        if(this.resendCached(client, requestID)) { ^this };
        realizationID = msg[3].asString;
        definition = msg[4].asString;
        contextID = msg[5].asString;
        draftID = msg[6].asString;
        runID = msg[7].asString;
        contextGeneration = msg[8].asInteger;
        fingerprint = msg[9].asString;
        payload = msg[10].asString;
        errorText = nil;
        try {
            if(Server.default.serverRunning.not) {
                Error("The desktop SuperCollider server is offline.").throw;
            };
            if(realizationID.isEmpty or: {
                realizations[this.keyFor(client.clientID, realizationID)].notNil
            }) { Error("audition realization already exists").throw };
            description = SynthDescLib.global.at(definition.asSymbol);
            if(description.isNil) {
                Error("SynthDef is not installed: %".format(definition)).throw;
            };
            voices = JSONlib.convertToSC(payload, useEvent: false);
            if(voices.isArray.not or: { voices.isEmpty } or: { voices.size > 128 }) {
                Error("audition requires 1-128 expanded voices").throw;
            };
            record = (
                client: client, instance: client.instance,
                realizationID: realizationID, definition: definition,
                contextID: contextID, draftID: draftID, runID: runID,
                contextGeneration: contextGeneration, fingerprint: fingerprint,
                description: description, synths: List.new,
                voiceStates: IdentityDictionary.new, state: \starting
            );
            realizations[this.keyFor(client.clientID, realizationID)] = record;
            voices.do { |voice, voiceIndex|
                var prepared, scalarArgs, arrays, synth;
                if(voice.isKindOf(Dictionary).not) {
                    Error("audition voice must be an object").throw;
                };
                prepared = this.voiceArguments(voice, description);
                scalarArgs = prepared[0];
                arrays = prepared[1];
                synth = if(arrays.notEmpty) {
                    Synth.newPaused(definition.asSymbol, scalarArgs.asArray)
                } {
                    Synth(definition.asSymbol, scalarArgs.asArray)
                };
                record.synths.add(synth);
                record.voiceStates[synth.nodeID] = \running;
                nodeIndex[synth.nodeID] = record;
                client.instance.own(synth, \synth, (
                    role: \auditionVoice,
                    realizationID: realizationID,
                    auditionRunID: runID,
                    auditionContextID: contextID,
                    draftID: draftID,
                    synthDefContextGeneration: contextGeneration,
                    synthDefFingerprint: fingerprint,
                    voiceIndex: voiceIndex,
                    synthDefName: definition.asSymbol
                ));
                arrays.do { |pair| synth.setn(pair[0], pair[1]) };
                if(arrays.notEmpty) { synth.run(true) };
            };
            this.sendState(record, \running);
        } { |error|
            errorText = error.errorString;
            if(record.notNil) {
                record.synths.do { |synth| nodeIndex.removeAt(synth.nodeID) };
                record.synths.copy.do(_.free);
                realizations.removeAt(this.keyFor(client.clientID, realizationID));
            };
        };
        if(errorText.notNil) {
            this.sendResult(client, requestID, false, \play,
                realizationID, \auditionFailed, errorText);
        } {
            this.sendResult(client, requestID, true, \play,
                realizationID, \started, "");
        };
        ^this;
    }

    handleCommand { |msg, addr|
        var client, requestID, action, realizationID, record, errorText;
        var resultState, complete, targetNodeID, targets;

        client = this.authorizedClient(msg, addr);
        if(client.isNil or: { msg.size < 5 }) { ^this };
        requestID = msg[2].asString;
        if(this.resendCached(client, requestID)) { ^this };
        action = msg[3].asString.asSymbol;
        realizationID = msg[4].asString;
        targetNodeID = if(msg.size > 5) { msg[5].asInteger } { -1 };
        record = realizations[this.keyFor(client.clientID, realizationID)];
        if(record.isNil) {
            this.sendResult(client, requestID, false, action,
                realizationID, \unknownRealization, realizationID);
            ^this;
        };
        errorText = nil;
        try {
            targets = this.targetSynths(record, targetNodeID);
            switch(action,
                \pause, { targets.do { |synth| synth.run(false) } },
                \resume, { targets.do { |synth| synth.run(true) } },
                \release, { targets.do(_.release) },
                \free, { targets.copy.do(_.free) },
                { Error("Unknown audition command: %".format(action)).throw }
            );
            resultState = case
                { action == \pause } { \paused }
                { action == \resume } { \running }
                { action == \release } { \releasing }
                { \ending };
            targets.do { |synth| record.voiceStates[synth.nodeID] = resultState };
            if(targetNodeID < 0) { record.state = resultState };
        } { |error| errorText = error.errorString };
        if(errorText.notNil) {
            this.sendResult(client, requestID, false, action,
                realizationID, \commandFailed, errorText);
        } {
            complete = {
                if(realizations[this.keyFor(client.clientID, realizationID)].notNil) {
                    this.sendState(record, record.state ? resultState);
                };
                this.sendResult(client, requestID, true, action,
                    realizationID, \applied, "");
            };
            if(action == \pause or: { action == \resume }) {
                // Do not claim a run-state transition until scsynth has processed it.
                Routine({
                    Server.default.sync;
                    complete.value;
                }).play(AppClock);
            } {
                complete.value;
            };
        };
        ^this;
    }

    handleSet { |msg, addr|
        var client, requestID, realizationID, controlName, declaredWidth;
        var valueCount, values, record, control, errorText, complete;
        var targetNodeID, targets;

        client = this.authorizedClient(msg, addr);
        if(client.isNil or: { msg.size < 8 }) { ^this };
        requestID = msg[2].asString;
        if(this.resendCached(client, requestID)) { ^this };
        realizationID = msg[3].asString;
        controlName = msg[4].asString.asSymbol;
        declaredWidth = msg[5].asInteger;
        valueCount = msg[6].asInteger;
        values = msg.copyRange(7, 6 + valueCount).collect(_.asFloat);
        targetNodeID = if(msg.size > (7 + valueCount)) {
            msg[7 + valueCount].asInteger
        } { -1 };
        record = realizations[this.keyFor(client.clientID, realizationID)];
        if(record.isNil) {
            this.sendResult(client, requestID, false, \set,
                realizationID, \unknownRealization, realizationID);
            ^this;
        };
        errorText = nil;
        try {
            if(valueCount < 1 or: { valueCount > 256 } or: { values.size != valueCount }) {
                Error("invalid audition control value count").throw;
            };
            targets = this.targetSynths(record, targetNodeID);
            control = this.controlFor(record.description, controlName);
            if(control.isNil) { Error("Unknown SynthDef control: %".format(controlName)).throw };
            if(control.numChannels.asInteger != declaredWidth) {
                Error("Stale control width for %: expected %, received %".format(
                    controlName, control.numChannels, declaredWidth)).throw;
            };
            if(declaredWidth == 1) {
                targets.do { |synth, index|
                    synth.set(controlName, values.wrapAt(index));
                };
            } {
                if(values.size != declaredWidth) {
                    Error("Control % requires % values".format(controlName, declaredWidth)).throw;
                };
                targets.do { |synth| synth.setn(controlName, values) };
            };
        } { |error| errorText = error.errorString };
        if(errorText.notNil) {
            this.sendResult(client, requestID, false, \set,
                realizationID, \setFailed, errorText);
        } {
            complete = {
                this.sendResult(client, requestID, true, \set,
                    realizationID, \applied, "");
            };
            Routine({ Server.default.sync; complete.value }).play(AppClock);
        };
        ^this;
    }
}
