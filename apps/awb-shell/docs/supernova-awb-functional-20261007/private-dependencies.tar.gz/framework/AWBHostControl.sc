/*
AWBHostControl
==============

Small process-level control plane for AWB desktop hosts. It is deliberately
separate from NodeManager: the language can remain discoverable while live
tracking is disabled.
*/
AWBHostControl {
    classvar <default, startupAction;
    var <mode, <nodeManagerPolicy, <isRunning, <token, responders;

    *initClass {
        startupAction = {
            if(Platform.ideName != "none" and: {
                ("AWB_HOST_AUTOSTART".getenv ? "1") != "0"
            }) {
                this.start(
                    ("AWB_NODEMANAGER_POLICY".getenv ? "whenNeeded").asSymbol,
                    \ide
                );
            };
        };
        StartUp.add(startupAction);
    }

    *new {
        ^super.new.init;
    }

    *start { |nodeManagerPolicy = \whenNeeded, mode = \ide, token|
        if(default.isNil) { default = this.new };
        default.start(nodeManagerPolicy, mode, token);
        ^default;
    }

    *stop {
        if(default.notNil) {
            default.stop;
            default = nil;
        };
    }

    *enableNodeManager {
        ^if(default.notNil) { default.enableNodeManager } { false };
    }

    *disableNodeManager {
        ^if(default.notNil) { default.disableNodeManager } { false };
    }

    *ensureNodeManager {
        ^if(default.notNil) { default.ensureNodeManager } { NodeManager.ensureEnabled };
    }

    *status {
        if(default.isNil) {
            "AWB host control is stopped".postln;
        } {
            default.status.postln;
        };
    }

    init {
        responders = List.new;
        isRunning = false;
        ^this;
    }

    start { |policy = \whenNeeded, hostMode = \ide, controlToken|
        mode = hostMode.asSymbol;
        token = controlToken ? "";
        this.nodeManagerPolicy_(policy);
        if(isRunning) { ^this };

        PTimelineOSCBridge.start;
        AuditionOSCBridge.start;
        SynthDefContextOSCBridge.start;
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleHello(msg, addr);
        }, '/awb/host/hello'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleNodeManager(msg, addr);
        }, '/awb/host/nodemanager'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleShutdown(msg, addr);
        }, '/awb/host/shutdown'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleToolOpen(msg, addr);
        }, '/awb/host/tool/open'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleToolClose(msg, addr);
        }, '/awb/host/tool/close'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleScoreSynthDefs(msg, addr);
        }, '/awb/host/score/synthdefs'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleAudioProbe(msg, addr);
        }, '/awb/host/audio/probe'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleQtStation(msg, addr);
        }, '/awb/host/qt-station/open'));
        isRunning = true;
        ("AWB host ready: " ++ mode ++ ", NodeManager "
            ++ this.nodeManagerStatus).postln;
        ^this;
    }

    stop {
        if(isRunning.not) { ^this };
        NodeManagerOSCBridge.stop;
        responders.do(_.free);
        responders.clear;
        PTimelineOSCBridge.stop;
        AuditionOSCBridge.stop;
        SynthDefContextOSCBridge.stop;
        isRunning = false;
        ^this;
    }

    nodeManagerPolicy_ { |policy|
        policy = policy.asSymbol;
        NodeManager.activationPolicy_(policy);
        nodeManagerPolicy = policy;
        if(policy == \always) {
            this.enableNodeManager;
        } {
            this.disableNodeManager;
        };
        ^nodeManagerPolicy;
    }

    enableNodeManager {
        NodeManager.enable;
        NodeManagerOSCBridge.start;
        ^true;
    }

    ensureNodeManager {
        if(nodeManagerPolicy == \manual) { ^false };
        ^this.enableNodeManager;
    }

    disableNodeManager {
        NodeManagerOSCBridge.stop;
        NodeManager.disable;
        ^false;
    }

    nodeManagerStatus {
        if(NodeManager.isEnabled.not) { ^\disabled };
        if(NodeManagerOSCBridge.default.notNil and: {
            NodeManagerOSCBridge.default.isRunning
        }) { ^\ready };
        ^\localOnly;
    }

    serverStatus {
        ^if(Server.default.notNil and: { Server.default.serverRunning }) {
            \ready
        } {
            \unavailable
        };
    }

    status {
        ^(
            protocol: 1,
            mode: mode,
            processID: thisProcess.pid,
            nodeManager: this.nodeManagerStatus,
            nodeManagerPolicy: nodeManagerPolicy,
            scsynth: this.serverStatus
        );
    }

    allowedAddress { |addr|
        var ip;
        ip = addr.ip.asString;
        ^ip.beginsWith("127.")
            or: { ip.beginsWith("::1") }
            or: { ip.beginsWith("::ffff:127.") };
    }

    tokenMatches { |candidate|
        if(token.isEmpty) { ^true };
        ^candidate.asString == token;
    }

    replyAddress { |msg, addr|
        var replyPort;
        replyPort = if(msg.size > 2) { msg[2].asInteger } { addr.port };
        if(replyPort <= 0) { replyPort = addr.port };
        ^NetAddr(addr.ip.asString, replyPort);
    }

    sendStatus { |clientID, address, requestID = ""|
        address.sendMsg(
            '/awb/host/status', clientID.asString, requestID.asString, 1,
            mode.asString, this.nodeManagerStatus.asString,
            nodeManagerPolicy.asString, this.serverStatus.asString,
            thisProcess.pid, "qt-station"
        );
    }

    handleHello { |msg, addr|
        var clientID, candidate;
        if(this.allowedAddress(addr).not or: { msg.size < 2 }) { ^this };
        clientID = msg[1].asString;
        candidate = if(msg.size > 3) { msg[3] } { "" };
        if(this.tokenMatches(candidate)) {
            this.sendStatus(clientID, this.replyAddress(msg, addr));
        };
        ^this;
    }

    handleNodeManager { |msg, addr|
        var clientID, requestID, action, candidate, address;
        if(this.allowedAddress(addr).not or: { msg.size < 5 }) { ^this };
        clientID = msg[1].asString;
        requestID = msg[3].asString;
        action = msg[4].asString.asSymbol;
        candidate = if(msg.size > 5) { msg[5] } { "" };
        if(this.tokenMatches(candidate).not) { ^this };
        address = this.replyAddress(msg, addr);

        switch(action,
            \enable, { this.enableNodeManager },
            \disable, { this.disableNodeManager },
            \whenNeeded, { this.nodeManagerPolicy_(\whenNeeded) },
            \always, { this.nodeManagerPolicy_(\always) },
            \manual, { this.nodeManagerPolicy_(\manual) },
            \status, { nil },
            {
                address.sendMsg('/awb/host/error', clientID, requestID,
                    "unknown NodeManager action");
                ^this;
            }
        );
        this.sendStatus(clientID, address, requestID);
        ^this;
    }

    handleShutdown { |msg, addr|
        var clientID, requestID, candidate, address;
        if(this.allowedAddress(addr).not or: { msg.size < 5 }) { ^this };
        clientID = msg[1].asString;
        requestID = msg[3].asString;
        candidate = msg[4];
        address = this.replyAddress(msg, addr);
        if(mode != \headless or: { this.tokenMatches(candidate).not }) {
            address.sendMsg('/awb/host/error', clientID, requestID,
                "shutdown rejected for attached host");
            ^this;
        };
        address.sendMsg('/awb/host/shutting-down', clientID, requestID);
        this.stop;
        if(Server.default.notNil and: { Server.default.serverRunning }) {
            Server.default.quit;
        };
        SystemClock.sched(0.5, { 0.exit; nil });
        ^this;
    }

    sendToolStatus { |address, clientID, requestID, status, toolID,
        instanceID|
        address.sendMsg(
            '/awb/host/tool/status', clientID.asString,
            requestID.asString, status.asString, toolID.asString,
            instanceID.asString
        );
    }

    handleAudioProbe { |msg, addr|
        var clientID, requestID, frequency, duration, amplitude;
        var candidate, address, server;

        if(this.allowedAddress(addr).not or: { msg.size < 8 }) { ^this };
        clientID = msg[1].asString;
        requestID = msg[3].asString;
        frequency = msg[4].asFloat.clip(20, 20000);
        duration = msg[5].asFloat.clip(0.05, 2);
        amplitude = msg[6].asFloat.clip(0, 0.2);
        candidate = msg[7];
        address = this.replyAddress(msg, addr);
        if(this.tokenMatches(candidate).not) { ^this };
        server = Server.default;
        if(server.isNil or: { server.serverRunning.not }) {
            address.sendMsg('/awb/host/error', clientID, requestID,
                "SuperCollider server is not running");
            ^this;
        };

        Routine({
            var errorText;
            errorText = nil;
            try {
                SynthDef(\awbHostAudioProbe, {
                    var signal, envelope;
                    envelope = EnvGen.ar(
                        Env.perc(0.005, \duration.kr(0.35), curve: -4),
                        doneAction: Done.freeSelf
                    );
                    signal = SinOsc.ar(\frequency.kr(440), 0,
                        \amplitude.kr(0.08)) * envelope;
                    Out.ar(0, signal ! 2);
                // `add`, not `send`: send transmits without registering in
                // SynthDescLib, and an unregistered def is invisible to
                // SynthDefAnalysis. A probe tone is brief, but if it sounds
                // it should be visible.
                }).add;
                server.sync;
                Synth(\awbHostAudioProbe, [
                    \frequency, frequency,
                    \duration, duration,
                    \amplitude, amplitude
                ], server.defaultGroup);
            } { |error|
                errorText = error.errorString;
            };
            if(errorText.isNil) {
                address.sendMsg('/awb/host/audio/probe/status',
                    clientID, requestID, "played", frequency, duration,
                    amplitude, server.name.asString);
            } {
                address.sendMsg('/awb/host/error', clientID, requestID,
                    errorText);
            };
        }).play(AppClock);
        ^this;
    }

    handleQtStation { |msg, addr|
        var clientID, requestID, address;
        if(this.allowedAddress(addr).not or: { msg.size != 5 }) { ^this };
        if(this.tokenMatches(msg[4]).not) { ^this };
        clientID = msg[1].asString; requestID = msg[3].asString;
        address = this.replyAddress(msg, addr);
        {
            var wasOpen;
            wasOpen = AwbWorkspaceGUI.default.notNil;
            try {
                AwbWorkspaceGUI.openOrFocus;
                address.sendMsg('/awb/host/qt-station/status', clientID, requestID,
                    if(wasOpen) { "focused" } { "opened" });
            } { |error|
                address.sendMsg('/awb/host/error', clientID, requestID, error.errorString);
            };
        }.defer;
        ^this;
    }

    handleToolOpen { |msg, addr|
        var clientID, requestID, toolID, instanceID, candidate, address;
        var instance, definitionID, instancePrefix;

        if(this.allowedAddress(addr).not or: { msg.size < 7 }) { ^this };
        clientID = msg[1].asString;
        requestID = msg[3].asString;
        toolID = msg[4].asString;
        instanceID = msg[5].asString;
        candidate = msg[6];
        address = this.replyAddress(msg, addr);
        if(this.tokenMatches(candidate).not) { ^this };
        case
        { toolID == "score-studio" } {
            definitionID = \scoreArranger;
            instancePrefix = "scoreArranger:";
        }
        { toolID == "field-modelling" } {
            definitionID = \fieldModelling;
            instancePrefix = "fieldModelling:";
        }
        {
            address.sendMsg('/awb/host/error', clientID, requestID,
                "unsupported native tool instance");
            ^this;
        };
        if(instanceID.isEmpty
            or: { instanceID.size > 256 }
            or: { instanceID.beginsWith(instancePrefix).not }) {
            address.sendMsg('/awb/host/error', clientID, requestID,
                "unsupported native tool instance");
            ^this;
        };

        try {
            instance = if(definitionID == \scoreArranger) {
                ScoreStudioTool.openShellInstance(instanceID)
            } {
                FieldModellingTool.openShellInstance(instanceID)
            };
            this.sendToolStatus(
                address, clientID, requestID, \active,
                toolID, instance.instanceID
            );
        } { |error|
            address.sendMsg('/awb/host/error', clientID, requestID,
                error.errorString);
        };
        ^this;
    }

    handleToolClose { |msg, addr|
        var clientID, requestID, toolID, instanceID, candidate, address;
        var instance, definitionID, instancePrefix;

        if(this.allowedAddress(addr).not or: { msg.size < 7 }) { ^this };
        clientID = msg[1].asString;
        requestID = msg[3].asString;
        toolID = msg[4].asString;
        instanceID = msg[5].asString;
        candidate = msg[6];
        address = this.replyAddress(msg, addr);
        if(this.tokenMatches(candidate).not) { ^this };
        case
        { toolID == "score-studio" } {
            definitionID = \scoreArranger;
            instancePrefix = "scoreArranger:";
        }
        { toolID == "field-modelling" } {
            definitionID = \fieldModelling;
            instancePrefix = "fieldModelling:";
        }
        {
            address.sendMsg('/awb/host/error', clientID, requestID,
                "unsupported native tool instance");
            ^this;
        };
        instance = ToolLauncher.at(instanceID);
        if(instanceID.beginsWith(instancePrefix).not
            or: { instance.isNil }
            or: { instance.definition.id != definitionID }
            or: { instance.config[\shellManaged] != true }) {
            address.sendMsg('/awb/host/error', clientID, requestID,
                "unknown shell-owned tool instance");
            ^this;
        };

        instance.close;
        this.sendToolStatus(
            address, clientID, requestID, \closed, toolID, instanceID
        );
        ^this;
    }

    handleScoreSynthDefs { |msg, addr|
        var clientID, requestID, instanceID, sourcePath, allowOverride;
        var candidate, address;

        if(this.allowedAddress(addr).not or: { msg.size < 8 }) { ^this };
        clientID = msg[1].asString;
        requestID = msg[3].asString;
        instanceID = msg[4].asString;
        sourcePath = msg[5].asString;
        allowOverride = msg[6].asInteger == 1;
        candidate = msg[7];
        address = this.replyAddress(msg, addr);
        if(this.tokenMatches(candidate).not) { ^this };

        Routine({
            var errorText, sourceName, outcome, previousSourcePath;
            errorText = nil;
            sourceName = PathName(sourcePath).fileName;
            try {
                outcome = ScoreStudioTool.loadScoreSynthDefs(
                    instanceID, sourcePath, allowOverride
                );
                if(outcome[\status] == \loaded) {
                    Server.default.sync;
                    if(SynthDefContextOSCBridge.default.notNil) {
                        SynthDefContextOSCBridge.default.definitionsChanged;
                    };
                };
            } { |error|
                errorText = error.errorString;
            };
            if(errorText.isNil) {
                previousSourcePath = outcome[\previousSourcePath] ? "";
                address.sendMsg('/awb/host/score/synthdefs/status',
                    clientID, requestID, outcome[\status].asString,
                    instanceID, sourceName, previousSourcePath);
            } {
                address.sendMsg('/awb/host/error', clientID, requestID,
                    errorText);
            };
        }).play(AppClock);
        ^this;
    }
}
