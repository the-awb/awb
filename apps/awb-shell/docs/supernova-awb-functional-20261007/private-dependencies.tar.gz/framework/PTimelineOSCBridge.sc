/*
PTimelineOSCBridge
==================

Revisioned, idempotent OSC control for PScoreTimelinePlayer. Scores arrive as
bounded snapshots containing one JSON string per canonical entry. JSON parsing
is data-only; no received string is interpreted as SuperCollider source.
*/
PTimelineOSCBridge {
    classvar <default;
    var <clients, <players, <snapshots, <responders, <requestCache;
    var <scoreHashes;
    var <requestOrder, <playerCallbacks, <realizationNodes, <realizationStates, <realizationVoiceStates, <liveInstruments;
    var <fieldRequests, <fieldRequestSerial;
    var <isRunning, <allowRemote;
    var <maxCachedRequests;

    *new { |allowRemote = false, maxCachedRequests = 512|
        ^super.new.init(allowRemote, maxCachedRequests);
    }

    *start { |allowRemote = false, maxCachedRequests = 512|
        if(default.isNil) {
            default = this.new(allowRemote, maxCachedRequests);
        };
        default.start;
        ^default;
    }

    *stop {
        if(default.notNil) {
            default.stop;
            default = nil;
        };
    }

    *connectedPlayer { |timeline, scoreID = "untitled", revision = 0,
        templateEvent|
        ^this.start.connectedPlayer(
            timeline, scoreID, revision, templateEvent
        );
    }

    init { |remoteAllowed, cacheLimit|
        clients = Dictionary.new;
        players = Dictionary.new;
        snapshots = Dictionary.new;
        responders = List.new;
        requestCache = Dictionary.new;
        scoreHashes = Dictionary.new;
        requestOrder = List.new;
        playerCallbacks = Dictionary.new;
        realizationNodes = Dictionary.new;
        realizationStates = Dictionary.new;
        realizationVoiceStates = Dictionary.new;
        liveInstruments = Dictionary.new;
        fieldRequests = Dictionary.new;
        fieldRequestSerial = 0;
        isRunning = false;
        allowRemote = remoteAllowed;
        maxCachedRequests = cacheLimit.asInteger.max(16);
        ^this;
    }

    start {
        if(isRunning) { ^this };

        responders.add(OSCFunc({ |msg, time, addr|
            this.handleHello(msg, addr);
        }, '/awb/timeline/hello'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handlePing(msg, addr);
        }, '/awb/timeline/ping'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleObserve(msg, addr);
        }, '/awb/timeline/observe'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleDisconnect(msg, addr);
        }, '/awb/timeline/disconnect'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleSnapshotBegin(msg, addr);
        }, '/awb/timeline/snapshot/begin'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleSnapshotChunk(msg, addr);
        }, '/awb/timeline/snapshot/chunk'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleSnapshotEnd(msg, addr);
        }, '/awb/timeline/snapshot/end'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleCommand(msg, addr);
        }, '/awb/timeline/command'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleRelease(msg, addr);
        }, '/awb/timeline/release'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleRealizationCommand(msg, addr);
        }, '/awb/timeline/realization/command'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleRealizationSet(msg, addr);
        }, '/awb/timeline/realization/set'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleInstrumentCommand(msg, addr);
        }, '/awb/timeline/instrument'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleProjectionRequest(msg, addr);
        }, '/awb/timeline/projection/request'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleFieldObserve(msg, addr);
        }, '/awb/field/observe'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleFieldPhase(msg, addr);
        }, '/awb/field/phase'));

        NodeManager.addObserver(this);
        isRunning = true;
        ^this;
    }

    stop {
        if(isRunning.not) { ^this };

        responders.do(_.free);
        responders.clear;
        NodeManager.removeObserver(this);
        playerCallbacks.keysValuesDo { |scoreID, callback|
            var player;
            player = players[scoreID];
            if(player.notNil) { player.removeDependant(callback) };
        };
        players.values.do { |player|
            if(player.isPlaying) { player.stopAll };
        };
        playerCallbacks.clear;
        clients.clear;
        snapshots.clear;
        requestCache.clear;
        scoreHashes.clear;
        requestOrder.clear;
        realizationNodes.clear;
        realizationStates.clear;
        realizationVoiceStates.clear;
        liveInstruments.clear;
        fieldRequests.clear;
        isRunning = false;
        ^this;
    }

    playerFor { |scoreID|
        ^players[scoreID.asString];
    }

    connectedPlayer { |timeline, scoreID, revision, templateEvent|
        var key, player;

        key = scoreID.asString;
        player = players[key];
        if(player.isNil) {
            player = PScoreTimelinePlayer(
                timeline, templateEvent, key, revision
            );
            players[key] = player;
            this.attachPlayer(key, player);
        };
        ^player;
    }

    isAllowedAddress { |addr|
        var ip;

        if(allowRemote) { ^true };
        ip = addr.ip.asString;
        ^ip.beginsWith("127.")
            or: { ip.beginsWith("::1") }
            or: { ip.beginsWith("::ffff:127.") };
    }

    handleHello { |msg, addr|
        var clientID, replyPort, client, toolInstance, instance, connected;

        if(this.isAllowedAddress(addr).not or: { msg.size < 2 }) { ^this };
        clientID = msg[1].asString;
        replyPort = if(msg.size > 2) { msg[2].asInteger } { addr.port };
        toolInstance = if(msg.size > 3) { msg[3].asString } { "" };
        if(replyPort <= 0) { replyPort = addr.port };
        if(toolInstance.notEmpty) {
            instance = ToolLauncher.at(toolInstance);
            connected = if(instance.isNil) {
                false
            } {
                case
                { instance.definition.id == \scoreArranger } {
                    ScoreStudioTool.markConnected(toolInstance, clientID)
                }
                { instance.definition.id == \fieldModelling } {
                    FieldModellingTool.markConnected(toolInstance, clientID)
                }
                { false };
            };
            if(connected.not) { ^this };
        };
        client = (
            clientID: clientID,
            address: NetAddr(addr.ip.asString, replyPort),
            sourceIP: addr.ip.asString,
            sourcePort: addr.port,
            scores: Set.new,
            activeScore: "",
            toolInstance: toolInstance
        );
        clients[clientID] = client;
        client.address.sendMsg('/awb/timeline/connected', clientID, 2);
        this.sendRuntime(client, nil);
    }

    handlePing { |msg, addr|
        var client, nonce;

        client = this.authorizedClient(msg, addr);
        if(client.isNil) { ^this };
        nonce = if(msg.size > 2) { msg[2] } { 0 };
        client.address.sendMsg(
            '/awb/timeline/pong', client.clientID, nonce, Main.elapsedTime
        );
        this.sendRuntime(client, players[client.activeScore]);
    }

    // Read-only attachment for companion views. Unlike command/projection requests this only
    // declares interest in an already-installed score and publishes its current runtime state.
    handleObserve { |msg, addr|
        var client, requestID, scoreID, expectedRevision, player;

        client = this.authorizedClient(msg, addr);
        if(client.isNil or: { msg.size < 5 }) { ^this };
        requestID = msg[2].asString;
        if(this.resendCached(client, requestID)) { ^this };
        scoreID = msg[3].asString;
        expectedRevision = msg[4].asInteger;
        player = players[scoreID];
        if(player.isNil) {
            this.sendResult(client, requestID, false, \observe,
                scoreID, -1, \unknownScore, scoreID);
            ^this;
        };
        if(expectedRevision >= 0 and: { player.revision != expectedRevision }) {
            this.sendResult(client, requestID, false, \observe,
                scoreID, player.revision, \revisionConflict,
                expectedRevision.asString);
            ^this;
        };
        client.scores.add(scoreID);
        client.activeScore = scoreID;
        this.sendResult(client, requestID, true, \observe,
            scoreID, player.revision, \observing, (player.runID ? "").asString);
        this.sendTransport(client, player);
        this.sendRuntime(client, player);
        this.sendActiveRealizations(client, player);
    }

    sendActiveRealizations { |client, player|
        player.currentStreamEvents.do { |event|
            var realizationID, nodeIDs, voiceStates, state, message;
            realizationID = event[\__scoreRealizationID];
            if(realizationID.notNil) {
                nodeIDs = (event[\id] ? []).asArray.copy;
                realizationNodes[realizationID] = nodeIDs.copy;
                state = realizationStates[realizationID.asString] ? \started;
                voiceStates = realizationVoiceStates[realizationID.asString];
                if(voiceStates.isNil) {
                    voiceStates = IdentityDictionary.new;
                    nodeIDs.do { |nodeID| voiceStates[nodeID] = state };
                    realizationVoiceStates[realizationID.asString] = voiceStates;
                };
                message = [
                    '/awb/timeline/realization', client.clientID,
                    event[\__scoreID].asString,
                    event[\__scoreRevision].asInteger,
                    event[\__scoreRunID].asString,
                    event[\__scoreEntryID].asString,
                    realizationID.asString,
                    state.asString,
                    event[\__scoreIndex].asInteger,
                    event[\__scoreTime].asFloat,
                    nodeIDs.size
                ] ++ nodeIDs ++ nodeIDs.collect { |nodeID|
                    (voiceStates[nodeID] ? state).asString
                };
                client.address.sendMsg(*message);
            };
        };
    }

    handleDisconnect { |msg, addr|
        var client;

        if(this.isAllowedAddress(addr).not or: { msg.size < 2 }) { ^this };
        client = clients[msg[1].asString];
        if(client.isNil
            or: { client.sourceIP != addr.ip.asString }
            or: { client.sourcePort != addr.port }) {
            ^this;
        };
        this.forgetClient(client, \browserDisconnected);
    }

    forgetClient { |client, reason|
        var prefix, instance;

        clients.removeAt(client.clientID);
        prefix = client.clientID ++ ":";
        snapshots.keys.copy.do { |key|
            if(key.beginsWith(prefix)) { snapshots.removeAt(key) };
        };
        requestCache.keys.copy.do { |key|
            if(key.beginsWith(prefix)) { requestCache.removeAt(key) };
        };
        requestOrder.copy.do { |key|
            if(key.beginsWith(prefix)) { requestOrder.remove(key) };
        };
        if(client.toolInstance.notEmpty) {
            instance = ToolLauncher.at(client.toolInstance);
            if(instance.notNil) {
                case
                { instance.definition.id == \scoreArranger } {
                    ScoreStudioTool.markDisconnected(
                        client.toolInstance, client.clientID, reason
                    );
                }
                { instance.definition.id == \fieldModelling } {
                    FieldModellingTool.markDisconnected(
                        client.toolInstance, client.clientID, reason
                    );
                };
            };
        };
        ^this;
    }

    handleSnapshotBegin { |msg, addr|
        var client, requestID, snapshotID, scoreID, revision;
        var expectedRevision, entryCount, contentHash, snapshot;
        var expectedGeneration, expectedFrontier;

        client = this.authorizedClient(msg, addr);
        if(client.isNil or: { msg.size < 9 }) { ^this };
        requestID = msg[2].asString;
        if(this.resendCached(client, requestID)) { ^this };

        snapshotID = msg[3].asString;
        scoreID = msg[4].asString;
        revision = msg[5].asInteger;
        expectedRevision = msg[6].asInteger;
        entryCount = msg[7].asInteger;
        contentHash = msg[8].asString;
        expectedGeneration = if(msg.size > 9 and: { msg[9].asInteger >= 0 }) {
            msg[9].asInteger
        } { nil };
        expectedFrontier = if(msg.size > 10 and: { msg[10].asFloat >= 0 }) {
            msg[10].asFloat
        } { nil };

        if(entryCount < 0) {
            this.sendResult(client, requestID, false, \snapshotBegin,
                scoreID, revision, \invalidEntryCount, entryCount.asString);
            ^this;
        };

        snapshot = (
            snapshotID: snapshotID,
            scoreID: scoreID,
            revision: revision,
            expectedRevision: expectedRevision,
            entryCount: entryCount,
            contentHash: contentHash,
            expectedGeneration: expectedGeneration,
            expectedFrontier: expectedFrontier,
            chunks: Dictionary.new
        );
        snapshot[\clientID] = client.clientID;
        snapshots[this.snapshotKey(client, snapshotID)] = snapshot;
        client.scores.add(scoreID);
        this.sendResult(client, requestID, true, \snapshotBegin,
            scoreID, revision, \accepted, snapshotID);
    }

    handleSnapshotChunk { |msg, addr|
        var client, requestID, snapshotID, chunkIndex, snapshot;
        var entries, previous;

        client = this.authorizedClient(msg, addr);
        if(client.isNil or: { msg.size < 6 }) { ^this };
        requestID = msg[2].asString;
        if(this.resendCached(client, requestID)) { ^this };

        snapshotID = msg[3].asString;
        chunkIndex = msg[4].asInteger;
        snapshot = snapshots[this.snapshotKey(client, snapshotID)];
        if(snapshot.isNil) {
            this.sendResult(client, requestID, false, \snapshotChunk,
                "", -1, \unknownSnapshot, snapshotID);
            ^this;
        };
        entries = msg.copyRange(5, msg.size - 1).collect(_.asString);
        previous = snapshot.chunks[chunkIndex];
        if(previous.notNil and: { previous != entries }) {
            this.sendResult(client, requestID, false, \snapshotChunk,
                snapshot.scoreID, snapshot.revision, \conflictingChunk,
                chunkIndex.asString);
            ^this;
        };
        snapshot.chunks[chunkIndex] = entries;
        this.sendResult(client, requestID, true, \snapshotChunk,
            snapshot.scoreID, snapshot.revision, \accepted, chunkIndex.asString);
    }

    handleSnapshotEnd { |msg, addr|
        var client, requestID, snapshotID, chunkCount, snapshot;
        var missing, entryStrings, parsed, player, result, parseError;

        client = this.authorizedClient(msg, addr);
        if(client.isNil or: { msg.size < 5 }) { ^this };
        requestID = msg[2].asString;
        if(this.resendCached(client, requestID)) { ^this };

        snapshotID = msg[3].asString;
        chunkCount = msg[4].asInteger;
        snapshot = snapshots[this.snapshotKey(client, snapshotID)];
        if(snapshot.isNil) {
            this.sendResult(client, requestID, false, \snapshotEnd,
                "", -1, \unknownSnapshot, snapshotID);
            ^this;
        };

        if(chunkCount < 0) {
            this.sendResult(client, requestID, false, \snapshotEnd,
                snapshot.scoreID, snapshot.revision, \invalidChunkCount,
                chunkCount.asString);
            ^this;
        };
        missing = if(chunkCount == 0) {
            []
        } {
            (0 .. (chunkCount - 1)).select { |index|
                snapshot.chunks[index].isNil
            }
        };
        if(missing.notEmpty) {
            snapshots.removeAt(this.snapshotKey(client, snapshotID));
            this.sendResult(client, requestID, false, \snapshotEnd,
                snapshot.scoreID, snapshot.revision, \missingChunks,
                missing.asString);
            ^this;
        };

        entryStrings = List.new;
        if(chunkCount > 0) {
            (0 .. (chunkCount - 1)).do { |index|
                entryStrings.addAll(snapshot.chunks[index]);
            };
        };
        entryStrings = entryStrings.asArray;
        if(entryStrings.size != snapshot.entryCount) {
            snapshots.removeAt(this.snapshotKey(client, snapshotID));
            this.sendResult(client, requestID, false, \snapshotEnd,
                snapshot.scoreID, snapshot.revision, \entryCountMismatch,
                entryStrings.size.asString);
            ^this;
        };

        parsed = nil;
        parseError = nil;
        try {
            parsed = entryStrings.collect { |json, index|
                var entry;
                if(\JSONlib.asClass.isNil) {
                    Error("JSONlib is required for timeline snapshots").throw;
                };
                entry = JSONlib.convertToSC(json, useEvent: false);
                if(entry.isKindOf(Dictionary).not) {
                    Error("Snapshot entry % is not a JSON object".format(index)).throw;
                };
                entry;
            };
            parsed = ScoreSclangConnector.normalizeScore(parsed);
        } { |error|
            parseError = error.errorString;
        };
        if(parseError.notNil) {
            snapshots.removeAt(this.snapshotKey(client, snapshotID));
            this.sendResult(client, requestID, false, \snapshotEnd,
                snapshot.scoreID, snapshot.revision, \invalidScore, parseError);
            ^this;
        };

        player = players[snapshot.scoreID];
        if(player.isNil) {
            if(snapshot.expectedRevision >= 0) {
                snapshots.removeAt(this.snapshotKey(client, snapshotID));
                this.sendResult(client, requestID, false, \snapshotEnd,
                    snapshot.scoreID, snapshot.revision, \revisionConflict,
                    "score does not exist");
                ^this;
            };
            player = PScoreTimelinePlayer(
                parsed, nil, snapshot.scoreID, snapshot.revision
            );
            players[snapshot.scoreID] = player;
            this.attachPlayer(snapshot.scoreID, player);
            result = (ok: true);
        } {
            result = player.replaceFuture(
                parsed, snapshot.revision, snapshot.expectedRevision,
                snapshot.expectedGeneration, snapshot.expectedFrontier
            );
        };

        if(result.ok.not) {
            snapshots.removeAt(this.snapshotKey(client, snapshotID));
            this.sendResult(client, requestID, false, \snapshotEnd,
                snapshot.scoreID, snapshot.revision, result.error,
                result.asString);
            ^this;
        };

        snapshots.removeAt(this.snapshotKey(client, snapshotID));
        scoreHashes[snapshot.scoreID] = snapshot.contentHash;
        client.activeScore = snapshot.scoreID;
        if(client.toolInstance.notEmpty) {
            ScoreStudioTool.bindPlayer(client.toolInstance, player);
        };
        this.sendResult(client, requestID, true, \snapshotEnd,
            snapshot.scoreID, snapshot.revision, result[\code] ? \installed,
            snapshot.contentHash);
        this.broadcastTransport(player);
        this.sendRuntime(client, player);
    }

    handleCommand { |msg, addr|
        var client, requestID, scoreID, expectedRevision, command;
        var argument, player, errorText, runtime, commandDetail;

        client = this.authorizedClient(msg, addr);
        if(client.isNil or: { msg.size < 7 }) { ^this };
        requestID = msg[2].asString;
        if(this.resendCached(client, requestID)) { ^this };

        scoreID = msg[3].asString;
        expectedRevision = msg[4].asInteger;
        command = msg[5].asString.asSymbol;
        argument = msg[6];
        player = players[scoreID];
        client.scores.add(scoreID);
        client.activeScore = scoreID;

        if(player.isNil) {
            this.sendResult(client, requestID, false, command,
                scoreID, -1, \unknownScore, scoreID);
            ^this;
        };
        if(expectedRevision >= 0 and: { player.revision != expectedRevision }) {
            this.sendResult(client, requestID, false, command,
                scoreID, player.revision, \revisionConflict,
                expectedRevision.asString);
            ^this;
        };

        if([\play, \resume].includes(command)) {
            runtime = this.runtimeFor(player);
            if(runtime.canPlay.not) {
                this.sendResult(client, requestID, false, command,
                    scoreID, player.revision, \runtimeNotReady,
                    runtime.reason);
                this.sendRuntime(client, player);
                ^this;
            };
        };

        errorText = nil;
        commandDetail = "";
        try {
            switch(command,
                \play, { player.play },
                \pause, { player.pause },
                \resume, { player.resume },
                \stop, { player.stopAll },
                \seek, { player.jumpToTime(argument.asFloat) },
                \smartSeek, {
                    var source, normalized, reconstructions;
                    if(\JSONlib.asClass.isNil) {
                        Error("JSONlib is required for smart seek").throw;
                    };
                    source = JSONlib.convertToSC(argument.asString, useEvent: false);
                    if(source.isKindOf(Dictionary).not) {
                        Error("Smart-seek plan is not a JSON object").throw;
                    };
                    if(ScoreSclangConnector.valueAt(source, \scoreID).asString != scoreID
                        or: { ScoreSclangConnector.valueAt(source, \revision).asInteger != player.revision }) {
                        Error("Smart-seek plan does not match the loaded score revision").throw;
                    };
                    reconstructions = ScoreSclangConnector.valueAt(source, \reconstructions) ? [];
                    normalized = Event.new;
                    normalized[\target] = ScoreSclangConnector.valueAt(source, \target).asFloat;
                    normalized[\skipped] = ScoreSclangConnector.valueAt(source, \skipped) ? [];
                    normalized[\reconstructions] = reconstructions.collect { |item, index|
                        var entry, result;
                        entry = (
                            id: ScoreSclangConnector.valueAt(item, \entryID),
                            time: normalized[\target], path: [],
                            event: ScoreSclangConnector.valueAt(item, \event)
                        );
                        result = ScoreSclangConnector.normalizedEntry(entry, index);
                        result[\entryID] = result[\id];
                        result[\sourceTime] = ScoreSclangConnector.valueAt(item, \sourceTime).asFloat;
                        result[\voiceIndex] = ScoreSclangConnector.valueAt(item, \voiceIndex).asInteger;
                        result[\quality] = ScoreSclangConnector.valueAt(item, \quality).asSymbol;
                        result[\phase] = ScoreSclangConnector.valueAt(item, \phase).asSymbol;
                        result[\remainingGate] = ScoreSclangConnector.valueAt(item, \remainingGate);
                        result[\remainingRelease] = ScoreSclangConnector.valueAt(item, \remainingRelease);
                        result;
                    };
                    player.smartJumpToTime(normalized);
                    commandDetail = "% reconstructed, % skipped".format(
                        normalized[\reconstructions].size, normalized[\skipped].size
                    );
                },
                \state, { nil },
                \openDocument, {
                    ScoreSclangConnector.openWorkingDocument(
                        player.timeline, player.scoreID, player.revision
                    );
                },
                { Error("Unknown timeline command: %".format(command)).throw }
            );
        } { |error|
            errorText = error.errorString;
        };
        if(errorText.notNil) {
            this.sendResult(client, requestID, false, command,
                scoreID, player.revision, \commandFailed, errorText);
            ^this;
        };

        this.sendResult(client, requestID, true, command,
            scoreID, player.revision, \applied, commandDetail);
        this.sendTransport(client, player);
        this.sendRuntime(client, player);
    }

    requiredDefinitions { |player|
        var names;

        if(player.isNil) { ^[] };
        names = List.new;
        player.timeline.do { |entry|
            var event, name;
            event = entry[\event];
            if(event.notNil and: { event[\type].asSymbol == \note }) {
                name = event[\instrument] ? event[\def];
                if(name.notNil and: { names.includes(name.asString).not }) {
                    names.add(name.asString);
                };
            };
        };
        ^names.asArray;
    }

    runtimeFor { |player|
        var engine, score, definitions, required, missing, reason, canPlay;

        engine = if(Server.default.serverRunning) { \ready } { \offline };
        score = if(player.notNil) { \ready } { \notLoaded };
        required = this.requiredDefinitions(player);
        missing = required.select { |name|
            SynthDescLib.global.at(name.asSymbol).isNil
        };
        definitions = if(player.isNil) {
            \unknown
        } {
            if(missing.isEmpty) { \ready } { \missing }
        };
        reason = case
        { engine != \ready } { "The desktop SuperCollider server is offline." }
        { score != \ready } { "The selected score revision is not loaded." }
        { definitions == \missing } {
            "Missing SynthDefs: %".format(missing.join(", "))
        }
        { "" };
        canPlay = (engine == \ready)
            and: { score == \ready }
            and: { definitions == \ready };
        ^(
            engine: engine,
            audio: \notApplicable,
            score: score,
            definitions: definitions,
            missingDefinitions: missing,
            canPlay: canPlay,
            reason: reason
        );
    }

    sendRuntime { |client, player|
        var runtime, message;

        runtime = this.runtimeFor(player);
        message = [
            '/awb/timeline/runtime',
            client.clientID,
            runtime.engine.asString,
            runtime.audio.asString,
            runtime.score.asString,
            runtime.definitions.asString,
            runtime.reason.asString,
            runtime.missingDefinitions.size
        ] ++ runtime.missingDefinitions;
        client.address.sendMsg(*message);
    }

    handleRelease { |msg, addr|
        var client, requestID, scoreID, expectedRevision, expectedRunID;
        var realizationID, releaseTime, player, result;

        client = this.authorizedClient(msg, addr);
        if(client.isNil or: { msg.size < 8 }) { ^this };
        requestID = msg[2].asString;
        if(this.resendCached(client, requestID)) { ^this };

        scoreID = msg[3].asString;
        expectedRevision = msg[4].asInteger;
        expectedRunID = msg[5].asString;
        realizationID = msg[6].asString;
        releaseTime = msg[7].asFloat.max(0);
        player = players[scoreID];
        client.scores.add(scoreID);

        if(player.isNil) {
            this.sendResult(client, requestID, false, \release,
                scoreID, -1, \unknownScore, scoreID);
            ^this;
        };
        if(player.revision != expectedRevision) {
            this.sendResult(client, requestID, false, \release,
                scoreID, player.revision, \revisionConflict,
                expectedRevision.asString);
            ^this;
        };

        result = player.releaseRealization(
            expectedRunID, realizationID, releaseTime
        );
        this.sendResult(client, requestID, result.ok, \release,
            scoreID, player.revision, result.code, realizationID);
    }

    handleRealizationCommand { |msg, addr|
        var client, requestID, scoreID, expectedRevision, expectedRunID;
        var realizationID, action, releaseTime, targetNodeID, player, result;

        client = this.authorizedClient(msg, addr);
        if(client.isNil or: { msg.size < 9 }) { ^this };
        requestID = msg[2].asString;
        if(this.resendCached(client, requestID)) { ^this };

        scoreID = msg[3].asString;
        expectedRevision = msg[4].asInteger;
        expectedRunID = msg[5].asString;
        realizationID = msg[6].asString;
        action = msg[7].asString.asSymbol;
        releaseTime = msg[8].asFloat.max(0);
        targetNodeID = if(msg.size > 9) { msg[9].asInteger } { -1 };
        player = players[scoreID];
        client.scores.add(scoreID);

        if(player.isNil) {
            this.sendResult(client, requestID, false, action,
                scoreID, -1, \unknownScore, scoreID);
            ^this;
        };
        if(player.revision != expectedRevision) {
            this.sendResult(client, requestID, false, action,
                scoreID, player.revision, \revisionConflict,
                expectedRevision.asString);
            ^this;
        };

        result = player.controlRealization(
            expectedRunID, realizationID, action, releaseTime, targetNodeID
        );
        if(result.ok and: { action != \release }) {
            this.broadcastRuntimeRealization(player, result.state, result.event, targetNodeID);
        };
        this.sendResult(client, requestID, result.ok, action,
            scoreID, player.revision, result.code, realizationID);
    }

    handleRealizationSet { |msg, addr|
        var client, requestID, scoreID, expectedRevision, expectedRunID;
        var realizationID, control, width, valueCount, values, targetNodeID, player, result;

        client = this.authorizedClient(msg, addr);
        if(client.isNil or: { msg.size < 11 }) { ^this };
        requestID = msg[2].asString;
        if(this.resendCached(client, requestID)) { ^this };
        scoreID = msg[3].asString;
        expectedRevision = msg[4].asInteger;
        expectedRunID = msg[5].asString;
        realizationID = msg[6].asString;
        control = msg[7].asString.asSymbol;
        width = msg[8].asInteger;
        valueCount = msg[9].asInteger;
        values = msg.copyRange(10, 9 + valueCount).collect(_.asFloat);
        targetNodeID = if(msg.size > (10 + valueCount)) {
            msg[10 + valueCount].asInteger
        } { -1 };
        player = players[scoreID];
        client.scores.add(scoreID);
        if(player.isNil) {
            this.sendResult(client, requestID, false, \set,
                scoreID, -1, \unknownScore, scoreID);
            ^this;
        };
        if(player.revision != expectedRevision) {
            this.sendResult(client, requestID, false, \set,
                scoreID, player.revision, \revisionConflict,
                expectedRevision.asString);
            ^this;
        };
        if(valueCount < 1 or: { valueCount > 256 }
            or: { values.size != valueCount }) {
            this.sendResult(client, requestID, false, \set,
                scoreID, player.revision, \invalidValues, realizationID);
            ^this;
        };
        result = player.setRealization(
            expectedRunID, realizationID, control, width, values, targetNodeID
        );
        this.sendResult(client, requestID, result.ok, \set,
            scoreID, player.revision, result.code, realizationID);
    }

    liveInstrumentKey { |client, instrumentID|
        ^client.toolInstance.asString ++ ":" ++ instrumentID.asString;
    }

    instrumentArguments { |message, startIndex, definition|
        var args, names;

        args = if(message.size > startIndex) {
            message.copyRange(startIndex, message.size - 1)
        } {
            []
        };
        if(args.size.odd) {
            Error("instrument controls must be name/value pairs").throw;
        };
        if(args.size > 256) {
            Error("instrument command exceeds 128 controls").throw;
        };
        names = SynthDescLib.global.at(definition.asSymbol).controls
            .collect { |control| control.name.asSymbol };
        args.pairsDo { |name, value|
            if(names.includes(name.asString.asSymbol).not) {
                Error("unknown instrument control: %".format(name)).throw;
            };
            if(value.isNumber.not) {
                Error("instrument control values must be numeric").throw;
            };
        };
        ^args.collect { |item, index|
            if(index.even) { item.asString.asSymbol } { item }
        };
    }

    instrumentArrayArguments { |message, startIndex, definition|
        var name, count, values, description, control;

        if(message.size < (startIndex + 3)) {
            Error("instrument setn requires control, count and values").throw;
        };
        name = message[startIndex].asString.asSymbol;
        count = message[startIndex + 1].asInteger;
        if(count < 1 or: { count > 256 }
            or: { message.size != (startIndex + 2 + count) }) {
            Error("instrument setn count is invalid").throw;
        };
        description = SynthDescLib.global.at(definition.asSymbol);
        control = description.controls.detect { |item|
            item.name.asSymbol == name
        };
        if(control.isNil) {
            Error("unknown instrument control: %".format(name)).throw;
        };
        if(control.numChannels < count) {
            Error("instrument setn exceeds control width: %".format(name)).throw;
        };
        values = message.copyRange(startIndex + 2, message.size - 1);
        if(values.any { |value| value.isNumber.not }) {
            Error("instrument setn values must be numeric").throw;
        };
        ^[name, values];
    }

    sendInstrumentState { |client, instrumentID, state, synth|
        client.address.sendMsg(
            '/awb/timeline/instrument/state',
            client.clientID,
            instrumentID.asString,
            state.asString,
            if(synth.notNil) { synth.nodeID } { -1 }
        );
    }

    handleInstrumentCommand { |msg, addr|
        var client, requestID, action, instrumentID, definition;
        var instance, key, synth, args, errorText, code;

        client = this.authorizedClient(msg, addr);
        if(client.isNil or: { msg.size < 5 }) { ^this };
        requestID = msg[2].asString;
        if(this.resendCached(client, requestID)) { ^this };
        action = msg[3].asString.asSymbol;
        instrumentID = msg[4].asString;
        definition = if(msg.size > 5) { msg[5].asString } { "" };
        key = this.liveInstrumentKey(client, instrumentID);
        synth = liveInstruments[key];
        instance = ToolLauncher.at(client.toolInstance.asString);
        errorText = nil;
        code = \applied;

        if(client.toolInstance.isEmpty or: { instance.isNil }
            or: { [\scoreArranger, \fieldModelling].includes(
                instance.definition.id
            ).not }) {
            this.sendResult(client, requestID, false, action,
                instrumentID, 0, \unknownToolInstance, client.toolInstance);
            ^this;
        };

        try {
            switch(action,
                \start, {
                    if(Server.default.serverRunning.not) {
                        Error("The desktop SuperCollider server is offline.").throw;
                    };
                    if(definition.isEmpty or: {
                        SynthDescLib.global.at(definition.asSymbol).isNil
                    }) {
                        Error("SynthDef is not installed: %".format(definition)).throw;
                    };
                    if(synth.notNil) {
                        code = \alreadyRunning;
                    } {
                        args = this.instrumentArguments(msg, 6, definition);
                        synth = Synth(definition.asSymbol, args);
                        liveInstruments[key] = synth;
                        instance.own(synth, \synth, (
                            role: \liveInstrument,
                            instrumentID: instrumentID,
                            synthDefName: definition.asSymbol
                        ));
                        synth.onFree({
                            instance.ownedObjectEnded(synth, \ended, \sclang);
                            if(liveInstruments[key] === synth) {
                                liveInstruments.removeAt(key);
                                this.sendInstrumentState(
                                    client, instrumentID, \ended, nil
                                );
                            };
                        });
                    };
                    this.sendInstrumentState(client, instrumentID, \running, synth);
                },
                \set, {
                    if(synth.isNil) { Error("instrument is not running").throw };
                    definition = synth.defName.asString;
                    args = this.instrumentArguments(msg, 6, definition);
                    synth.set(*args);
                    this.sendInstrumentState(client, instrumentID, \running, synth);
                },
                \setn, {
                    if(synth.isNil) { Error("instrument is not running").throw };
                    definition = synth.defName.asString;
                    args = this.instrumentArrayArguments(msg, 6, definition);
                    synth.setn(args[0], args[1]);
                    this.sendInstrumentState(client, instrumentID, \running, synth);
                },
                \pause, {
                    if(synth.isNil) { Error("instrument is not running").throw };
                    synth.run(false);
                    this.sendInstrumentState(client, instrumentID, \paused, synth);
                },
                \resume, {
                    if(synth.isNil) { Error("instrument is not running").throw };
                    synth.run(true);
                    this.sendInstrumentState(client, instrumentID, \running, synth);
                },
                \release, {
                    if(synth.isNil) { Error("instrument is not running").throw };
                    synth.release;
                    this.sendInstrumentState(client, instrumentID, \releasing, synth);
                },
                \free, {
                    if(synth.isNil) { Error("instrument is not running").throw };
                    synth.free;
                    liveInstruments.removeAt(key);
                    this.sendInstrumentState(client, instrumentID, \ended, nil);
                },
                { Error("Unknown instrument command: %".format(action)).throw }
            );
        } { |error|
            errorText = error.errorString;
        };
        if(errorText.notNil) {
            this.sendResult(client, requestID, false, action,
                instrumentID, 0, \instrumentCommandFailed, errorText);
            ^this;
        };
        this.sendResult(client, requestID, true, action,
            instrumentID, 0, code, "");
    }

    handleProjectionRequest { |msg, addr|
        var client, requestID, scoreID, expectedRevision, contentHash, kind;
        var player, installedHash, projectionText, chunks, messages, errorText;

        client = this.authorizedClient(msg, addr);
        if(client.isNil or: { msg.size < 7 }) { ^this };
        requestID = msg[2].asString;
        if(this.resendCached(client, requestID)) { ^this };

        scoreID = msg[3].asString;
        expectedRevision = msg[4].asInteger;
        contentHash = msg[5].asString;
        kind = msg[6].asString.asSymbol;
        player = players[scoreID];
        client.scores.add(scoreID);

        if(player.isNil) {
            this.sendResult(client, requestID, false, \projection,
                scoreID, -1, \unknownScore, scoreID);
            ^this;
        };
        if(player.revision != expectedRevision) {
            this.sendResult(client, requestID, false, \projection,
                scoreID, player.revision, \revisionConflict,
                expectedRevision.asString);
            ^this;
        };
        installedHash = scoreHashes[scoreID];
        if(installedHash.isNil or: { installedHash != contentHash }) {
            this.sendResult(client, requestID, false, \projection,
                scoreID, player.revision, \contentHashMismatch, contentHash);
            ^this;
        };

        projectionText = nil;
        errorText = nil;
        try {
            projectionText = ScoreSclangConnector.projectionDocumentText(
                player.timeline, player.scoreID, player.revision, kind
            );
        } { |error|
            errorText = error.errorString;
        };
        if(errorText.notNil) {
            this.sendResult(client, requestID, false, \projection,
                scoreID, player.revision, \projectionFailed, errorText);
            ^this;
        };

        chunks = this.chunkUTF8(projectionText, 2048);
        messages = List.new;
        messages.add([
            '/awb/timeline/projection/begin', client.clientID,
            requestID, scoreID, player.revision, installedHash,
            kind.asString, chunks.size, projectionText.size
        ]);
        chunks.do { |chunk, index|
            messages.add([
                '/awb/timeline/projection/chunk', client.clientID,
                requestID, index, chunk
            ]);
        };
        messages.add([
            '/awb/timeline/projection/end', client.clientID,
            requestID, scoreID, player.revision, installedHash,
            kind.asString, chunks.size
        ]);
        messages.add(this.resultMessage(
            client, requestID, true, \projection,
            scoreID, player.revision, \generated, chunks.size.asString
        ));
        this.cacheAndSend(client, requestID, messages.asArray);
    }

    utf8SizeOfChar { |character|
        var code;

        code = character.ascii;
        if(code < 128) { ^1 };
        if(code < 2048) { ^2 };
        if(code < 65536) { ^3 };
        ^4;
    }

    chunkUTF8 { |string, maxBytes = 2048|
        var chunks, current, currentBytes;

        chunks = List.new;
        current = "";
        currentBytes = 0;
        string.do { |character|
            var characterBytes;

            characterBytes = this.utf8SizeOfChar(character);
            if(current.notEmpty and: {
                (currentBytes + characterBytes) > maxBytes
            }) {
                chunks.add(current);
                current = "";
                currentBytes = 0;
            };
            current = current ++ character;
            currentBytes = currentBytes + characterBytes;
        };
        if(current.notEmpty or: { string.isEmpty }) { chunks.add(current) };
        ^chunks.asArray;
    }

    authorizedClient { |msg, addr|
        var client;

        if(this.isAllowedAddress(addr).not or: { msg.size < 2 }) { ^nil };
        client = clients[msg[1].asString];
        if(client.isNil or: { client.sourceIP != addr.ip.asString }) { ^nil };
        ^client;
    }

    requestKey { |client, requestID|
        ^client.clientID ++ ":" ++ requestID.asString;
    }

    snapshotKey { |client, snapshotID|
        ^client.clientID ++ ":" ++ snapshotID.asString;
    }

    resendCached { |client, requestID|
        var messages;

        messages = requestCache[this.requestKey(client, requestID)];
        if(messages.isNil) { ^false };
        messages.do { |message| client.address.sendMsg(*message) };
        ^true;
    }

    resultMessage { |client, requestID, ok, action, scoreID, revision, code, detail|
        ^[
            '/awb/timeline/result',
            client.clientID,
            requestID.asString,
            if(ok) { 1 } { 0 },
            action.asString,
            scoreID.asString,
            revision.asInteger,
            code.asString,
            detail.asString
        ];
    }

    cacheAndSend { |client, requestID, messages|
        var key, oldest;

        key = this.requestKey(client, requestID);
        requestCache[key] = messages;
        requestOrder.add(key);
        while { requestOrder.size > maxCachedRequests } {
            oldest = requestOrder.removeAt(0);
            requestCache.removeAt(oldest);
        };
        messages.do { |message| client.address.sendMsg(*message) };
    }

    sendResult { |client, requestID, ok, action, scoreID, revision, code, detail|
        var message;

        message = this.resultMessage(
            client, requestID, ok, action, scoreID, revision, code, detail
        );
        this.cacheAndSend(client, requestID, [message]);
    }

    attachPlayer { |scoreID, player|
        var callback;

        callback = { |changedPlayer, what, data|
            this.playerChanged(changedPlayer, what, data);
        };
        playerCallbacks[scoreID] = callback;
        player.addDependant(callback);
    }

    playerChanged { |player, what, data|
        switch(what,
            \transportChanged, { this.broadcastTransport(player) },
            \scoreEntryScheduled, { this.broadcastRealization(player, \scheduled, data) },
            \scoreRealizationReleased, {
                this.broadcastRuntimeRealization(player, \released, data.event,
                    (data.targetNodeID ? -1).asInteger)
            },
            \scoreReplaced, { this.broadcastTransport(player) }
        );
    }

    nodeManagerChanged { |action, data|
        var player, event;

        if(data.isKindOf(Dictionary).not) { ^this };
        player = data[\streamPlayer];
        event = data[\event];
        if(player.isKindOf(PScoreTimelinePlayer).not or: { event.isNil }) {
            ^this;
        };

        switch(action,
            \streamEventStarted, {
                this.broadcastRuntimeRealization(player, \started, event);
            },
            \scoreRealizationEnded, {
                this.broadcastRuntimeRealization(player, \ended, event);
            }
        );
    }

    interestedClientsDo { |scoreID, function|
        clients.values.do { |client|
            if(client.scores.includes(scoreID.asString)) {
                function.value(client);
            };
        };
    }

    broadcastTransport { |player|
        this.interestedClientsDo(player.scoreID, { |client|
            this.sendTransport(client, player);
        });
    }

    sendTransport { |client, player|
        var anchor;

        anchor = player.transportAnchor;
        client.address.sendMsg(
            '/awb/timeline/transport',
            client.clientID,
            anchor[\scoreID],
            anchor[\revision],
            (anchor[\runID] ? "").asString,
            anchor[\state].asString,
            anchor[\scorePosition].asFloat,
            anchor[\hostMonotonicTime].asFloat,
            anchor[\rate].asFloat,
            anchor[\currentIndex] ? -1,
            anchor[\clockClass].asString,
            anchor[\scheduledStartHostTime] ? -1.0,
            anchor[\executionGeneration] ? 0,
            anchor[\committedFrontier] ? -1.0
        );
    }

    broadcastRealization { |player, state, data|
        this.interestedClientsDo(player.scoreID, { |client|
            client.address.sendMsg(
                '/awb/timeline/realization',
                client.clientID,
                data.scoreID.asString,
                data.revision.asInteger,
                (data.runID ? "").asString,
                data.entryID.asString,
                data.realizationID.asString,
                state.asString,
                data.scoreIndex.asInteger,
                data.scoreTime.asFloat,
                0,
                data.executionGeneration ? 0
            );
        });
    }

    broadcastRuntimeRealization { |player, state, event, targetNodeID = -1|
        var realizationID, nodeIDs, voiceStates, message;

        realizationID = event[\__scoreRealizationID];
        if(realizationID.isNil) { ^this };
        nodeIDs = if(state == \started) {
            (event[\id] ? []).asArray.copy
        } {
            realizationNodes[realizationID] ? (event[\id] ? []).asArray.copy
        };
        if(state == \started) {
            realizationNodes[realizationID] = nodeIDs.copy;
            realizationStates[realizationID.asString] = state;
            voiceStates = IdentityDictionary.new;
            nodeIDs.do { |nodeID| voiceStates[nodeID] = state };
            realizationVoiceStates[realizationID.asString] = voiceStates;
        } {
            if(state == \ended) {
                realizationNodes.removeAt(realizationID);
                realizationStates.removeAt(realizationID.asString);
                realizationVoiceStates.removeAt(realizationID.asString);
            } {
                voiceStates = realizationVoiceStates[realizationID.asString]
                    ? IdentityDictionary.new;
                if(targetNodeID.asInteger >= 0) {
                    voiceStates[targetNodeID.asInteger] = state;
                } {
                    realizationStates[realizationID.asString] = state;
                    nodeIDs.do { |nodeID| voiceStates[nodeID] = state };
                };
                realizationVoiceStates[realizationID.asString] = voiceStates;
            };
        };
        voiceStates = realizationVoiceStates[realizationID.asString]
            ? IdentityDictionary.new;

        this.interestedClientsDo(player.scoreID, { |client|
            message = [
                '/awb/timeline/realization',
                client.clientID,
                event[\__scoreID].asString,
                event[\__scoreRevision].asInteger,
                event[\__scoreRunID].asString,
                event[\__scoreEntryID].asString,
                realizationID.asString,
                state.asString,
                event[\__scoreIndex].asInteger,
                event[\__scoreTime].asFloat,
                nodeIDs.size
            ] ++ nodeIDs ++ nodeIDs.collect { |nodeID|
                (voiceStates[nodeID] ? state).asString
            } ++ [event[\__scoreExecutionGeneration] ? 0];
            client.address.sendMsg(*message);
        });
    }

    fieldComponentCount { |defName|
        switch(defName.asSymbol,
            \fieldBasic, { ^2 },
            \substrate, { ^2 },
            \substrate2, { ^3 }
        );
        ^nil;
    }

    fieldObserverAvailable { |defName|
        var desc;

        desc = SynthDescLib.global.at(defName.asDefName);
        if(desc.isNil) { ^false };
        ^desc.controls.any { |control| control.name.asSymbol == \fieldObserverID };
    }

    fieldNodeSpecs { |player, requestedNodeIDs|
        var requested, specs;

        requested = requestedNodeIDs.collect(_.asInteger).asSet;
        specs = List.new;
        player.currentStreamEvents.do { |event|
            var defName, componentCount;
            defName = event[\instrument] ? event[\def];
            componentCount = this.fieldComponentCount(defName);
            (event[\id] ? []).asArray.do { |nodeID|
                if(requested.includes(nodeID.asInteger) and: { componentCount.notNil }) {
                    specs.add((
                        nodeID: nodeID.asInteger,
                        defName: defName.asSymbol,
                        server: event[\server] ? Server.default,
                        componentCount: componentCount
                    ));
                };
            };
        };
        ^specs.asArray;
    }

    nextFieldRequestID {
        fieldRequestSerial = (fieldRequestSerial % 8000000) + 1;
        while { fieldRequests[fieldRequestSerial].notNil } {
            fieldRequestSerial = (fieldRequestSerial % 8000000) + 1;
        };
        ^fieldRequestSerial;
    }

    sendFieldResult { |client, requestID, ok, code, detail, observationHostTime = -1, expected = 0|
        client.address.sendMsg(
            '/awb/field/result', client.clientID, requestID.asString,
            if(ok) { 1 } { 0 }, code.asString, detail.asString,
            observationHostTime.asFloat, expected.asInteger
        );
    }

    handleFieldObserve { |msg, addr|
        var client, requestID, scoreID, revision, runID, nodeCount, nodeIDs;
        var player, specs, unavailable, server, lookahead, observationHostTime;
        var serverRequestID, messages, expected;

        client = this.authorizedClient(msg, addr);
        if(client.isNil or: { msg.size < 7 }) { ^this };
        requestID = msg[2].asString;
        scoreID = msg[3].asString;
        revision = msg[4].asInteger;
        runID = msg[5].asString;
        nodeCount = msg[6].asInteger;
        if(nodeCount <= 0 or: { nodeCount > 256 } or: { msg.size != (7 + nodeCount) }) {
            this.sendFieldResult(client, requestID, false, \invalidNodes, nodeCount);
            ^this;
        };
        player = players[scoreID];
        if(player.isNil or: { player.revision != revision }
            or: { player.runID.asString != runID }) {
            this.sendFieldResult(client, requestID, false, \staleRun, runID);
            ^this;
        };
        nodeIDs = msg.copyRange(7, msg.size - 1).collect(_.asInteger);
        specs = this.fieldNodeSpecs(player, nodeIDs);
        if(specs.size != nodeIDs.asSet.size) {
            this.sendFieldResult(client, requestID, false, \unknownNodes, nodeIDs.asString);
            ^this;
        };
        unavailable = specs.detect { |spec| this.fieldObserverAvailable(spec[\defName]).not };
        if(unavailable.notNil) {
            this.sendFieldResult(client, requestID, false, \observerUnavailable,
                unavailable[\defName].asString);
            ^this;
        };

        server = specs.first[\server];
        if(specs.any { |spec| spec[\server] !== server }) {
            this.sendFieldResult(client, requestID, false, \multipleServers, scoreID);
            ^this;
        };
        if(server.serverRunning.not) {
            this.sendFieldResult(client, requestID, false, \serverUnavailable, server.name);
            ^this;
        };
        serverRequestID = this.nextFieldRequestID;
        lookahead = (server.latency ? 0.2).asFloat.max(0.05);
        observationHostTime = Main.elapsedTime + lookahead;
        expected = specs.sum { |spec| spec[\componentCount] };
        fieldRequests[serverRequestID] = (
            client: client, clientRequestID: requestID,
            scoreID: scoreID, revision: revision, runID: runID,
            observationHostTime: observationHostTime,
            specs: specs, expected: expected, replies: Dictionary.new
        );
        messages = specs.collect { |spec|
            ['/n_set', spec[\nodeID],
                \fieldObserverID, spec[\nodeID],
                \fieldRequestID, serverRequestID,
                \t_fieldRequest, 1]
        };
        server.sendBundle(lookahead, *messages);
        this.sendFieldResult(client, requestID, true, \scheduled,
            serverRequestID, observationHostTime, expected);
        AppClock.sched(lookahead + 0.5, {
            var pending;
            pending = fieldRequests.removeAt(serverRequestID);
            if(pending.notNil) {
                this.sendFieldResult(pending[\client], pending[\clientRequestID],
                    false, \timeout, pending[\replies].size,
                    pending[\observationHostTime], pending[\expected]);
            };
            nil;
        });
        ^this;
    }

    handleFieldPhase { |msg, addr|
        var serverRequestID, pending, nodeID, componentIndex, spec, key;

        if(msg.size < 9 or: { addr.port != Server.default.addr.port }) { ^this };
        nodeID = msg[1].asInteger;
        serverRequestID = msg[3].asInteger;
        componentIndex = msg[4].asInteger;
        pending = fieldRequests[serverRequestID];
        if(pending.isNil) { ^this };
        spec = pending[\specs].detect { |item| item[\nodeID].asInteger == nodeID };
        if(spec.isNil or: { componentIndex < 0 }
            or: { componentIndex >= spec[\componentCount] }) { ^this };
        key = nodeID.asString ++ ":" ++ componentIndex.asString;
        pending[\replies][key] = msg.copy;
        if(pending[\replies].size == pending[\expected]) {
            fieldRequests.removeAt(serverRequestID);
            this.sendFieldSnapshot(pending);
        };
        ^this;
    }

    sendFieldSnapshot { |pending|
        var ordered, reference, referencePhase, messages;

        ordered = List.new;
        pending[\specs].do { |spec|
            spec[\componentCount].do { |componentIndex|
                ordered.add(pending[\replies][
                    spec[\nodeID].asString ++ ":" ++ componentIndex.asString
                ]);
            };
        };
        ordered = ordered.asArray;
        if(ordered.any(_.isNil)) {
            this.sendFieldResult(pending[\client], pending[\clientRequestID],
                false, \incomplete, ordered.count(_.notNil),
                pending[\observationHostTime], pending[\expected]);
            ^this;
        };
        reference = ordered.first;
        referencePhase = reference[6].asFloat;
        messages = ordered.collect { |reply|
            [
                '/awb/field/snapshot/component',
                pending[\client].clientID, pending[\clientRequestID],
                reply[1].asInteger, reply[4].asInteger,
                reply[5].asFloat,
                (reply[6].asFloat - referencePhase).wrap(-pi, pi),
                reply[7].asFloat, reply[8].asInteger
            ]
        };
        pending[\client].address.sendMsg(
            '/awb/field/snapshot/begin',
            pending[\client].clientID, pending[\clientRequestID],
            pending[\scoreID], pending[\revision], pending[\runID],
            pending[\observationHostTime],
            reference[1].asInteger, reference[4].asInteger,
            reference[5].asFloat, pending[\expected]
        );
        messages.do { |message| pending[\client].address.sendMsg(*message) };
        pending[\client].address.sendMsg(
            '/awb/field/snapshot/end',
            pending[\client].clientID, pending[\clientRequestID], pending[\expected]
        );
        ^this;
    }
}
