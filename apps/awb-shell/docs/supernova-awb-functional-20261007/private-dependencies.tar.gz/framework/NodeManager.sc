/*
NodeManager - Universal Sound Object Tracking System
==================================================

Universal coordinator and GUI interface for all sound-making objects in SuperCollider.
Replaces Playlist.sc with comprehensive tracking, observer notifications, and hierarchical view.

Architecture:
- Universal truth source for "what's making sound"
- Event-driven with observer pattern (no polling)
- Distributed responsibility: P* self-manage, raw objects actively tracked
- Hierarchical view for interactive control

Integration:
- Absorbs Playlist.sc functionality with proven OSC monitoring
- P* family auto-registration
- EventPreset self-tracking integration
- Tool integration support
*/

NodeManager {
    classvar <instance, <enabled, <activationPolicy;
    classvar <streamContainers, <orphanedEventsContainer, <orphanedNodesContainer;
    var <registry, <watchedEntries, <observers, <oscResponders, <hierarchyCache;
    var <streamEventSerial;
    var cmdPeriodAction;

    *initClass {
        enabled = true;
        activationPolicy = \always;
        instance = NodeManager.new;
        streamContainers = Dictionary.new;

        // Create real orphan container objects
        orphanedEventsContainer = VirtualOrphanContainer(\event, "Orphaned Events");
        orphanedNodesContainer = VirtualOrphanContainer(\node, "Orphaned Nodes");

        // Register orphan containers through standard flow
        instance.register(orphanedEventsContainer, \container, (
            name: "Orphaned Events",
            isOrphanContainer: true
        ));
        instance.register(orphanedNodesContainer, \container, (
            name: "Orphaned Nodes",
            isOrphanContainer: true
        ));

        // Store in streamContainers dictionary
        streamContainers[\orphanedEvents] = orphanedEventsContainer;
        streamContainers[\orphanedNodes] = orphanedNodesContainer;
    }

    *new {
        ^super.new.init;
    }

    init {
        registry = IdentityDictionary.new;
        watchedEntries = IdentityDictionary.new;
        observers = Set.new;
        oscResponders = [];
        hierarchyCache = nil;
        streamEventSerial = 0;

        this.installCmdPeriodAction;
    }

    installCmdPeriodAction {
        if(cmdPeriodAction.notNil) { ^this };
        cmdPeriodAction = {
            "NodeManager: Cmd+Period detected - cleaning up all entries".postln;
            watchedEntries.keysValuesDo({ |object, entry|
                entry.active = false;
            });
            this.removeFinished;
            this.notifyObservers(\cmdPeriodCleanup, registry.size);
        };
        CmdPeriod.add(cmdPeriodAction);
        ^this;
    }

    removeCmdPeriodAction {
        if(cmdPeriodAction.notNil) {
            CmdPeriod.remove(cmdPeriodAction);
            cmdPeriodAction = nil;
        };
        ^this;
    }

    *enable {
        if(enabled) { ^true };
        enabled = true;
        instance.installCmdPeriodAction;
        instance.restoreBaseContainers;
        instance.notifyObservers(\enabled, nil);
        "NodeManager: enabled".postln;
        ^true;
    }

    *ensureEnabled {
        if(enabled) { ^true };
        if(activationPolicy == \manual) { ^false };
        ^this.enable;
    }

    *activationPolicy_ { |policy|
        policy = policy.asSymbol;
        if([\always, \whenNeeded, \manual].includes(policy).not) {
            Error("NodeManager policy must be always, whenNeeded or manual").throw;
        };
        activationPolicy = policy;
        if(policy == \always) { this.enable };
        ^activationPolicy;
    }

    *disable {
        var bridgeClass;
        if(enabled.not) { ^false };
        bridgeClass = \NodeManagerOSCBridge.asClass;
        if(bridgeClass.notNil and: { bridgeClass.default.notNil }) {
            bridgeClass.perform(\stop);
        };
        instance.deactivate;
        enabled = false;
        "NodeManager: disabled (sound was left untouched)".postln;
        ^false;
    }

    *isEnabled {
        ^enabled == true;
    }

    deactivate {
        this.notifyObservers(\disabled, nil);
        watchedEntries.values.copy.do { |entry|
            this.cleanupOSCResponders(entry);
        };
        streamContainers.values.do { |container|
            if(container.respondsTo(\children)) {
                container.children.copy.do { |object| container.remove(object) };
            };
        };
        streamContainers.keys.copy.do { |key|
            if([\orphanedEvents, \orphanedNodes].includes(key).not) {
                streamContainers.removeAt(key);
            };
        };
        registry.clear;
        watchedEntries.clear;
        hierarchyCache = nil;
        this.cleanupAllOSCResponders;
        this.removeCmdPeriodAction;
        ^this;
    }

    restoreBaseContainers {
        if(orphanedEventsContainer.notNil) {
            this.register(orphanedEventsContainer, \container, (
                name: "Orphaned Events", isOrphanContainer: true
            ));
            streamContainers[\orphanedEvents] = orphanedEventsContainer;
        };
        if(orphanedNodesContainer.notNil) {
            this.register(orphanedNodesContainer, \container, (
                name: "Orphaned Nodes", isOrphanContainer: true
            ));
            streamContainers[\orphanedNodes] = orphanedNodesContainer;
        };
        ^this;
    }

    // === CORE REGISTRY METHODS ===

    *register { |object, type, metadata|
        if(enabled.not) { ^nil };
        ^instance.register(object, type, metadata);
    }

    register { |object, type, metadata|
        var entry;

        if(enabled.not) { ^nil };

        if(object.isNil) {
            "NodeManager.register: object is nil".warn;
            ^nil;
        };

        entry = this.watch(object, type, metadata, nil);
        if(entry.owner.notNil and: { entry.owner.trackingEnabled.not }) {
            this.unproject(object);
            ^entry;
        };
        ^this.project(object, type, metadata);
    }

    *watch { |object, type, metadata, owner|
        if(enabled.not) { ^nil };
        ^instance.watch(object, type, metadata, owner);
    }

    // An Event carries \group; a Synth and a Node have .group. Anything else
    // has none, and answers nil rather than a guess.
    prGroupOf { |object|
        var group;
        group = case
            { object.isKindOf(Event) } { object[\group] }
            { object.respondsTo(\group) } { object.tryPerform(\group) }
            { nil };
        // Groups are held as their node id: the object may be freed, and an
        // id still identifies which group it WAS in.
        ^group !? { |g| if(g.respondsTo(\nodeID)) { g.nodeID } { g } };
    }

    watch { |object, type, metadata, owner|
        var entry, incomingMetadata;

        if(enabled.not) { ^nil };
        if(object.isNil) { ^nil };
        incomingMetadata = metadata ? ();
        entry = watchedEntries[object];

        if(entry.notNil) {
            entry.type = type ? entry.type;
            entry.metadata.putAll(incomingMetadata);
            entry.active = true;
            if(owner.notNil) { entry.owner = owner };
            ^entry;
        };

        incomingMetadata = incomingMetadata.copy;
        // The server group this object is in, captured once at registration
        // rather than asked for later - by the time anything wants it the
        // object may be gone. Only filled if the caller did not supply it.
        //
        // This is the one piece of real server architecture the registry was
        // missing: a node belongs to a group, and grouping is how this system
        // is actually structured on the server side.
        incomingMetadata[\group] = incomingMetadata[\group] ?? {
            this.prGroupOf(object);
        };

        entry = (
            object: object,
            type: type ? \unknown,
            startTime: Date.getDate,
            metadata: incomingMetadata,
            owner: owner,
            active: true,
            projected: false,
            lifecycleReported: false,
            monitor: nil
        );
        watchedEntries[object] = entry;
        this.setupCleanup(entry);
        ^entry;
    }

    *project { |object, type, metadata|
        if(enabled.not) { ^nil };
        ^instance.project(object, type, metadata);
    }

    project { |object, type, metadata|
        var entry, targetContainers, wasProjected;

        if(enabled.not) { ^nil };
        entry = this.watch(object, type, metadata, nil);
        if(entry.isNil) { ^nil };
        wasProjected = entry.projected == true;
        entry.type = type ? entry.type;
        entry.metadata.putAll(metadata ? ());
        entry.projected = true;
        registry[object] = entry;
        targetContainers = this.determineStreams(object, entry.type, entry.metadata);
        targetContainers.do { |container| container.add(object) };
        hierarchyCache = nil;
        this.notifyObservers(if(wasProjected) { \updated } { \registered }, entry);
        if(wasProjected.not) {
            ("NodeManager: Projected " ++ entry.type ++ " | Total: " ++ registry.size).postln;
        };
        ^entry;
    }

    *unproject { |object|
        ^instance.unproject(object);
    }

    unproject { |object|
        var entry;

        entry = registry[object];
        if(entry.notNil) {
            streamContainers.do { |container| container.remove(object) };
            registry.removeAt(object);
            entry.projected = false;
            hierarchyCache = nil;
            this.notifyObservers(\unregistered, entry);
            ("NodeManager: Unprojected " ++ entry.type ++ " | Remaining: "
                ++ registry.size).postln;
        };
        ^entry;
    }

    *forget { |object|
        ^instance.forget(object);
    }

    forget { |object|
        var entry;

        entry = watchedEntries[object];
        if(entry.notNil) {
            this.unproject(object);
            this.cleanupOSCResponders(entry);
            watchedEntries.removeAt(object);
        };
        ^entry;
    }

    *isWatched { |object|
        ^instance.isWatched(object);
    }

    isWatched { |object|
        ^watchedEntries[object].notNil;
    }

    *watchCountFor { |object|
        ^instance.watchCountFor(object);
    }

    watchCountFor { |object|
        ^if(watchedEntries[object].notNil) { 1 } { 0 };
    }

    *entryFor { |object|
        ^instance.entryFor(object);
    }

    entryFor { |object|
        ^watchedEntries[object];
    }

    *eventsForStreamPlayer { |player|
        if(enabled.not) { ^[] };
        ^instance.eventsForStreamPlayer(player);
    }

    eventsForStreamPlayer { |player|
        var entries;
        entries = watchedEntries.values.select({ |entry|
            entry.active == true and: {
                entry.metadata.notNil and: {
                    entry.metadata.streamPlayer === player
                }
            }
        });
        entries = entries.sort({ |a, b|
            (a.metadata.streamEventSerial ? 0) < (b.metadata.streamEventSerial ? 0)
        });
        ^entries.collect(_.object);
    }

    trackStreamEvent { |player, event, container|
        var metadata;
        if(enabled.not or: { event.isNil }) { ^nil };
        streamEventSerial = streamEventSerial + 1;
        metadata = (
            streamPlayer: player,
            streamContainer: container ? player,
            streamEventSerial: streamEventSerial,
            nodeIDs: event[\id].asArray,
            server: event[\server] ? Server.default,
            instrument: event[\instrument],
            defName: event[\instrument]
        );
        ^this.register(event, \streamEvent, metadata);
    }

    finishTrackedPlayerIfComplete { |player|
        var playerEntry;
        playerEntry = watchedEntries[player];
        if(playerEntry.notNil and: {
            playerEntry.metadata.sourceEnded == true and: {
                this.eventsForStreamPlayer(player).isEmpty
            }
        }) {
            playerEntry.active = false;
        };
        ^playerEntry;
    }

    *unregister { |object|
        ^instance.unregister(object);
    }

    unregister { |object|
        ^this.forget(object);
    }

    // === STREAM CONTAINER MANAGEMENT ===

    determineStreams { |object, type, metadata|
        var containers, presetName, toolSource, toolInstance, synthDefName, isNodeObject;
        containers = IdentitySet.new;
        metadata = metadata ? ();

        // Don't categorize container objects themselves
        if(type == \container) {
            ^containers.asArray;
        };

        // Don't categorize stream player objects themselves - they are containers, not children
        if(type == \streamPlayer or: { type == \EventStreamPlayerWithTracking }) {
            ^containers.asArray;
        };

        // Provenance is additive: the same live object can be found through its
        // SynthDef, its spawning tool and its source preset without changing the
        // scsynth group tree or duplicating lifecycle ownership.
        presetName = metadata.presetName;
        toolSource = metadata.toolSource;
        toolInstance = metadata.toolInstance;
        synthDefName = metadata.defName;

        if(object.isKindOf(Event)) {
            presetName = object[\__preset] ? presetName;
            toolSource = object[\__toolSource] ? toolSource;
            toolInstance = object[\__toolInstance] ? toolInstance;
            synthDefName = object[\instrument] ? synthDefName;
        };

        if(presetName.notNil) {
            containers = containers.add(this.getOrCreatePresetContainer(presetName));
        };
        if(toolSource.notNil) {
            containers = containers.add(this.getOrCreateToolSourceContainer(toolSource));
        };
        if(toolSource.notNil and: { toolInstance.notNil }) {
            containers = containers.add(
                this.getOrCreateToolInstanceContainer(toolSource, toolInstance)
            );
        };
        if(synthDefName.notNil) {
            containers = containers.add(this.getOrCreateSynthDefContainer(synthDefName));
        };

        if(containers.isEmpty) {
            isNodeObject = [\synth, \tempSynth, \rawNode].includes(type)
                or: { object.isKindOf(Node) };
            containers = containers.add(this.getOrCreateOrphanContainer(
                if(isNodeObject) { \node } { \event }
            ));
        };

        ^containers.asArray;
    }

    *containersFor { |object|
        ^instance.containersFor(object);
    }

    containersFor { |object|
        var containers;
        containers = IdentitySet.new;
        streamContainers.do { |container|
            if(container.children.includes(object)) {
                containers = containers.add(container);
            };
        };
        ^containers.asArray;
    }

    *getOrphanedEvents {
        ^if(orphanedEventsContainer.notNil, { orphanedEventsContainer.children }, { [] });
    }

    *getOrphanedNodes {
        ^if(orphanedNodesContainer.notNil, { orphanedNodesContainer.children }, { [] });
    }

    *getStreamContainers {
        ^streamContainers;
    }

    *getOrCreateToolSourceContainer { |toolSource|
        ^instance.getOrCreateToolSourceContainer(toolSource);
    }

    getOrCreateToolSourceContainer { |toolSource|
        var containerKey, container;

        containerKey = ("toolSource_" ++ toolSource).asSymbol;
        container = streamContainers[containerKey];

        if(container.isNil) {
            // Create new tool source container
            container = VirtualOrphanContainer(\toolEvent, "Tool: " ++ toolSource);

            // Register the container itself
            this.register(container, \container, (
                name: "Tool: " ++ toolSource,
                toolSource: toolSource,
                isToolContainer: true
            ));

            // Store in streamContainers dictionary
            streamContainers[containerKey] = container;

            ("NodeManager: Created tool source container for: " ++ toolSource).postln;
        };

        ^container;
    }

    *getOrCreateToolInstanceContainer { |toolSource, toolInstance|
        ^instance.getOrCreateToolInstanceContainer(toolSource, toolInstance);
    }

    getOrCreateToolInstanceContainer { |toolSource, toolInstance|
        var containerKey, container, instanceString;

        instanceString = toolInstance.asString;
        containerKey = ("toolInstance_" ++ toolSource ++ "_" ++ instanceString).asSymbol;
        container = streamContainers[containerKey];

        if(container.isNil) {
            container = VirtualOrphanContainer(
                \toolInstance,
                "Tool Instance: " ++ toolSource ++ " [" ++ instanceString ++ "]"
            );

            this.register(container, \container, (
                name: container.name,
                toolSource: toolSource,
                toolInstance: instanceString,
                isToolInstanceContainer: true
            ));

            streamContainers[containerKey] = container;
            ("NodeManager: Created tool instance container for: "
                ++ toolSource ++ " [" ++ instanceString ++ "]").postln;
        };

        ^container;
    }

    *getOrCreateSynthDefContainer { |synthDefName|
        ^instance.getOrCreateSynthDefContainer(synthDefName);
    }

    getOrCreateSynthDefContainer { |synthDefName|
        var containerKey, container;

        containerKey = ("synthDef_" ++ synthDefName).asSymbol;
        container = streamContainers[containerKey];

        if(container.isNil) {
            // Create new SynthDef container
            container = VirtualOrphanContainer(\synth, "SynthDef: " ++ synthDefName);

            // Register the container itself
            this.register(container, \container, (
                name: "SynthDef: " ++ synthDefName,
                synthDefName: synthDefName,
                isSynthDefContainer: true
            ));

            // Store in streamContainers dictionary
            streamContainers[containerKey] = container;

            ("NodeManager: Created SynthDef container for: " ++ synthDefName).postln;
        };

        ^container;
    }

    *getOrCreatePresetContainer { |presetName|
        ^instance.getOrCreatePresetContainer(presetName);
    }

    *getOrCreateOrphanContainer { |orphanType|
        ^instance.getOrCreateOrphanContainer(orphanType);
    }

    getOrCreatePresetContainer { |presetName|
        var containerKey, container;

        containerKey = ("preset_" ++ presetName).asSymbol;
        container = streamContainers[containerKey];

        if(container.isNil) {
            // Create new preset container
            container = VirtualOrphanContainer(\event, "Preset: " ++ presetName);

            // Register the container itself
            this.register(container, \container, (
                name: "Preset: " ++ presetName,
                presetName: presetName,
                isPresetContainer: true
            ));

            // Store in streamContainers dictionary
            streamContainers[containerKey] = container;

            ("NodeManager: Created preset container for: " ++ presetName).postln;
        };

        ^container;
    }

    getOrCreateOrphanContainer { |orphanType|
        var containerKey, container, displayName;

        containerKey = case
        { orphanType == \event } { \orphanedEvents }
        { orphanType == \node } { \orphanedNodes }
        { ("orphaned_" ++ orphanType).asSymbol };
        container = streamContainers[containerKey];

        if(container.isNil) {
            // Create appropriate orphan container name
            displayName = case
            { orphanType == \event } { "Orphaned Events" }
            { orphanType == \node } { "Orphaned Nodes" }
            { "Orphaned " ++ orphanType.asString.capitalizeFirst };

            // Create new orphan container
            container = VirtualOrphanContainer(orphanType, displayName);

            // Register the container itself
            this.register(container, \container, (
                name: displayName,
                isOrphanContainer: true
            ));

            // Store in streamContainers dictionary
            streamContainers[containerKey] = container;

            if(orphanType == \event) {
                orphanedEventsContainer = container;
            };
            if(orphanType == \node) {
                orphanedNodesContainer = container;
            };

            ("NodeManager: Created orphan container for: " ++ orphanType).postln;
        };

        ^container;
    }

    // === AUTOMATIC CLEANUP MONITORING (from Playlist.sc) ===

    setupCleanup { |entry|
        var object = entry.object;

        // Containers organize live objects but are not themselves playing objects.
        // Their lifetime is explicit; never infer it from an isPlaying response.
        if(entry.type == \container) {
            ^this;
        };

        // Navigable PStreamPlayers own pause/resume and terminal lifecycle.
        // isPlaying=false means paused as well as finished, so generic polling
        // would incorrectly discard the container at every pause.
        if(object.isKindOf(PStreamPlayer)) {
            this.setupPStreamPlayerMonitoring(entry);
            ^this;
        };

        // Handle different object types with proven patterns from Playlist.sc
        switch(object.class.name,
            \Synth, {
                this.setupSynthOSCMonitoring(entry);
            },
            \Event, {
                this.setupEventOSCMonitoring(entry);
            },
            \EventStreamPlayer, {
                this.setupPatternPolling(entry);
            },
            \EventStreamPlayerWithTracking, {
                // Enhanced tracking - use observer pattern
                this.setupTrackedPlayerMonitoring(entry);
            },
            \Task, {
                this.setupPatternPolling(entry);
            },
            // Generic fallback
            {
                if(object.respondsTo(\isPlaying)) {
                    this.setupPatternPolling(entry);
                } {
                    ("Warning: Don't know how to monitor " ++ object.class ++ " for cleanup").warn;
                };
            }
        );
    }

    // OSC monitoring for Event node lifecycle (proven from Playlist.sc)
    setupEventOSCMonitoring { |entry|
        var object, nodeIDs, server, responder, trackedNodes;
        object = entry.object;

        nodeIDs = object[\id];
        server = object[\server] ? Server.default;

        if(nodeIDs.notNil) {
            trackedNodes = nodeIDs.asArray.copy;

            responder = OSCFunc({ |msg|
                var endedNodeID = msg[1];

                if(trackedNodes.includes(endedNodeID)) {
                    trackedNodes.remove(endedNodeID);

                    if(trackedNodes.isEmpty) {
                        var streamPlayer, streamContainer;
                        entry.active = false;
                        object[\isPlaying] = false;

                        streamPlayer = entry.metadata.streamPlayer;
                        streamContainer = entry.metadata.streamContainer ? streamPlayer;
                        if(streamPlayer.notNil) {
                            if(streamPlayer.respondsTo(\trackedEventEnded)) {
                                streamPlayer.trackedEventEnded(object);
                            };
                            this.notifyObservers(\streamEventStopped, (
                                streamPlayer: streamContainer,
                                event: object
                            ));
                            this.finishTrackedPlayerIfComplete(streamPlayer);
                        };

                        this.removeFinished;
                    };
                };
            }, '/n_end', server.addr);

            entry.monitor = responder;
            entry.monitorKind = \osc;
            oscResponders = oscResponders.add(responder);
        };
    }

    // OSC monitoring for Synth node lifecycle (proven from Playlist.sc)
    setupSynthOSCMonitoring { |entry|
        var object, nodeID, server, responder;
        object = entry.object;

        nodeID = object.nodeID;
        server = object.server ? Server.default;

        if(nodeID.notNil) {
            responder = OSCFunc({ |msg|
                var endedNodeID = msg[1];

                if(endedNodeID == nodeID) {
                    entry.active = false;

                    this.removeFinished;
                };
            }, '/n_end', server.addr);

            entry.monitor = responder;
            entry.monitorKind = \osc;
            oscResponders = oscResponders.add(responder);
        };
    }

    // Enhanced monitoring for EventStreamPlayerWithTracking
    setupTrackedPlayerMonitoring { |entry|
        var object, dependant;
        object = entry.object;

        // Use observer pattern for real-time updates
        dependant = { |player, what, event|
            case
            { what == \eventStarted } {
                var streamContainer;
                streamContainer = entry.metadata.streamContainer ? player;
                this.trackStreamEvent(player, event, streamContainer);
                this.notifyObservers(\streamEventStarted, (
                    streamPlayer: streamContainer,
                    event: event
                ));
            }
            { what == \streamEnded } {
                entry.metadata.sourceEnded = true;
                this.finishTrackedPlayerIfComplete(player);
                this.removeFinished;
            }
            { what == \stopped } {
                entry.metadata.sourceEnded = true;
                this.finishTrackedPlayerIfComplete(player);
                this.removeFinished;
            };
        };
        object.addDependant(dependant);
        entry.monitor = dependant;
        entry.monitorKind = \dependant;
    }

    setupPStreamPlayerMonitoring { |entry|
        var object, dependant;
        object = entry.object;

        dependant = { |player, what|
            if(what == \fullyFinished) {
                entry.active = false;
                this.removeFinished;
            };
        };
        object.addDependant(dependant);
        entry.monitor = dependant;
        entry.monitorKind = \dependant;
    }

    // Polling for abstract objects (patterns, tasks)
    setupPatternPolling { |entry|
        var object, routine;
        object = entry.object;

        routine = {
            while { object.isPlaying } { 0.1.wait };
            entry.active = false;
            this.removeFinished;
        }.fork;
        entry.monitor = routine;
        entry.monitorKind = \routine;
    }

    // Clean up OSC responders for specific entry
    cleanupOSCResponders { |entry|
        var monitor;

        monitor = entry.monitor;
        if(monitor.notNil) {
            switch(entry.monitorKind,
                \dependant, {
                    try { entry.object.removeDependant(monitor) } { |error| nil };
                },
                \routine, {
                    if(monitor !== thisThread) {
                        try { monitor.stop } { |error| nil };
                    };
                },
                {
                    try { monitor.free } { |error| nil };
                    oscResponders.remove(monitor);
                }
            );
            entry.monitor = nil;
            entry.monitorKind = nil;
        };
    }

    // Remove finished items from registry
    removeFinished {
        var beforeSize, afterSize, finishedEntries;
        beforeSize = registry.size;

        // Trust the active flag set by lifecycle callbacks, then remove every
        // projection of the object as well as its authoritative registry entry.
        finishedEntries = watchedEntries.values.select({ |entry|
            entry.active != true;
        });
        finishedEntries.do { |entry|
            if(entry.lifecycleReported != true) {
                entry.lifecycleReported = true;
                if(entry.owner.notNil) {
                    entry.owner.ownedObjectEnded(entry.object, \ended, \nodeManager);
                };
            };
            this.forget(entry.object);
        };

        afterSize = registry.size;

        if(beforeSize != afterSize) {
            // Invalidate hierarchy cache
            hierarchyCache = nil;

            this.notifyObservers(\cleaned, afterSize);

            ("NodeManager: Cleaned up " ++ (beforeSize - afterSize) ++ " finished items | Remaining: " ++ afterSize).postln;
        };
    }

    // === FILTERING AND QUERY API ===

    *filter { |criteria|
        ^instance.filter(criteria);
    }

    filter { |criteria|
        var results = registry.values;

        if(criteria.isKindOf(Array)) {
            criteria.do { |criterion|
                results = this.applyCriterion(results, criterion);
            };
        } {
            results = this.applyCriterion(results, criteria);
        };

        ^results;
    }

    applyCriterion { |entryList, criterion|
        if(criterion.isKindOf(Association)) {
            var key, value;
            key = criterion.key;
            value = criterion.value;

            case
            { key == \type } {
                ^entryList.select { |entry| entry.type == value };
            }
            { key == \preset } {
                ^entryList.select { |entry|
                    entry.metadata.preset == value;
                };
            }
            { key == \tool } {
                // The projection writes toolSource and toolInstance, never
                // `tool` - so this read metadata.tool and silently matched
                // NOTHING. A criterion that returns an empty list looks like
                // a true answer about the world rather than a wrong question,
                // which is why it went unnoticed.
                //
                // Matches either, so \tool -> \toneDiamond finds everything
                // that tool made, and \tool -> "toneDiamond:1001" narrows to
                // one instance.
                ^entryList.select { |entry|
                    var metadata;
                    metadata = entry.metadata ? ();
                    (metadata[\toolSource].asString == value.asString)
                        or: { metadata[\toolInstance].asString == value.asString }
                        or: { metadata[\tool].asString == value.asString };
                };
            }
            { key == \group } {
                ^entryList.select { |entry|
                    (entry.metadata ? ())[\group].asString == value.asString;
                };
            }
            { key == \container } {
                // By the container object, or by its name. Containers hold
                // their members in `children`, so membership is asked of the
                // container rather than stored on the entry.
                ^entryList.select { |entry|
                    var container;
                    container = if(value.isKindOf(Symbol) or: { value.isKindOf(String) }) {
                        NodeManager.containerNamed(value);
                    } { value };
                    (container.notNil)
                        and: { (container.tryPerform(\children) ? [])
                            .includes(entry[\object]) };
                };
            }
            {
                ^entryList;
            };
        } {
            // Direct object filter
            if(criterion.isKindOf(EventPreset)) {
                ^entryList.select { |entry|
                    entry.metadata.preset == criterion.name;
                };
            };
        };

        ^entryList;
    }

    *getAll {
        ^instance.getAll;
    }

    getAll {
        this.removeFinished; // Clean up first
        ^registry.values;
    }

    // The containers themselves, rather than everything inside them. There
    // was no way to ask "what containers are there" and then choose one -
    // callers were stuck with getAll and filtered by hand.
    *getActiveContainers {
        ^this.getActive.select { |entry| entry[\type] == \container };
    }

    *containerNamed { |name|
        var entry;
        name = name.asString;
        entry = this.getActiveContainers.detect { |each|
            ((each[\metadata] ? ())[\name].asString == name)
                or: { (each[\metadata] ? ())[\toolInstance].asString == name }
                or: { (each[\metadata] ? ())[\toolSource].asString == name };
        };
        ^entry !? { |e| e[\object] };
    }

    // What is inside one container. Takes the container object, or an entry
    // wrapping one, or its name.
    *entriesIn { |container|
        var object;
        object = case
            { container.isKindOf(Symbol) or: { container.isKindOf(String) } }
                { this.containerNamed(container) }
            { container.isKindOf(Event) and: { container[\object].notNil } }
                { container[\object] }
            { container };
        if(object.isNil) { ^[] };
        ^this.getActive.select { |entry|
            (object.tryPerform(\children) ? []).includes(entry[\object]);
        };
    }

    *getActive {
        ^instance.getActive;
    }

    getActive {
        this.removeFinished;
        ^registry.values.select({ |entry| entry.active == true });
    }

    // === HIERARCHICAL VIEW FOR GUI ===

    *getHierarchicalView {
        ^instance.getHierarchicalView;
    }

    getHierarchicalView {
        var categories, activeEntries, typeGroups;

        if(hierarchyCache.notNil) {
            ^hierarchyCache;
        };

        this.removeFinished;
        activeEntries = this.getActive;
        categories = [];

        // Group by type and create hierarchical structure
        typeGroups = IdentityDictionary.new;
        activeEntries.do({ |entry|
            var type = entry.type;
            if(typeGroups[type].isNil) {
                typeGroups[type] = [];
            };
            typeGroups[type] = typeGroups[type].add(entry);
        });

        typeGroups.keysValuesDo({ |type, entries|
            var categoryName, items;

            categoryName = case
            { type == \streamPlayer } { "Stream Players" }
            { type == \nodePlayer } { "Node Players" }
            { type == \preset } { "Preset Players" }
            { type == \tool } { "Tool Instances" }
            { type == \rawNode } { "Manual Objects" }
            { type == \event } { "Manual Events" }
            { type == \synth } { "Manual Synths" }
            { "Other (" ++ type ++ ")" };

            items = entries.collect({ |entry|
                this.formatHierarchyItem(entry);
            });

            categories = categories.add((
                category: categoryName,
                type: type,
                items: items
            ));
        });

        hierarchyCache = categories;
        ^categories;
    }

    formatHierarchyItem { |entry|
        var object, name, status, nodeIDs, age, children;
        object = entry.object;
        age = Date.getDate.rawSeconds - entry.startTime.rawSeconds;

        // Extract node IDs for display
        nodeIDs = case
        { object.class.name == \Event } { object[\id] }
        { object.class.name == \Synth } { [object.nodeID] }
        { [] };

        // Detect container objects and read their live children
        children = [];
        if(object.respondsTo(\currentStreamEvents)) {
            // PStreamPlayer and similar containers
            var currentEvents = object.currentStreamEvents;
            if(currentEvents.notNil and: { currentEvents.notEmpty }) {
                children = currentEvents.collect({ |event|
                    var childAge = if(event[\startTime].notNil, {
                        Date.getDate.rawSeconds - event[\startTime].rawSeconds;
                    }, { age });

                    (
                        name: "Event(freq:" ++ (event[\freq] ? "?") ++ ")",
                        status: "node:" ++ (event[\id] ? "?") ++ " (" ++ childAge.round(0.1) ++ "s)",
                        nodes: event[\id].asArray,
                        age: childAge,
                        isChild: true,
                        parentEntry: entry
                    );
                });
            };
        } {
            if(object.respondsTo(\playingInstances)) {
                // EventPreset and similar containers with multiple instances
                var instances = object.playingInstances;
                if(instances.notNil and: { instances.notEmpty }) {
                    children = instances.collect({ |instance, index|
                        var childAge = if(instance[\startTime].notNil, {
                            Date.getDate.rawSeconds - instance[\startTime].rawSeconds;
                        }, { age });

                        (
                            name: "Instance " ++ (index + 1) ++ " (freq:" ++ (instance[\freq] ? "?") ++ ")",
                            status: "node:" ++ (instance[\id] ? "?") ++ " (" ++ childAge.round(0.1) ++ "s)",
                            nodes: instance[\id].asArray,
                            age: childAge,
                            isChild: true,
                            parentEntry: entry
                        );
                    });
                };
            };
        };

        // Generate display name with container info
        name = case
        { entry.metadata.preset.notNil } { "Preset: " ++ entry.metadata.preset }
        { entry.metadata.tool.notNil } { "Tool: " ++ entry.metadata.tool }
        { object.class.name.asString.contains("StreamPlayer") or: { object.class.name.asString.contains("SequencePlayer") } } {
            var playerType = object.class.name.asString;
            var positionInfo = "";

            // Add position info for stream players
            if(object.respondsTo(\currentIndex) and: { object.respondsTo(\size) }) {
                var currentIdx = object.currentIndex ? 0;
                var totalSize = object.size;
                if(totalSize.notNil) {
                    positionInfo = " (Position: " ++ currentIdx ++ "/" ++ totalSize ++ ")";
                } {
                    positionInfo = " (Position: " ++ currentIdx ++ ")";
                };
            };

            playerType ++ positionInfo;
        }
        { object.class.name == \Event } { "Event(freq:" ++ (object[\freq] ? "?") ++ ")" }
        { object.class.name == \Synth } { "Synth(" ++ object.defName ++ ")" }
        { object.class.asString };

        // Generate status with child count for containers
        if(children.notEmpty) {
            status = if(entry.active, "active", "finished") ++ " (" ++ age.round(0.1) ++ "s, " ++ children.size ++ " children)";
        } {
            status = if(entry.active, "active", "finished") ++ " (" ++ age.round(0.1) ++ "s)";
        };

        ^(
            name: name,
            status: status,
            nodes: nodeIDs,
            age: age,
            children: children,
            hasChildren: children.notEmpty,
            entry: entry
        );
    }

    // === OBSERVER PATTERN (from Playlist.sc) ===

    *addObserver { |observer|
        instance.addObserver(observer);
    }

    addObserver { |observer|
        observers.add(observer);
    }

    *removeObserver { |observer|
        instance.removeObserver(observer);
    }

    removeObserver { |observer|
        observers.remove(observer);
    }

    *notifyObservers { |action, data|
        instance.notifyObservers(action, data);
    }

    notifyObservers { |action, data|
        // Invalidate hierarchy cache when objects change
        hierarchyCache = nil;

        observers.do({ |observer|
            // Handle both Object method calls and Event function calls
            if(observer.respondsTo(\nodeManagerChanged)) {
                observer.nodeManagerChanged(action, data);
            } {
                // For Events, check if they have the function and call it
                if(observer.isKindOf(Event) and: { observer[\nodeManagerChanged].notNil }) {
                    observer[\nodeManagerChanged].value(action, data);
                };
            };
        });
    }

    // === CONTROL METHODS ===

    *supportsControl { |object, selector|
        ^instance.supportsControl(object, selector);
    }

    supportsControl { |object, selector|
        var method;

        if(object.isNil) { ^false };
        method = object.class.findRespondingMethodFor(selector);
        ^method.notNil and: { method.ownerClass !== Object };
    }

    ownerFor { |object|
        var entry;
        entry = watchedEntries[object];
        ^if(entry.notNil) { entry.owner } { nil };
    }

    *releaseObject { |object, releaseTime|
        ^instance.releaseObject(object, releaseTime);
    }

    releaseObject { |object, releaseTime|
        var released, owner;

        owner = this.ownerFor(object);
        if(owner.notNil) {
            ^owner.requestOwnedAction(object, \release, [releaseTime], \nodeManager);
        };

        if(this.supportsControl(object, \release).not) { ^false };
        released = true;
        try {
            if(releaseTime.isNil) {
                object.release;
            } {
                object.release(releaseTime);
            };
        } { |error|
            released = false;
            ("NodeManager: release failed for %: %"
                .format(object.class.name, error.errorString)).warn;
        };
        ^released;
    }

    *stopObject { |object|
        ^instance.stopObject(object);
    }

    stopObject { |object|
        var stopped, owner;

        owner = this.ownerFor(object);
        if(owner.notNil) {
            ^owner.requestOwnedAction(object, \stop, [], \nodeManager);
        };

        if(this.supportsControl(object, \stop).not) { ^false };
        stopped = true;
        try {
            object.stop;
        } { |error|
            stopped = false;
            ("NodeManager: stop failed for %: %"
                .format(object.class.name, error.errorString)).warn;
        };
        ^stopped;
    }

    *freeObject { |object|
        ^instance.freeObject(object);
    }

    freeObject { |object|
        var freed, owner;

        owner = this.ownerFor(object);
        if(owner.notNil) {
            ^owner.requestOwnedAction(object, \free, [], \nodeManager);
        };

        if(this.supportsControl(object, \free).not) { ^false };
        freed = true;
        try {
            object.free;
        } { |error|
            freed = false;
            ("NodeManager: free failed for %: %"
                .format(object.class.name, error.errorString)).warn;
        };
        ^freed;
    }

    *terminateObject { |object|
        ^instance.terminateObject(object);
    }

    terminateObject { |object|
        var server, nodeIDs, owner;

        owner = this.ownerFor(object);
        if(owner.notNil) {
            ^owner.requestOwnedAction(object, \terminate, [], \nodeManager);
        };

        if(object.isKindOf(Event)) {
            nodeIDs = object[\id];
            if(nodeIDs.notNil) {
                server = object[\server] ? Server.default;
                nodeIDs.asArray.do { |nodeID|
                    server.sendMsg(\n_free, nodeID);
                };
                object[\id] = nil;
                ^true;
            };
        };

        if(object.isKindOf(Node)) {
            ^this.freeObject(object);
        };

        ^this.stopObject(object) or: { this.freeObject(object) };
    }

    *releaseAll { |releaseTime|
        ^instance.releaseAll(releaseTime);
    }

    releaseAll { |releaseTime|
        var entries, released;

        entries = registry.values.select({ |entry| entry.type != \container });
        released = entries.select({ |entry|
            this.releaseObject(entry.object, releaseTime)
        }).size;
        this.notifyObservers(\releaseRequested, (
            requested: entries.size,
            released: released,
            releaseTime: releaseTime
        ));
        ^(requested: entries.size, released: released,
            skipped: entries.size - released);
    }

    *stopAll {
        instance.stopAll;
    }

    stopAll {
        var entries, activeCount;

        entries = registry.values.select({ |entry| entry.type != \container });
        activeCount = entries.size;
        entries.do({ |entry|
            this.stopAndRemove(entry);
        });

        ("NodeManager: Stopped all " ++ activeCount ++ " active items").postln;
    }

    *stopType { |type|
        instance.stopType(type);
    }

    stopType { |type|
        var typeEntries;

        typeEntries = registry.values.select({ |entry|
            entry.type == type and: { entry.type != \container }
        });

        typeEntries.do({ |entry|
            this.stopAndRemove(entry);
        });

        ("NodeManager: Stopped " ++ typeEntries.size ++ " " ++ type ++ " items").postln;
    }

    stopAndRemove { |entry|
        var object, controlled, owner;

        object = entry.object;
        owner = this.ownerFor(object);
        controlled = this.terminateObject(object);

        if(controlled and: { owner.isNil }) {
            this.unregister(object);
        } {
            if(controlled.not) {
                ("NodeManager: no stop/free control for %; keeping it registered"
                    .format(object.class.name)).warn;
            };
        };
        ^controlled;
    }

    *stopAndRemoveObject { |object|
        ^instance.stopAndRemoveObject(object);
    }

    stopAndRemoveObject { |object|
        var entry;
        entry = watchedEntries[object];
        if(entry.isNil) { ^false };
        ^this.stopAndRemove(entry);
    }

    cleanupAllOSCResponders {
        oscResponders.copy.do({ |responder|
            try {
                responder.free;
            } { |error|
                // Responder might already be freed
            };
        });
        oscResponders = [];
    }

    // === STATUS AND DEBUG ===

    *status {
        instance.status;
    }

    status {
        var activeEntries;
        if(enabled.not) {
            "=== NodeManager Status ===".postln;
            ("disabled (policy: " ++ activationPolicy ++ ")").postln;
            ^this;
        };
        this.removeFinished;
        activeEntries = this.getActive;

        ("=== NodeManager Status ===").postln;
        ("Total registered: " ++ registry.size).postln;
        ("Active items: " ++ activeEntries.size).postln;
        ("OSC responders: " ++ oscResponders.size).postln;

        if(activeEntries.size > 0) {
            "Active items:".postln;
            activeEntries.do({ |entry|
                var item = this.formatHierarchyItem(entry);
                ("  " ++ item.name ++ " - " ++ item.status).postln;
            });
        } {
            "  (no active items)".postln;
        };
    }

    *cleanup {
        instance.cleanup;
    }

    cleanup {
        this.removeFinished;
        hierarchyCache = nil;
    }
}

// === UNIVERSAL +NODE EXTENSION FOR RAW OBJECT TRACKING ===

+ Node {
    *new { |server, nodeID|
        var node = super.new(server, nodeID);

        // Auto-register with NodeManager
        NodeManager.register(node, \rawNode, (
            server: server ? Server.default,
            nodeID: nodeID,
            startTime: Date.getDate
        ));

        ^node;
    }
}

// COMMENTED OUT - Synth.new override was breaking synth creation
// Better to use manual registration when needed
//
+ Synth {

		*new { arg defName, args, target, addAction=\addToHead;
		var synth, server, addActionID;
		target = target.asTarget;
		server = target.server;
		addActionID = addActions[addAction];
		synth = this.basicNew(defName, server);

		synth.group = if(addActionID < 2) { target } { target.group };
		server.sendMsg(9, //"s_new"
			defName, synth.nodeID, addActionID, target.nodeID,
			*(args.asOSCArgArray)
		);
		// ^synth

		// *new { |defName, args, target, addAction=\addToHead|
		// var synth = super.new(defName, args, target, addAction);
		this.registerwithNodeManager(synth, defName, args, target, addAction);


^synth;
}

		*newPaused { arg defName, args, target, addAction=\addToHead;
		var synth, server, addActionID;
		target = target.asTarget;
		server = target.server;
		addActionID = addActions[addAction];
		synth = this.basicNew(defName, server);
		synth.group = if(addActionID < 2) { target } { target.group };
		server.sendBundle(nil, [9, defName, synth.nodeID, addActionID, target.nodeID] ++
			args.asOSCArgArray, [12, synth.nodeID, 0]); // "s_new" + "/n_run"
		this.registerwithNodeManager(synth, defName, args, target, addAction);
		^synth
	}

	*replace { arg nodeToReplace, defName, args, sameID=false;
		var synth, server, newNodeID;
		if(sameID) { newNodeID = nodeToReplace.nodeID };
		server = nodeToReplace.server;
		synth = this.basicNew(defName, server, newNodeID);

		server.sendMsg(9, //"s_new"
			defName,
			synth.nodeID,
			4, // addReplace
			nodeToReplace.nodeID,
			*(args.asOSCArgArray)
		);
		// scsynth does not send /n_end for a node displaced by addReplace.
		// Record the language-side transition explicitly.
		NodeManager.unregister(nodeToReplace);
		this.registerwithNodeManager(
			synth,
			defName,
			args,
			target:nil,
			addAction:\replace,
			replacedNodeID:nodeToReplace.nodeID
		);
		^synth
	}

	*registerwithNodeManager { |synth, defName, args, target, addAction, replacedNodeID|
		// Auto-register with NodeManager
		NodeManager.register(synth, \synth, (
			defName: defName,
			args: args,
			target: target,
			addAction: addAction,
			server: synth.server,
			nodeID: synth.nodeID,
			replacedNodeID: replacedNodeID
		));
	}
}

// COMMENTED OUT - Event.play override was breaking playback
// Better to use manual registration or hook into EventPreset system
//
// + Event {
//     play { |clock, protoEvent, quant|
//         var playedEvent = super.play(clock, protoEvent, quant);
//
//         // Auto-register with NodeManager if this event creates nodes
//         if(playedEvent.notNil and: { playedEvent[\id].notNil }) {
//             NodeManager.register(playedEvent, \event, (
//                 freq: playedEvent[\freq],
//                 instrument: playedEvent[\instrument],
//                 dur: playedEvent[\dur],
//                 amp: playedEvent[\amp],
//                 server: playedEvent[\server] ? Server.default,
//                 nodeIDs: playedEvent[\id].asArray
//             ));
//         };
//
//         ^playedEvent;
//     }
// }
