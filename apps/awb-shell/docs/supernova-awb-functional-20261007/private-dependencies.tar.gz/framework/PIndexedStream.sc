/*
PIndexedStream - Event stream with callback system for navigation players
========================================================================

Wrapper around event arrays that provides Stream interface with event callbacks.
Used by PStreamPlayer subclasses to create streams from regenerated event sequences.

Features:
- Standard SuperCollider Stream interface (next, reset)
- Event callback system for performance tracking
- Utility methods for stream inspection
*/

PIndexedStream {
    var <events, <callback, <commitCallback;
    var currentIndex = 0;

    *new { |eventArray, eventCallback, itemCommitCallback|
        ^super.new.init(eventArray, eventCallback, itemCommitCallback);
    }

    init { |eventArray, eventCallback, itemCommitCallback|
        events = eventArray ? [];
        callback = eventCallback;
        commitCallback = itemCommitCallback;
        currentIndex = 0;
    }

    next { |inEvent|
        var event;
        if(currentIndex >= events.size) { ^nil };
        
        event = events[currentIndex];
        // EventStreamPlayer passes its prototype Event into Stream:next.
        // Preserve that context (server, group, clock-related defaults, etc.)
        // while allowing the authored event to override individual fields.
        if(inEvent.notNil) {
            event = inEvent.copy.putAll(event);
        };
        
        // The commit callback sees rests as well. This lets a timeline player
        // advance its committed frontier when a replacement tail begins with
        // an exact gap, without treating the rest as a musical realization.
        if(commitCallback.notNil) {
            commitCallback.value(event, currentIndex);
        };

        // Notify the historical event callback if provided (skip rests).
        if(callback.notNil and: { event[\type] != \rest }) {
            callback.value(event, currentIndex);
        };
        
        currentIndex = currentIndex + 1;
        ^event;
    }

    reset {
        currentIndex = 0;
    }

    // Utility methods
    size { ^events.size }
    isEmpty { ^events.isEmpty }
    
    // Stream protocol
    embedInStream { |stream|
        var event;
        while {
            event = this.next;
            event.notNil
        } {
            stream = event.embedInStream(stream);
        };
        ^stream;
    }
}
