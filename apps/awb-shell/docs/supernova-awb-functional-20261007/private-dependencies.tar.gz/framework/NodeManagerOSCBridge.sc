/*
NodeManagerOSCBridge
====================

Process-local NodeManager state projected as a small OSC protocol for local
Node, Tauri or other adapters. Browser clients are expected to connect to that
adapter over WebSocket; browsers do not speak UDP OSC directly.

The bridge exports normalized values and process-lifetime IDs. It never tries
to serialize or reconstruct arbitrary SuperCollider objects.
*/
NodeManagerOSCBridge {
    classvar <default;
    var <subscribers, <entryIDs, <objectsByEntryID, <responders;
    var <nextEntryID, <sequence, <isRunning, <allowRemote;

    *new { |allowRemote = false|
        ^super.new.init(allowRemote);
    }

    *start { |allowRemote = false|
        if(default.isNil) {
            default = this.new(allowRemote);
        };
        default.start;
        ^default;
    }

    *stop {
        if(default.notNil) {
            default.stop;
            default = nil;
        };
    }

    init { |remoteAllowed|
        subscribers = Dictionary.new;
        entryIDs = IdentityDictionary.new;
        objectsByEntryID = Dictionary.new;
        responders = List.new;
        nextEntryID = 1;
        sequence = 0;
        isRunning = false;
        allowRemote = remoteAllowed;
        ^this;
    }

    start {
        if(isRunning) { ^this };

        NodeManager.addObserver(this);
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleSubscribe(msg, addr);
        }, '/awb/nm/subscribe'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleUnsubscribe(msg, addr);
        }, '/awb/nm/unsubscribe'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleSnapshotRequest(msg, addr);
        }, '/awb/nm/snapshot'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handlePing(msg, addr);
        }, '/awb/nm/ping'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleToolNotification(msg, addr);
        }, '/awb/nm/tool/notify'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleToolAssociation(msg, addr);
        }, '/awb/nm/tool/associate'));

        isRunning = true;
        ^this;
    }

    stop {
        if(isRunning.not) { ^this };

        NodeManager.removeObserver(this);
        responders.do(_.free);
        responders.clear;
        subscribers.clear;
        isRunning = false;
        ^this;
    }

    isAllowedAddress { |addr|
        var ip;

        if(allowRemote) { ^true };
        ip = addr.ip.asString;
        ^ip.beginsWith("127.")
            or: { ip.beginsWith("::1") }
            or: { ip.beginsWith("::ffff:127.") };
    }

    handleSubscribe { |msg, addr|
        var clientID, replyPort, scopeKind, scopeValue, dataMode;
        var deliveryMode, batchWindow, subscriber;

        if(this.isAllowedAddress(addr).not) { ^this };
        if(msg.size < 2) {
            this.sendError(addr, "", "subscribe requires clientID");
            ^this;
        };

        clientID = msg[1].asString;
        replyPort = if(msg.size > 2) { msg[2].asInteger } { addr.port };
        if(replyPort <= 0) { replyPort = addr.port };
        scopeKind = if(msg.size > 3) { msg[3].asString.asSymbol } { \all };
        scopeValue = if(msg.size > 4) { msg[4].asString.asSymbol } { nil };
        dataMode = if(msg.size > 5) { msg[5].asString.asSymbol } { \summary };
        deliveryMode = if(msg.size > 6) { msg[6].asString.asSymbol } { \immediate };
        batchWindow = if(msg.size > 7) { msg[7].asFloat } { 0.016 };

        if([\all, \tool, \preset, \synthDef, \container].includes(scopeKind).not) {
            this.sendError(NetAddr(addr.ip, replyPort), clientID, "unknown scope");
            ^this;
        };
        if([\summary, \values].includes(dataMode).not) {
            this.sendError(NetAddr(addr.ip.asString, replyPort), clientID, "unknown data mode");
            ^this;
        };
        if([\immediate, \bundle, \coalesced].includes(deliveryMode).not) {
            this.sendError(NetAddr(addr.ip.asString, replyPort), clientID, "unknown delivery mode");
            ^this;
        };
        batchWindow = batchWindow.clip(0.001, 1.0);

        subscriber = (
            clientID: clientID,
            address: NetAddr(addr.ip.asString, replyPort),
            sourceIP: addr.ip.asString,
            scopeKind: scopeKind,
            scopeValue: scopeValue,
            dataMode: dataMode,
            deliveryMode: deliveryMode,
            batchWindow: batchWindow,
            visibleIDs: Set.new,
            messageCapture: nil,
            pendingTransactions: Dictionary.new,
            pendingOrder: List.new,
            pendingFromSequence: nil,
            pendingThroughSequence: nil,
            flushScheduled: false
        );
        subscribers[clientID] = subscriber;
        subscriber.address.sendMsg(
            '/awb/nm/subscribed', clientID, 3, dataMode,
            deliveryMode, batchWindow
        );
        this.sendSnapshot(subscriber);
    }

    handleUnsubscribe { |msg, addr|
        var clientID, subscriber;

        if(msg.size < 2) { ^this };
        clientID = msg[1].asString;
        subscriber = this.authorizedSubscriber(clientID, addr);
        if(subscriber.notNil) {
            this.flushSubscriber(subscriber);
            subscriber.address.sendMsg('/awb/nm/unsubscribed', clientID);
            subscribers.removeAt(clientID);
        };
    }

    handleSnapshotRequest { |msg, addr|
        var clientID, subscriber;

        if(msg.size < 2) { ^this };
        clientID = msg[1].asString;
        subscriber = this.authorizedSubscriber(clientID, addr);
        if(subscriber.notNil) {
            this.flushSubscriber(subscriber);
            this.sendSnapshot(subscriber);
        };
    }

    handlePing { |msg, addr|
        var clientID, nonce, subscriber;

        if(msg.size < 2) { ^this };
        clientID = msg[1].asString;
        nonce = if(msg.size > 2) { msg[2] } { 0 };
        subscriber = this.authorizedSubscriber(clientID, addr);
        if(subscriber.notNil) {
            subscriber.address.sendMsg('/awb/nm/pong', clientID, nonce, sequence);
        };
    }

    handleToolNotification { |msg, addr|
        var clientID, toolSource, instanceID, action, payload, subscriber;

        if(msg.size < 5) {
            this.sendError(addr, "", "tool notify requires clientID, tool, instance and action");
            ^this;
        };
        clientID = msg[1].asString;
        subscriber = this.authorizedSubscriber(clientID, addr);
        if(subscriber.isNil) { ^this };

        toolSource = msg[2].asString.asSymbol;
        instanceID = msg[3].asString;
        action = msg[4].asString.asSymbol;
        payload = if(msg.size > 5) { msg.copyRange(5, msg.size - 1) } { [] };

        NodeManager.notifyObservers(\externalToolNotification, (
            clientID: clientID,
            toolSource: toolSource,
            toolInstance: instanceID,
            action: action,
            payload: payload,
            receivedAt: Main.elapsedTime
        ));
        subscriber.address.sendMsg(
            '/awb/nm/tool/notified',
            clientID,
            toolSource,
            instanceID,
            action
        );
    }

    handleToolAssociation { |msg, addr|
        var clientID, externalEntryID, toolSource, instanceID;
        var subscriber, object, entry;

        if(msg.size < 4) {
            this.sendError(addr, "", "tool associate requires clientID, entryID and tool");
            ^this;
        };
        clientID = msg[1].asString;
        subscriber = this.authorizedSubscriber(clientID, addr);
        if(subscriber.isNil) { ^this };

        externalEntryID = msg[2].asInteger;
        toolSource = msg[3].asString.asSymbol;
        instanceID = if(msg.size > 4) { msg[4].asString } { clientID };
        object = objectsByEntryID[externalEntryID];
        entry = if(object.notNil) {
            NodeManager.getAll.detect { |candidate| candidate.object === object }
        };

        if(entry.isNil or: { entry.type == \container }) {
            this.sendError(subscriber.address, clientID, "unknown or non-leaf entryID");
            ^this;
        };

        NodeManager.register(object, entry.type, (
            toolSource: toolSource,
            toolInstance: instanceID,
            externalClientID: clientID
        ));
        subscriber.address.sendMsg(
            '/awb/nm/tool/associated',
            clientID,
            externalEntryID,
            toolSource,
            instanceID
        );
    }

    authorizedSubscriber { |clientID, addr|
        var subscriber;

        if(this.isAllowedAddress(addr).not) { ^nil };
        subscriber = subscribers[clientID];
        if(subscriber.isNil) {
            this.sendError(addr, clientID, "not subscribed");
            ^nil;
        };
        if(subscriber.sourceIP != addr.ip.asString) {
            this.sendError(addr, clientID, "subscriber address mismatch");
            ^nil;
        };
        ^subscriber;
    }

    sendError { |addr, clientID, message|
        addr.sendMsg('/awb/nm/error', clientID.asString, message.asString);
    }

    nextSequence {
        sequence = sequence + 1;
        ^sequence;
    }

    externalIDFor { |object|
        var id;

        id = entryIDs[object];
        if(id.isNil) {
            id = nextEntryID;
            nextEntryID = nextEntryID + 1;
            entryIDs[object] = id;
            objectsByEntryID[id] = object;
        };
        ^id;
    }

    sendSnapshot { |subscriber|
        var snapshotSequence, messages;

        snapshotSequence = this.nextSequence;
        subscriber.visibleIDs.clear;
        subscriber.address.sendMsg(
            '/awb/nm/snapshot/begin',
            subscriber.clientID,
            snapshotSequence
        );
        NodeManager.getActive.do { |entry|
            if(subscriber.deliveryMode == \immediate) {
                this.sendEntryTo(subscriber, entry, snapshotSequence);
            } {
                messages = List.new;
                subscriber.messageCapture = messages;
                this.sendEntryTo(subscriber, entry, snapshotSequence);
                subscriber.messageCapture = nil;
                this.deliverMessages(subscriber, messages.asArray);
            };
        };
        subscriber.address.sendMsg(
            '/awb/nm/snapshot/end',
            subscriber.clientID,
            snapshotSequence
        );
    }

    nodeManagerChanged { |action, data|
        var changeSequence, entry;

        changeSequence = this.nextSequence;
        entry = this.registryEntryFrom(data);

        if(action == \unregistered) {
            if(entry.notNil) {
                subscribers.do { |subscriber|
                    this.deliverChange(subscriber, changeSequence, entry.object, {
                        this.sendRemovalTo(subscriber, entry.object, changeSequence);
                    });
                };
            };
            ^this;
        };

        if([\registered, \updated].includes(action) and: { entry.notNil }) {
            subscribers.do { |subscriber|
                this.deliverChange(subscriber, changeSequence, entry.object, {
                    this.sendEntryTo(subscriber, entry, changeSequence);
                });
            };
            ^this;
        };

        // Preserve event-surface actions for recorders and tool adapters even
        // when they do not correspond to an authoritative registry entry.
        subscribers.do { |subscriber|
            this.deliverChange(subscriber, changeSequence, nil, {
                this.sendMessageTo(
                    subscriber,
                    '/awb/nm/event',
                    subscriber.clientID,
                    changeSequence,
                    action.asString
                );
            });
        };
    }

    deliverChange { |subscriber, changeSequence, object, function|
        var messages, key;

        if(subscriber.deliveryMode == \immediate) {
            function.value;
            ^this;
        };

        messages = List.new;
        subscriber.messageCapture = messages;
        function.value;
        subscriber.messageCapture = nil;
        if(messages.isEmpty) { ^this };

        if(subscriber.deliveryMode == \bundle) {
            this.deliverMessages(subscriber, messages.asArray);
            ^this;
        };

        key = if(object.notNil) {
            this.externalIDFor(object)
        } {
            changeSequence.neg
        };
        this.queueTransaction(subscriber, key, changeSequence, messages.asArray);
    }

    queueTransaction { |subscriber, key, changeSequence, messages|
        var clientID;

        if(subscriber.pendingOrder.isEmpty) {
            subscriber.pendingFromSequence = changeSequence;
        };
        subscriber.pendingThroughSequence = changeSequence;
        subscriber.pendingOrder.remove(key);
        subscriber.pendingOrder.add(key);
        subscriber.pendingTransactions[key] = (
            sequence: changeSequence,
            messages: messages
        );

        if(subscriber.flushScheduled.not) {
            subscriber.flushScheduled = true;
            clientID = subscriber.clientID;
            SystemClock.sched(subscriber.batchWindow, {
                var current;
                current = subscribers[clientID];
                if(current === subscriber) {
                    this.flushSubscriber(subscriber);
                };
                nil;
            });
        };
    }

    flushSubscriber { |subscriber|
        var transactions, fromSequence, throughSequence;

        if(subscriber.isNil) { ^this };
        subscriber.flushScheduled = false;
        if(subscriber.pendingOrder.isEmpty) { ^this };

        transactions = subscriber.pendingOrder.collect { |key|
            subscriber.pendingTransactions[key]
        };
        fromSequence = subscriber.pendingFromSequence;
        throughSequence = subscriber.pendingThroughSequence;
        subscriber.pendingOrder.clear;
        subscriber.pendingTransactions.clear;
        subscriber.pendingFromSequence = nil;
        subscriber.pendingThroughSequence = nil;

        // Cap each coalesced OSC packet by transaction count. A transaction is
        // never split, so clear/upsert/value replacement remains atomic.
        transactions.clump(16).do { |group|
            throughSequence = group.last.sequence;
            this.deliverCoalescedGroup(
                subscriber, group, fromSequence, throughSequence
            );
            fromSequence = throughSequence + 1;
        };
    }

    deliverCoalescedGroup { |subscriber, transactions, fromSequence, throughSequence|
        var messages;

        messages = List.new;
        messages.add([
            '/awb/nm/batch/begin', subscriber.clientID,
            fromSequence, throughSequence
        ]);
        transactions.do { |transaction|
            messages.addAll(transaction.messages);
        };
        messages.add([
            '/awb/nm/batch/end', subscriber.clientID,
            fromSequence, throughSequence
        ]);
        this.deliverMessages(subscriber, messages.asArray);
    }

    deliverMessages { |subscriber, messages|
        if(messages.isEmpty) { ^this };
        if(subscriber.deliveryMode == \immediate) {
            messages.do { |message| subscriber.address.sendMsg(*message) };
        } {
            subscriber.address.sendBundle(0.0, *messages);
        };
    }

    sendMessageTo { |subscriber ...message|
        if(subscriber.messageCapture.notNil) {
            subscriber.messageCapture.add(message);
        } {
            subscriber.address.sendMsg(*message);
        };
    }

    registryEntryFrom { |data|
        if(data.isKindOf(Event)
            and: { data[\object].notNil }
            and: { data[\type].notNil }) {
            ^data;
        };
        ^nil;
    }

    sendEntryTo { |subscriber, entry, changeSequence|
        var object, externalID, visible;

        object = entry.object;
        externalID = this.externalIDFor(object);
        visible = this.entryMatchesSubscriber(entry, subscriber);

        if(visible.not) {
            if(subscriber.visibleIDs.includes(externalID)) {
                this.sendRemovalTo(subscriber, object, changeSequence);
            };
            ^this;
        };

        subscriber.visibleIDs.add(externalID);
        if(entry.type == \container) {
            this.sendContainerTo(subscriber, entry, externalID, changeSequence);
        } {
            this.sendLeafTo(subscriber, entry, externalID, changeSequence);
        };
    }

    sendContainerTo { |subscriber, entry, externalID, changeSequence|
        var object, key;

        object = entry.object;
        key = this.keyForContainer(object) ? \unknown;
        this.sendMessageTo(
            subscriber,
            '/awb/nm/container/upsert',
            subscriber.clientID,
            changeSequence,
            externalID,
            key,
            (entry.metadata.name ? object.name ? "Container").asString,
            object.children.size
        );
    }

    sendLeafTo { |subscriber, entry, externalID, changeSequence|
        var object, nodeIDs, serverName, memberships;
        var containerExternalID, containerEntry;

        object = entry.object;
        nodeIDs = this.nodeIDsFor(object);
        serverName = this.serverNameFor(object);
        this.sendMessageTo(
            subscriber,
            '/awb/nm/entry/upsert',
            subscriber.clientID,
            changeSequence,
            externalID,
            entry.type,
            object.class.name,
            this.nameFor(entry),
            entry.active.binaryValue,
            serverName,
            (entry.metadata.toolSource ? "").asString,
            (entry.metadata.presetName ? "").asString,
            (entry.metadata.defName ? "").asString
        );
        this.sendMessageTo(
            subscriber,
            '/awb/nm/entry/nodes/clear',
            subscriber.clientID,
            changeSequence,
            externalID
        );
        nodeIDs.do { |nodeID|
            this.sendMessageTo(
                subscriber,
                '/awb/nm/entry/node',
                subscriber.clientID,
                changeSequence,
                externalID,
                nodeID
            );
        };
        this.sendMessageTo(
            subscriber,
            '/awb/nm/entry/memberships/clear',
            subscriber.clientID,
            changeSequence,
            externalID
        );
        memberships = NodeManager.containersFor(object);
        memberships.do { |container|
            if(this.containerMatchesSubscriber(container, subscriber)) {
                containerExternalID = this.externalIDFor(container);
                if(subscriber.visibleIDs.includes(containerExternalID).not) {
                    containerEntry = NodeManager.getAll.detect { |candidate|
                        candidate.object === container
                    };
                    if(containerEntry.notNil) {
                        subscriber.visibleIDs.add(containerExternalID);
                        this.sendContainerTo(
                            subscriber,
                            containerEntry,
                            containerExternalID,
                            changeSequence
                        );
                    };
                };
                this.sendMessageTo(
                    subscriber,
                    '/awb/nm/membership/upsert',
                    subscriber.clientID,
                    changeSequence,
                    externalID,
                    containerExternalID,
                    this.keyForContainer(container) ? \unknown
                );
            };
        };
        if(subscriber.dataMode == \values) {
            this.sendValuesTo(subscriber, entry, externalID, changeSequence);
        };
    }

    sendValuesTo { |subscriber, entry, externalID, changeSequence|
        var object, args;

        object = entry.object;
        this.sendMessageTo(
            subscriber,
            '/awb/nm/entry/values/clear',
            subscriber.clientID,
            changeSequence,
            externalID
        );

        if(object.isKindOf(Event)) {
            object.keysValuesDo { |key, value|
                this.sendValueTo(
                    subscriber,
                    changeSequence,
                    externalID,
                    "object",
                    key.asString,
                    value,
                    0
                );
            };
        };

        if(object.isKindOf(Synth)) {
            args = entry.metadata.args;
            if(args.notNil) {
                args.asArray.pairsDo { |key, value|
                    this.sendValueTo(
                        subscriber,
                        changeSequence,
                        externalID,
                        "args",
                        key.asString,
                        value,
                        0
                    );
                };
            };
        };

        [\toolState, \toolInstance, \externalClientID].do { |key|
            if(entry.metadata[key].notNil) {
                this.sendValueTo(
                    subscriber,
                    changeSequence,
                    externalID,
                    "metadata",
                    key.asString,
                    entry.metadata[key],
                    0
                );
            };
        };
    }

    sendValueTo { |subscriber, changeSequence, externalID, source, keyPath, value, depth|
        var childPath;

        if(depth > 4) {
            this.sendUnsupportedValueTo(
                subscriber,
                changeSequence,
                externalID,
                source,
                keyPath,
                "maximumDepth"
            );
            ^this;
        };

        if(value.isNil) {
            this.sendScalarValueTo(
                subscriber, changeSequence, externalID, source, keyPath,
                "nil", -1, ""
            );
            ^this;
        };
        if(value === true or: { value === false }) {
            this.sendScalarValueTo(
                subscriber, changeSequence, externalID, source, keyPath,
                "boolean", -1, value.binaryValue
            );
            ^this;
        };
        if(value.isNumber) {
            this.sendScalarValueTo(
                subscriber, changeSequence, externalID, source, keyPath,
                "number", -1, value
            );
            ^this;
        };
        if(value.isKindOf(String) or: { value.isKindOf(Symbol) }) {
            this.sendScalarValueTo(
                subscriber, changeSequence, externalID, source, keyPath,
                "string", -1, value.asString
            );
            ^this;
        };
        if(value.isKindOf(Dictionary)) {
            value.keysValuesDo { |key, child|
                childPath = keyPath ++ "." ++ key.asString;
                this.sendValueTo(
                    subscriber,
                    changeSequence,
                    externalID,
                    source,
                    childPath,
                    child,
                    depth + 1
                );
            };
            ^this;
        };
        if(value.isKindOf(SequenceableCollection)) {
            value.do { |child, index|
                childPath = keyPath ++ "[" ++ index ++ "]";
                this.sendValueTo(
                    subscriber,
                    changeSequence,
                    externalID,
                    source,
                    childPath,
                    child,
                    depth + 1
                );
            };
            ^this;
        };

        this.sendUnsupportedValueTo(
            subscriber,
            changeSequence,
            externalID,
            source,
            keyPath,
            value.class.name.asString
        );
    }

    sendScalarValueTo { |subscriber, changeSequence, externalID, source,
        keyPath, valueType, index, value|

        this.sendMessageTo(
            subscriber,
            '/awb/nm/entry/value',
            subscriber.clientID,
            changeSequence,
            externalID,
            source,
            keyPath,
            valueType,
            index,
            value
        );
    }

    sendUnsupportedValueTo { |subscriber, changeSequence, externalID, source,
        keyPath, className|

        this.sendMessageTo(
            subscriber,
            '/awb/nm/entry/value/unsupported',
            subscriber.clientID,
            changeSequence,
            externalID,
            source,
            keyPath,
            className
        );
    }

    sendRemovalTo { |subscriber, object, changeSequence|
        var externalID;

        externalID = entryIDs[object];
        if(externalID.notNil and: { subscriber.visibleIDs.includes(externalID) }) {
            this.sendMessageTo(
                subscriber,
                '/awb/nm/entry/remove',
                subscriber.clientID,
                changeSequence,
                externalID
            );
            subscriber.visibleIDs.remove(externalID);
        };
    }

    entryMatchesSubscriber { |entry, subscriber|
        var targetContainer;

        if(subscriber.scopeKind == \all) { ^true };
        targetContainer = this.containerForScope(subscriber);
        if(targetContainer.isNil) { ^false };
        if(entry.object === targetContainer) { ^true };
        if(entry.type == \container) { ^false };
        ^targetContainer.children.includes(entry.object);
    }

    containerMatchesSubscriber { |container, subscriber|
        var targetContainer;

        if(subscriber.scopeKind == \all) { ^true };
        targetContainer = this.containerForScope(subscriber);
        ^container === targetContainer;
    }

    containerForScope { |subscriber|
        var key;

        key = case
        { subscriber.scopeKind == \tool } {
            ("toolSource_" ++ subscriber.scopeValue).asSymbol
        }
        { subscriber.scopeKind == \preset } {
            ("preset_" ++ subscriber.scopeValue).asSymbol
        }
        { subscriber.scopeKind == \synthDef } {
            ("synthDef_" ++ subscriber.scopeValue).asSymbol
        }
        { subscriber.scopeKind == \container } {
            subscriber.scopeValue
        }
        { nil };
        ^if(key.notNil) { NodeManager.getStreamContainers[key] } { nil };
    }

    keyForContainer { |container|
        var result;

        result = nil;
        NodeManager.getStreamContainers.keysValuesDo { |key, candidate|
            if(candidate === container) { result = key };
        };
        ^result;
    }

    nodeIDsFor { |object|
        if(object.isKindOf(Synth)) { ^[object.nodeID] };
        if(object.isKindOf(Event) and: { object[\id].notNil }) {
            ^object[\id].asArray;
        };
        if(object.respondsTo(\nodeID) and: { object.nodeID.notNil }) {
            ^[object.nodeID];
        };
        ^[];
    }

    serverNameFor { |object|
        var server;

        server = if(object.isKindOf(Event)) {
            object[\server]
        } {
            if(object.respondsTo(\server)) { object.server } { nil }
        };
        ^if(server.notNil) { server.name.asString } { "" };
    }

    nameFor { |entry|
        var object;

        object = entry.object;
        if(entry.metadata.name.notNil) { ^entry.metadata.name.asString };
        if(object.isKindOf(Synth)) { ^("Synth(" ++ object.defName ++ ")") };
        if(object.isKindOf(Event)) {
            ^("Event(" ++ (object[\instrument] ? \default) ++ ")");
        };
        ^object.class.name.asString;
    }
}
