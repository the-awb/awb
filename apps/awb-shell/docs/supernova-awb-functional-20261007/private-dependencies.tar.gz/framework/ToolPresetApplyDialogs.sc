ToolPresetLoadDialog {
    var <instance, <library, <window, <listView, <detailView, <applyButton;
    var <compatibleKeys, <selectedPreset;
    var appliedAction, closed;

    *open { |instance, library, appliedAction|
        ^super.new.init(instance, library, appliedAction);
    }

    init { |anInstance, aLibrary, anAction|
        if(anInstance.isKindOf(ToolInstance).not) {
            Error("ToolPresetLoadDialog requires a ToolInstance").throw;
        };
        instance = anInstance;
        library = aLibrary ? ToolPresets.default;
        if(library.isKindOf(ToolPresetLibrary).not) {
            Error("ToolPresetLoadDialog requires a ToolPresetLibrary").throw;
        };
        appliedAction = anAction;
        compatibleKeys = [];
        closed = false;
        this.build;
        library.addObserver(this);
        this.refresh;
        window.front;
        ^this;
    }

    build {
        var applyRow;

        window = Window(
            "Load preset into %".format(instance.definition.displayName),
            Rect(300, 180, 620, 430)
        );
        window.onClose_({ this.windowClosed });
        listView = ListView(window).action_({ this.showSelection });
        detailView = TextView(window)
            .editable_(false)
            .font_(Font.monospace(10));
        applyButton = Button(window)
            .states_([["Load into existing Tool"]])
            .action_({ this.applySelected });
        applyRow = HLayout(
            [StaticText(window).string_(instance.instanceID), stretch: 1],
            Button(window).states_([["Reload library"]])
                .action_({ this.reloadLibrary }),
            Button(window).states_([["Cancel"]]).action_({ this.close }),
            applyButton
        );
        window.layout_(VLayout(
            StaticText(window).string_("Compatible ToolPresets"),
            [listView, stretch: 1],
            [detailView, stretch: 1],
            applyRow
        ));
        ^this;
    }

    reloadLibrary {
        try {
            library.load;
            this.refresh;
        } { |error|
            detailView.string_(error.errorString);
        };
        ^library;
    }

    refresh {
        var previousKey;

        if(closed) { ^this };
        previousKey = if(selectedPreset.notNil) { selectedPreset.name.asSymbol } { nil };
        compatibleKeys = library.compatibleWith(instance).keys.asArray.sort;
        listView.items_(compatibleKeys.collect { |key|
            var preset = library.at(key);
            "%  [%]".format(preset.name, preset.address)
        });
        selectedPreset = nil;
        if(previousKey.notNil and: { compatibleKeys.includes(previousKey) }) {
            this.selectKey(previousKey);
        } {
            detailView.string_(if(compatibleKeys.isEmpty) {
                "No compatible ToolPresets for % / %."
                    .format(
                        instance.definition.id,
                        instance.definition.dependencies[\promotionContract]
                    )
            } {
                "Select a ToolPreset to load into this existing instance."
            });
            applyButton.enabled_(false);
        };
        ^this;
    }

    showSelection {
        var index;

        index = listView.value;
        if(index.isNil or: { index < 0 } or: { index >= compatibleKeys.size }) {
            selectedPreset = nil;
            applyButton.enabled_(false);
            ^nil;
        };
        selectedPreset = library.at(compatibleKeys[index]);
        detailView.string_(selectedPreset.asDict.asCompileString);
        applyButton.enabled_(true);
        ^selectedPreset;
    }

    selectKey { |key|
        var index;

        index = compatibleKeys.indexOf(key.asSymbol);
        if(index.isNil) { ^nil };
        listView.value_(index);
        ^this.showSelection;
    }

    applySelected {
        if(selectedPreset.isNil) { ^nil };
        try {
            selectedPreset.applyTo(instance);
            if(appliedAction.notNil) {
                appliedAction.value(selectedPreset, instance);
            };
            this.close;
        } { |error|
            detailView.string_(error.errorString);
        };
        ^selectedPreset;
    }

    toolPresetLibraryChanged { |action, preset|
        if(closed.not) { { this.refresh }.defer };
    }

    windowClosed {
        if(closed.not) {
            closed = true;
            library.removeObserver(this);
        };
        ^this;
    }

    close {
        if(closed) { ^this };
        if(window.notNil and: { window.isClosed.not }) {
            window.close;
        } {
            this.windowClosed;
        };
        ^this;
    }
}

ToolPresetTargetDialog {
    var <preset, <window, <listView, <detailView, <applyButton;
    var <compatibleInstances, <selectedInstance;
    var appliedAction, closed;

    *open { |preset, appliedAction|
        ^super.new.init(preset, appliedAction);
    }

    init { |aPreset, anAction|
        if(aPreset.isKindOf(ToolPreset).not) {
            Error("ToolPresetTargetDialog requires a ToolPreset").throw;
        };
        preset = aPreset;
        appliedAction = anAction;
        compatibleInstances = [];
        closed = false;
        this.build;
        this.refresh;
        window.front;
        ^this;
    }

    build {
        window = Window(
            "Apply % to existing Tool".format(preset.name),
            Rect(340, 220, 600, 360)
        );
        window.onClose_({ closed = true });
        listView = ListView(window).action_({ this.showSelection });
        detailView = TextView(window)
            .editable_(false)
            .font_(Font.monospace(10));
        applyButton = Button(window)
            .states_([["Apply preset"]])
            .action_({ this.applySelected });
        window.layout_(VLayout(
            StaticText(window).string_("Compatible active ToolInstances"),
            [listView, stretch: 1],
            [detailView, stretch: 1],
            HLayout(
                Button(window).states_([["Refresh"]]).action_({ this.refresh }),
                [StaticText(window), stretch: 1],
                Button(window).states_([["Cancel"]]).action_({ this.close }),
                applyButton
            )
        ));
        ^this;
    }

    refresh {
        var previousID;

        if(closed) { ^this };
        previousID = if(selectedInstance.notNil) { selectedInstance.instanceID } { nil };
        compatibleInstances = ToolLauncher.instancesFor(preset.toolID)
            .select { |instance| preset.isCompatibleWith(instance) }
            .sort { |a, b| a.instanceID < b.instanceID };
        listView.items_(compatibleInstances.collect { |instance|
            "%  revision %".format(instance.instanceID, instance.configRevision)
        });
        selectedInstance = nil;
        if(previousID.notNil) {
            this.selectInstanceID(previousID);
        };
        if(selectedInstance.isNil) {
            detailView.string_(if(compatibleInstances.isEmpty) {
                "No compatible active ToolInstances."
            } {
                "Select the existing ToolInstance to reconfigure."
            });
            applyButton.enabled_(false);
        };
        ^this;
    }

    showSelection {
        var index;

        index = listView.value;
        if(index.isNil or: { index < 0 } or: { index >= compatibleInstances.size }) {
            selectedInstance = nil;
            applyButton.enabled_(false);
            ^nil;
        };
        selectedInstance = compatibleInstances[index];
        detailView.string_(selectedInstance.snapshot.asCompileString);
        applyButton.enabled_(true);
        ^selectedInstance;
    }

    selectInstanceID { |instanceID|
        var index;

        index = compatibleInstances.detectIndex { |instance|
            instance.instanceID == instanceID.asString
        };
        if(index.isNil) { ^nil };
        listView.value_(index);
        ^this.showSelection;
    }

    applySelected {
        if(selectedInstance.isNil) { ^nil };
        try {
            preset.applyTo(selectedInstance);
            if(appliedAction.notNil) {
                appliedAction.value(preset, selectedInstance);
            };
            this.close;
        } { |error|
            detailView.string_(error.errorString);
        };
        ^selectedInstance;
    }

    close {
        if(closed) { ^this };
        closed = true;
        if(window.notNil and: { window.isClosed.not }) { window.close };
        ^this;
    }
}
