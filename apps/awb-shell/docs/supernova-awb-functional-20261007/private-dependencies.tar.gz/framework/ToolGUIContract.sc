ToolGUIContract {
    // Runtime interface validation keeps ToolGUIs composable without forcing
    // unrelated screens into a visual inheritance hierarchy.

    *requiredSelectors {
        ^[\view, \instance, \instanceControls, \embedded, \refresh, \dispose];
    }

    *validate { |toolGUI, expectedInstance|
        var missing;

        if(toolGUI.isNil) { Error("ToolGUI factory returned nil").throw };
        missing = this.requiredSelectors.reject { |selector|
            toolGUI.respondsTo(selector)
        };
        if(missing.notEmpty) {
            Error("ToolGUI % is missing contract selectors: %"
                .format(toolGUI.class.name, missing)).throw;
        };
        if(expectedInstance.notNil and: { toolGUI.instance !== expectedInstance }) {
            Error("ToolGUI is attached to the wrong ToolInstance").throw;
        };
        if(toolGUI.view.isNil) {
            Error("ToolGUI contract requires a root view").throw;
        };
        if(toolGUI.instanceControls.isKindOf(ToolInstanceControls).not) {
            Error("ToolGUI contract requires composed ToolInstanceControls").throw;
        };
        ^toolGUI;
    }
}
