ToolPresetLibrary {
    var <presets, <libraryPath, <observers, <rejectedRecords;

    *new { |libraryPath|
        ^super.newCopyArgs(Dictionary.new, libraryPath, Set.new, Dictionary.new);
    }

    *defaultPath {
        ^Platform.userAppSupportDir +/+ "awbCollider-ToolPresets.archive";
    }

    at { |key|
        ^presets[key.asSymbol];
    }

    add { |preset, allowOverwrite=false|
        var key;

        if(preset.isKindOf(ToolPreset).not) {
            Error("ToolPresetLibrary accepts only ToolPreset values").throw;
        };
        key = preset.name.asSymbol;
        if(presets.includesKey(key) and: { allowOverwrite.not }) {
            Error("ToolPreset already exists: %".format(key)).throw;
        };
        presets[key] = preset;
        this.notifyObservers(\added, preset);
        ^preset;
    }

    remove { |key|
        var preset;
        preset = presets.removeAt(key.asSymbol);
        if(preset.notNil) { this.notifyObservers(\removed, preset) };
        ^preset;
    }

    keys {
        ^presets.keys.asArray.sort;
    }

    size {
        ^presets.size;
    }

    compatibleWith { |instance|
        if(instance.isKindOf(ToolInstance).not) {
            Error("ToolPresetLibrary compatibility requires a ToolInstance").throw;
        };
        ^presets.select { |preset| preset.isCompatibleWith(instance) };
    }

    save { |path|
        var savePath, data, directory;

        savePath = path ? libraryPath;
        if(savePath.isNil) { Error("ToolPresetLibrary requires a save path").throw };
        data = rejectedRecords.copy;
        presets.keysValuesDo { |key, preset| data[key] = preset.asDict };
        directory = PathName(savePath).pathOnly;
        if(File.exists(directory).not) { PathName(directory).mkdir };
        data.writeArchive(savePath);
        ^savePath;
    }

    load { |path|
        var loadPath, data, loaded;

        loadPath = path ? libraryPath;
        if(loadPath.isNil) { Error("ToolPresetLibrary requires a load path").throw };
        if(File.exists(loadPath).not) { ^this };
        data = Object.readArchive(loadPath);
        if(data.isKindOf(Dictionary).not) {
            Error("Invalid ToolPreset library at %".format(loadPath)).throw;
        };
        loaded = Dictionary.new;
        rejectedRecords = Dictionary.new;
        data.keysValuesDo { |key, record|
            try {
                loaded[key.asSymbol] = ToolPreset.fromDict(record);
            } { |error|
                rejectedRecords[key.asSymbol] = record;
                ("Rejected ToolPreset %: %"
                    .format(key, error.errorString)).warn;
            };
        };
        presets = loaded;
        this.notifyObservers(\loaded, nil);
        ^this;
    }

    addObserver { |observer|
        observers.add(observer);
        ^observer;
    }

    removeObserver { |observer|
        observers.remove(observer);
        ^observer;
    }

    notifyObservers { |action, preset|
        observers.do { |observer|
            if(observer.respondsTo(\toolPresetLibraryChanged)) {
                observer.toolPresetLibraryChanged(action, preset);
            };
        };
    }
}

ToolPresets {
    classvar default, defaultLoaded;

    *initClass {
        default = ToolPresetLibrary(ToolPresetLibrary.defaultPath);
        defaultLoaded = false;
    }

    *default {
        if(defaultLoaded != true) {
            default.load;
            defaultLoaded = true;
        };
        ^default;
    }

    *useLibrary { |library, loadOnFirstAccess=false|
        if(library.isKindOf(ToolPresetLibrary).not) {
            Error("ToolPresets requires a ToolPresetLibrary").throw;
        };
        default = library;
        defaultLoaded = loadOnFirstAccess.not;
        ^default;
    }

    *at { |key|
        ^this.default.at(key);
    }

    *add { |preset, allowOverwrite=false|
        ^this.default.add(preset, allowOverwrite);
    }

    *remove { |key|
        ^this.default.remove(key);
    }

    *save { |path|
        ^this.default.save(path);
    }

    *load { |path|
        default.load(path);
        defaultLoaded = true;
        ^default;
    }

    *keys {
        ^this.default.keys;
    }

    *size {
        ^this.default.size;
    }
}

ScaleBeatToolPresetAdapter {
    *fromCandidate { |candidate, name, address="uncategorized", tags=#[], notes=""|
        if(candidate[\contract] != \scaleBeatSelectionV1) {
            Error("ScaleBeatToolPresetAdapter: unsupported candidate contract").throw;
        };
        if(candidate[\toolID] != \scaleBeatAnalyser) {
            Error("ScaleBeatToolPresetAdapter: candidate has the wrong tool ID").throw;
        };
        ^ToolPreset(
            name,
            candidate[\toolID],
            candidate[\toolVersion],
            candidate[\contract],
            candidate[\config],
            candidate[\selectedPair],
            address,
            tags,
            notes,
            (kind: \toolSnapshotPromotion)
        );
    }
}

ToneDiamondToolPresetAdapter {
    *fromCandidate { |candidate, name, address="uncategorized", tags=#[], notes=""|
        if(candidate[\contract] != \toneDiamondSelectionV1
            or: { candidate[\toolID] != \toneDiamond }) {
            Error("ToneDiamondToolPresetAdapter: incompatible candidate").throw;
        };
        ^ToolPreset(
            name,
            candidate[\toolID],
            candidate[\toolVersion],
            candidate[\contract],
            candidate[\config],
            (
                activeCells: candidate[\activeCells] ? [],
                referenceCell: candidate[\referenceCell],
                relationships: candidate[\relationships] ? []
            ),
            address,
            tags,
            notes,
            (kind: \toolSnapshotPromotion)
        );
    }
}

BeatHarmonyToolPresetAdapter {
    *fromCandidate { |candidate, name, address="uncategorized", tags=#[], notes=""|
        if(candidate[\contract] != \beatHarmonySelectionV1
            or: { candidate[\toolID] != \beatHarmonyGenerator }) {
            Error("BeatHarmonyToolPresetAdapter: incompatible candidate").throw;
        };
        ^ToolPreset(
            name,
            candidate[\toolID],
            candidate[\toolVersion],
            candidate[\contract],
            candidate[\config],
            (
                selectedIndex: candidate[\config][\selectedIndex],
                selectedResult: candidate[\selectedResult]
            ),
            address,
            tags,
            notes,
            (kind: \toolSnapshotPromotion)
        );
    }
}

ScaleBeatEventPresetAdapter {
    *candidateFromEmission { |emission|
        var payload, origin;

        if(emission[\type] != \degreePair) {
            Error("ScaleBeatEventPresetAdapter requires a degreePair emission").throw;
        };
        payload = emission[\payload];
        origin = (
            kind: \toolEmission,
            eventNamespaceRoot: emission[\toolSource],
            sourceToolPreset: if(emission[\sourcePresetRef].notNil) {
                emission[\sourcePresetRef].deepCopy
            } { nil },
            sourceToolPresetFingerprint: emission[\sourcePresetFingerprint],
            toolID: emission[\toolSource],
            toolInstance: emission[\toolInstance],
            emissionID: emission[\emissionID],
            emissionType: emission[\type],
            configRevision: emission[\configRevision],
            configFingerprint: emission[\configFingerprint]
        );
        ^(
            domain: \event,
            contract: \scaleBeatDegreePairEventV1,
            event: (
                instrument: \awbScaleBeatAudition,
                freq1: payload[\frequency1],
                freq2: payload[\frequency2],
                amp: emission[\config][\amplitude] ? 0.05,
                dur: 1
            ),
            origin: origin
        );
    }

    *fromCandidate { |candidate, name, address="uncategorized", tags=#[], notes=""|
        var preset, root, normalizedAddress;

        if(candidate[\contract] != \scaleBeatDegreePairEventV1) {
            Error("ScaleBeatEventPresetAdapter: unsupported candidate contract").throw;
        };
        if(candidate[\origin][\eventNamespaceRoot].isNil) {
            Error("ScaleBeatEventPresetAdapter: candidate has no Tool namespace root").throw;
        };
        root = candidate[\origin][\eventNamespaceRoot].asString;
        normalizedAddress = (address ? "events").asString.stripWhiteSpace;
        if(normalizedAddress.isEmpty or: { normalizedAddress == "uncategorized" }) {
            normalizedAddress = root;
        } {
            if(normalizedAddress != root
                and: { normalizedAddress.beginsWith(root ++ "/").not }) {
                normalizedAddress = root ++ "/" ++ normalizedAddress;
            };
        };
        preset = EventPreset.fromEvent(
            candidate[\event], name, normalizedAddress, tags, notes
        );
        ^preset.setDurableOrigin(candidate[\origin]);
    }
}
