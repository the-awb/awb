/*
SynthDefContextOSCBridge
========================

Read-only, bounded projection of the SynthDefs actually present in this sclang
context. The compiled graph is sent exactly as desc.def.asBytes; ControlSpecs
are sent separately because .scsyndef does not reliably contain that metadata.
No definition is accepted, compiled, installed or executed by this bridge.
*/
SynthDefContextOSCBridge {
    classvar <default;
    var <clients, <responders, <isRunning, <allowRemote;
    var <chunkBytes, <maxDefinitionBytes;

    *new { |allowRemote = false, chunkBytes = 768,
        maxDefinitionBytes = 4194304|
        ^super.new.init(
            allowRemote, chunkBytes, maxDefinitionBytes
        );
    }

    *start { |allowRemote = false, chunkBytes = 768,
        maxDefinitionBytes = 4194304|
        if(default.isNil) {
            default = this.new(
                allowRemote, chunkBytes, maxDefinitionBytes
            );
        };
        default.start;
        ^default;
    }

    *stop {
        if(default.notNil) {
            default.stop;
            default = nil;
        };
    }

    init { |remoteAllowed, requestedChunkBytes, requestedMaximum|
        clients = Dictionary.new;
        responders = List.new;
        isRunning = false;
        allowRemote = remoteAllowed;
        chunkBytes = requestedChunkBytes.asInteger.clip(64, 2048);
        maxDefinitionBytes = requestedMaximum.asInteger.max(chunkBytes);
        ^this;
    }

    start {
        if(isRunning) { ^this };

        responders.add(OSCFunc({ |msg, time, addr|
            this.handleHello(msg, addr);
        }, '/awb/synthdef/hello'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleDisconnect(msg, addr);
        }, '/awb/synthdef/disconnect'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleList(msg, addr);
        }, '/awb/synthdef/list'));
        responders.add(OSCFunc({ |msg, time, addr|
            this.handleDescribe(msg, addr);
        }, '/awb/synthdef/describe'));

        isRunning = true;
        ^this;
    }

    stop {
        if(isRunning.not) { ^this };
        responders.do(_.free);
        responders.clear;
        clients.clear;
        isRunning = false;
        ^this;
    }

    definitionsChanged {
        clients.values.do { |client|
            client.address.sendMsg(
                '/awb/synthdef/connected', client.clientID, 1
            );
        };
        ^this;
    }

    isAllowedAddress { |addr|
        var ip;

        if(allowRemote) { ^true };
        ip = addr.ip.asString;
        ^ip.beginsWith("127.")
            or: { ip.beginsWith("::1") }
            or: { ip.beginsWith("::ffff:127.") };
    }

    handleHello { |msg, addr|
        var clientID, replyPort, client;

        if(this.isAllowedAddress(addr).not or: { msg.size < 2 }) {
            ^this;
        };
        clientID = msg[1].asString;
        replyPort = if(msg.size > 2) {
            msg[2].asInteger
        } {
            addr.port
        };
        if(replyPort <= 0) { replyPort = addr.port };
        client = (
            clientID: clientID,
            address: NetAddr(addr.ip.asString, replyPort),
            sourceIP: addr.ip.asString,
            sourcePort: addr.port
        );
        clients[clientID] = client;
        client.address.sendMsg(
            '/awb/synthdef/connected', clientID, 1
        );
        ^this;
    }

    handleDisconnect { |msg, addr|
        var client;

        if(this.isAllowedAddress(addr).not or: { msg.size < 2 }) {
            ^this;
        };
        client = clients[msg[1].asString];
        if(client.notNil
            and: { client.sourceIP == addr.ip.asString }
            and: { client.sourcePort == addr.port }) {
            clients.removeAt(client.clientID);
        };
        ^this;
    }

    authorizedClient { |msg, addr|
        var client;

        if(this.isAllowedAddress(addr).not or: { msg.size < 2 }) {
            ^nil;
        };
        client = clients[msg[1].asString];
        if(client.isNil
            or: { client.sourceIP != addr.ip.asString }
            or: { client.sourcePort != addr.port }) {
            ^nil;
        };
        ^client;
    }

    handleList { |msg, addr|
        var client, requestID, names;

        client = this.authorizedClient(msg, addr);
        if(client.isNil or: { msg.size < 3 }) { ^this };
        requestID = msg[2].asString;
        names = SynthDescLib.global.synthDescs.keys.asArray
            .collect(_.asString).sort;
        client.address.sendMsg(
            '/awb/synthdef/list/begin',
            client.clientID, requestID, names.size
        );
        names.do { |name, index|
            client.address.sendMsg(
                '/awb/synthdef/list/item',
                client.clientID, requestID, index, name
            );
        };
        client.address.sendMsg(
            '/awb/synthdef/list/end',
            client.clientID, requestID, names.size
        );
        ^this;
    }

    handleDescribe { |msg, addr|
        var client, requestID, name, desc, bytes, chunks;
        var specs, specNames;

        client = this.authorizedClient(msg, addr);
        if(client.isNil or: { msg.size < 4 }) { ^this };
        requestID = msg[2].asString;
        name = msg[3].asString;
        desc = SynthDescLib.global.at(name.asSymbol);
        if(desc.isNil) {
            this.sendError(client, requestID, \unknownSynthDef, name);
            ^this;
        };
        if(desc.def.isNil) {
            this.sendError(
                client, requestID, \graphUnavailable, name
            );
            ^this;
        };

        bytes = desc.def.asBytes;
        if(bytes.size > maxDefinitionBytes) {
            this.sendError(
                client, requestID, \definitionTooLarge,
                bytes.size.asString
            );
            ^this;
        };
        chunks = bytes.clump(chunkBytes);
        specs = desc.specs ? ();
        specNames = specs.keys.asArray.select { |key|
            specs[key].isKindOf(ControlSpec)
        }.collect(_.asString).sort;

        client.address.sendMsg(
            '/awb/synthdef/description/begin',
            client.clientID, requestID, name,
            bytes.size, chunks.size, specNames.size
        );
        chunks.do { |chunk, index|
            client.address.sendMsg(
                '/awb/synthdef/description/chunk',
                client.clientID, requestID, index,
                this.bytesToHex(chunk)
            );
        };
        specNames.do { |specName|
            this.sendSpec(
                client, requestID, specName,
                specs[specName.asSymbol]
            );
        };
        client.address.sendMsg(
            '/awb/synthdef/description/end',
            client.clientID, requestID, name,
            bytes.size, chunks.size, specNames.size
        );
        ^this;
    }

    sendSpec { |client, requestID, name, spec|
        var warp, warpKind, warpValue;

        warp = spec.warp.asSpecifier;
        if(warp.isNumber) {
            warpKind = "curve";
            warpValue = warp;
        } {
            warpKind = "named";
            warpValue = warp.asString;
        };
        client.address.sendMsg(
            '/awb/synthdef/description/spec',
            client.clientID, requestID, name.asString,
            spec.minval, spec.maxval,
            warpKind, warpValue,
            spec.step, spec.default, spec.units.asString
        );
        ^this;
    }

    bytesToHex { |bytes|
        ^bytes.collect { |byte|
            byte.asInteger.bitAnd(255).asHexString(2)
        }.join;
    }

    sendError { |client, requestID, code, detail|
        client.address.sendMsg(
            '/awb/synthdef/error',
            client.clientID, requestID,
            code.asString, detail.asString
        );
        ^this;
    }
}
