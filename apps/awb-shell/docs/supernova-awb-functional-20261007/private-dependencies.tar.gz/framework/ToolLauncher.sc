ToolLauncher {
    classvar <instances;

    *initClass {
        instances = Dictionary.new;
    }

    *open { |toolID, initialConfig, options|
        ^this.openNamed(toolID, nil, initialConfig, options);
    }

    *openNamed { |toolID, instanceID, initialConfig, options|
        var definition, existing, instance;

        options = options ? ();
        definition = ToolRegistry.at(toolID, options[\toolVersion]);
        if(definition.isNil) {
            Error("ToolLauncher: unavailable tool % version %"
                .format(toolID, options[\toolVersion] ? "default")).throw;
        };

        if(instanceID.notNil) {
            instanceID = instanceID.asString;
            existing = instances[instanceID];
            if(existing.notNil) {
                if(existing.definition.id != definition.id or: { existing.definition.version != definition.version }) {
                    Error("ToolLauncher: instance ID % belongs to %"
                        .format(instanceID, existing.definition.id)).throw;
                };
                ^existing;
            };
        };

        if(definition.multipleInstances.not) {
            existing = instances.values.detect { |item|
                item.definition.id == definition.id and: { item.definition.version == definition.version } and: { item.isPlaying }
            };
            if(existing.notNil) { ^existing };
        };

        instance = ToolInstance(definition, initialConfig, instanceID);
        instances[instance.instanceID] = instance;

        try {
            instance.open(options ? ());
        } { |error|
            instances.removeAt(instance.instanceID);
            try { instance.close } { |cleanupError| cleanupError.warn };
            error.throw;
        };

        ^instance;
    }

    *close { |instanceID|
        var instance;
        instance = instances[instanceID.asString];
        if(instance.notNil) {
            instance.close;
        };
        ^instance;
    }

    *at { |instanceID|
        ^instances[instanceID.asString];
    }

    *active {
        ^instances.values.select(_.isPlaying).asArray;
    }

    *instancesFor { |toolID|
        toolID = toolID.asSymbol;
        ^instances.values.select { |instance|
            instance.definition.id == toolID
        }.asArray;
    }

    *instanceClosed { |instance|
        instances.removeAt(instance.instanceID);
    }

    *closeAll {
        instances.values.copy.do(_.close);
    }
}
