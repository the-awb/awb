// PluginEnvDetect3.cpp
// William Boon (armedwithbow@gmail.com)

#include "SC_PlugIn.hpp"
// #include "EnvDetect3.hpp"

static InterfaceTable* ft;

struct EnvDetect3 : public Unit {
	float m_env; //m_atk,m_rel,
};

void EnvDetect3_next_a(EnvDetect3 *unit, int inNumSamples);
	void EnvDetect3_Ctor(EnvDetect3* unit);

void EnvDetect3_next_k(EnvDetect3 *unit, int inNumSamples);
	void EnvDetect3_Ctor(EnvDetect3* unit);

void EnvDetect3_Ctor(EnvDetect3* unit) {
	if (INRATE(0) == calc_FullRate) {
            // if the frequency argument is audio rate
            SETCALC(EnvDetect3_next_a);
			
        } else {   
			SETCALC(EnvDetect3_next_k); 
        // if thene frequency argument is control rate (or a scalar).

        }  

	//	unit->m_atk= (float) exp(-1/(SAMPLERATE*ZIN0(1)));
	//
	//	unit->m_rel= (float) exp(-1/(SAMPLERATE*ZIN0(2)));
	//
	//printf("atk %f rel %f\t",unit->m_atk,unit->m_rel);

	unit->m_env=0.0;
}


void EnvDetect3_next_a(EnvDetect3 *unit, int inNumSamples) {

	float *in = ZIN(0);
	float *out = ZOUT(0);

	//int ksamps = unit->mWorld->mFullRate.mBufLength;

	float envelope= unit->m_env;
	//float ga= unit->m_atk;
	//	float gr= unit->m_rel;
	//

	float ga= (float) exp(-1/(SAMPLERATE*ZIN0(1)));
	float gr= (float) exp(-1/(SAMPLERATE*ZIN0(2)));

	//find max this block
	for(int j=0; j<inNumSamples; ++j) {
		float next= fabs(ZXP(in));
		//printf("next %f\t",next);

		if(envelope<next){
			envelope*=ga;
			envelope+= (1-ga)*next;
		}
		else {
			envelope*=gr;
			envelope+= (1-gr)*next;
		}

		ZXP(out)= envelope;

	}

	unit->m_env=envelope;

}

void EnvDetect3_next_k(EnvDetect3 *unit, int inNumSamples) {

	float *in = ZIN(0);
	float *out = ZOUT(0);

	//int ksamps = unit->mWorld->mFullRate.mBufLength;

	float envelope= unit->m_env;
	//float ga= unit->m_atk;
	//	float gr= unit->m_rel;
	//

	float ga= (float) exp(-1/(SAMPLERATE*ZIN0(1)));
	float gr= (float) exp(-1/(SAMPLERATE*ZIN0(2)));

	//find max this block
	for(int j=0; j<inNumSamples; ++j) {
		float next= fabs(ZXP(in));
		//printf("next %f\t",next);

		if(envelope<next){
			envelope*=ga;
			envelope+= (1-ga)*next;
		}
		else {
			envelope*=gr;
			envelope+= (1-gr)*next;
		}

		ZXP(out)= envelope;

	}

	unit->m_env=envelope;

}
// namespace EnvDetect3 {

// EnvDetect3::EnvDetect3() {
//     if (isAudioRateIn(0)) {
//             // if the frequency argument is audio rate
//             mCalcFunc = make_calc_function<EnvDetect3, &EnvDetect3::next_a>();
//         } else {    
//         // if thene frequency argument is control rate (or a scalar).
//             mCalcFunc = make_calc_function<EnvDetect3, &EnvDetect3::next_k>();
//         }  
    
//     //  if (isAudioRateIn(0)) {
//     //         next_a(1);
//     //     } else {
//     //         next_k(1);
//     //     }
//     unit->m_env=0.0;
// }

// void EnvDetect3::next_a(int nSamples) {
//     float *in = ZIN(0);
// 	float *out = ZOUT(0);

// 	//int ksamps = unit->mWorld->mFullRate.mBufLength;

// 	float envelope= m_env;
// 	//float ga= unit->m_atk;
// 	//	float gr= unit->m_rel;
// 	//

// 	float ga= (float) exp(-1/(SAMPLERATE*ZIN0(1)));
// 	float gr= (float) exp(-1/(SAMPLERATE*ZIN0(2)));

// 	//find max this block
// 	for(int j=0; j<nSamples; ++j) {
// 		float next= fabs(ZXP(in));
// 		//printf("next %f\t",next);

// 		if(envelope<next){
// 			envelope*=ga;
// 			envelope+= (1-ga)*next;
// 		}
// 		else {
// 			envelope*=gr;
// 			envelope+= (1-gr)*next;
// 		}

// 		ZXP(out)= envelope;

// 	}

// 	m_env=envelope;
// }

// void EnvDetect3::next_k(int nSamples) {
//     float *in = ZIN(0);
// 	float *out = ZOUT(0);

// 	//int ksamps = unit->mWorld->mFullRate.mBufLength;

// 	float envelope= m_env;
// 	//float ga= unit->m_atk;
// 	//	float gr= unit->m_rel;
// 	//

// 	float ga= (float) exp(-1/(SAMPLERATE*ZIN0(1)));
// 	float gr= (float) exp(-1/(SAMPLERATE*ZIN0(2)));

// 	//find max this block
// 	for(int j=0; j<nSamples; ++j) {
// 		float next= fabs(ZXP(in));
// 		//printf("next %f\t",next);

// 		if(envelope<next){
// 			envelope*=ga;
// 			envelope+= (1-ga)*next;
// 		}
// 		else {
// 			envelope*=gr;
// 			envelope+= (1-gr)*next;
// 		}

// 		ZXP(out)= envelope;

// 	}

// 	m_env=envelope;
// }

// } // namespace EnvDetect3

PluginLoad(EnvDetect3UGens) {
    // Plugin magic
    ft = inTable;
    DefineSimpleUnit(EnvDetect3);
}
