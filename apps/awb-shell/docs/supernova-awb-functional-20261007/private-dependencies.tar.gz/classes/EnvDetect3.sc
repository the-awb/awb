EnvDetect3 : UGen {
	*ar { arg in, attack=1, release=1;
		^this.multiNew('audio', in, attack, release);
	}

	*kr { arg in, attack=1, release=1;
		^this.multiNew('control', in, attack, release);
	}
	checkInputs { ^if(rate === \audio) { this.checkSameRateAsFirstInput } }
}
